import Mathlib

namespace HighamBenchCandidate

/- The paper numbers the components from 1 to n. `List.finRange n` visits
   the corresponding `Fin n` indices in that order. The first addition is
   exact because adding a floating-point number to zero leaves it unchanged. -/
def roundedSum {n : ℕ} (w addErr : Fin n → ℝ) : ℝ :=
  (List.finRange n).foldl (fun s i => (s + w i) * (1 + addErr i)) 0

noncomputable def exactY {n : ℕ} (x : Fin n → ℝ) : ℝ :=
  Real.log (∑ i : Fin n, Real.exp (x i))

noncomputable def exactG {n : ℕ} (x : Fin n → ℝ) (j : Fin n) : ℝ :=
  Real.exp (x j - exactY x)

noncomputable def computedY {n : ℕ} (x expErr addErr : Fin n → ℝ) (logErr : ℝ) : ℝ :=
  Real.log (roundedSum (fun i => Real.exp (x i) * (1 + expErr i)) addErr) *
    (1 + logErr)

noncomputable def computedG {n : ℕ} (x expErr addErr subErr finalExpErr : Fin n → ℝ)
    (logErr : ℝ) (j : Fin n) : ℝ :=
  Real.exp ((x j - computedY x expErr addErr logErr) * (1 + subErr j)) *
    (1 + finalExpErr j)

def infinityNorm {n : ℕ} (v : Fin n → ℝ) : ℝ :=
  (List.finRange n).foldl (fun m j => max m |v j|) 0

theorem target :
    ∀ (n : ℕ) (x : Fin n → ℝ) (hn : 0 < n),
      0 < infinityNorm (exactG x) ∧
      ∃ C : ℝ, 0 ≤ C ∧ ∃ radius : ℝ, 0 < radius ∧
        ∀ (u : ℝ), 0 < u → u < radius →
          ∀ (expErr addErr subErr finalExpErr : Fin n → ℝ) (logErr : ℝ),
            (∀ i, |expErr i| ≤ u) →
            (∀ i, |addErr i| ≤ u) →
            addErr ⟨0, hn⟩ = 0 →
            |logErr| ≤ u →
            (∀ i, |subErr i| ≤ u) →
            (∀ i, |finalExpErr i| ≤ u) →
            infinityNorm (fun j =>
                computedG x expErr addErr subErr finalExpErr logErr j - exactG x j) /
              infinityNorm (exactG x) ≤
              (|exactY x| + infinityNorm (fun j => x j - exactY x) +
                (n : ℝ) + 2) * u + C * u ^ 2 := by
  sorry

end HighamBenchCandidate
