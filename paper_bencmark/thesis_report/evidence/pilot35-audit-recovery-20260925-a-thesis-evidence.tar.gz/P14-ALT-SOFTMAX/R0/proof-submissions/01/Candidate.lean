import Mathlib

namespace HighamBenchCandidate

/- The paper numbers the components from 1 to n. `List.finRange n` visits
   the corresponding `Fin n` indices in that order. The first addition is
   exact because adding a floating-point number to zero leaves it unchanged. -/
def roundedSum {n : ℕ} (w addErr : Fin n → ℝ) : ℝ :=
  (List.finRange n).foldl (fun s i => (s + w i) * (1 + addErr i)) 0

noncomputable def exactY {n : ℕ} (x : Fin n → ℝ) : ℝ :=
  Real.log (∑ i : Fin n, Real.exp (x i))

noncomputable def exactG {n : ℕ} (x : Fin n → ℝ) (j : Fin n) : ℝ :=
  Real.exp (x j - exactY x)

noncomputable def computedY {n : ℕ} (x expErr addErr : Fin n → ℝ) (logErr : ℝ) : ℝ :=
  Real.log (roundedSum (fun i => Real.exp (x i) * (1 + expErr i)) addErr) *
    (1 + logErr)

noncomputable def computedG {n : ℕ} (x expErr addErr subErr finalExpErr : Fin n → ℝ)
    (logErr : ℝ) (j : Fin n) : ℝ :=
  Real.exp ((x j - computedY x expErr addErr logErr) * (1 + subErr j)) *
    (1 + finalExpErr j)

def infinityNorm {n : ℕ} (v : Fin n → ℝ) : ℝ :=
  (List.finRange n).foldl (fun m j => max m |v j|) 0

end HighamBenchCandidate

private theorem generic_fold_bounds
    {ι : Type*} (l : List ι) (e w a : ι → ℝ) (u : ℝ)
    (hu : 0 ≤ u) (hu1 : u < 1)
    (he : ∀ i, 0 ≤ e i)
    (hwlo : ∀ i, (1-u)*e i ≤ w i)
    (hwhi : ∀ i, w i ≤ (1+u)*e i)
    (ha : ∀ i, |a i| ≤ u)
    (k : ℕ) (s t : ℝ) (ht : 0 ≤ t)
    (hslo : (1-u)^(k+1)*t ≤ s)
    (hshi : s ≤ (1+u)^(k+1)*t) :
    (1-u)^(k+1+l.length) * l.foldl (fun z i => z+e i) t ≤
      l.foldl (fun z i => (z+w i)*(1+a i)) s ∧
    l.foldl (fun z i => (z+w i)*(1+a i)) s ≤
      (1+u)^(k+1+l.length) * l.foldl (fun z i => z+e i) t := by
  induction l generalizing k s t with
  | nil => simpa using And.intro hslo hshi
  | cons i l ih =>
    have hL : 0 ≤ 1-u := by linarith
    have hH : 1 ≤ 1+u := by linarith
    have hLp : (1-u)^(k+1) ≤ 1-u := by
      rw [pow_succ]
      have hpow : (1-u)^k ≤ 1 := pow_le_one₀ hL (by linarith)
      nlinarith
    have hHp : 1+u ≤ (1+u)^(k+1) := by
      rw [pow_succ]
      have hpow : 1 ≤ (1+u)^k := one_le_pow₀ hH
      nlinarith
    have he0 := he i
    have hnewlo : (1-u)^(k+1) * (t+e i) ≤ s+w i := by
      have h1 : (1-u)^(k+1)*e i ≤ (1-u)*e i := mul_le_mul_of_nonneg_right hLp he0
      have h2 := hwlo i
      nlinarith [mul_add ((1-u)^(k+1)) t (e i)]
    have hnewhi : s+w i ≤ (1+u)^(k+1) * (t+e i) := by
      have h1 : (1+u)*e i ≤ (1+u)^(k+1)*e i := mul_le_mul_of_nonneg_right hHp he0
      have h2 := hwhi i
      nlinarith [mul_add ((1+u)^(k+1)) t (e i)]
    have ha0 : 1-u ≤ 1+a i := by
      have h := (abs_le.mp (ha i)).1
      linarith
    have ha1 : 1+a i ≤ 1+u := by
      have h := (abs_le.mp (ha i)).2
      linarith
    have htnonneg : 0 ≤ t+e i := add_nonneg ht he0
    have hsn : 0 ≤ s+w i := le_trans (mul_nonneg (pow_nonneg hL _) htnonneg) hnewlo
    have hstepLo : (1-u)^(k+2)*(t+e i) ≤ (s+w i)*(1+a i) := by
      rw [show k+2 = (k+1)+1 by omega, pow_succ]
      have h1 := mul_le_mul_of_nonneg_left hnewlo hL
      have h2 := mul_le_mul_of_nonneg_left ha0 hsn
      nlinarith [mul_assoc (1-u) ((1-u)^(k+1)) (t+e i)]
    have hstepHi : (s+w i)*(1+a i) ≤ (1+u)^(k+2)*(t+e i) := by
      rw [show k+2 = (k+1)+1 by omega, pow_succ]
      have h1 := mul_le_mul_of_nonneg_left hnewhi (by linarith : 0 ≤ 1+u)
      have h2 := mul_le_mul_of_nonneg_left ha1 hsn
      nlinarith [mul_assoc (1+u) ((1+u)^(k+1)) (t+e i)]
    have hres := ih (k+1) ((s+w i)*(1+a i)) (t+e i) htnonneg hstepLo hstepHi
    simpa only [List.length_cons, List.foldl_cons, Nat.add_assoc,
      show k+1+(l.length+1)=k+1+1+l.length by omega] using hres

private theorem log_one_sub_lower (u : ℝ) (hu2 : u ≤ 1/2) :
    -(u+2*u^2) ≤ Real.log (1-u) := by
  have hden : 0 < 1-u := by linarith
  have h := Real.one_sub_inv_le_log_of_pos hden
  have hfactor : 0 ≤ u^2*(1-2*u) := mul_nonneg (sq_nonneg u) (by linarith)
  have heq : 1-(1-u)⁻¹ = -u/(1-u) := by
    field_simp
    ring
  have hrat : -(u+2*u^2) ≤ 1-(1-u)⁻¹ := by
    rw [heq]
    apply (le_div_iff₀ hden).mpr
    nlinarith [hfactor]
  exact le_trans hrat h

namespace HighamBenchCandidate
private theorem exact_fold_eq_sum {n : ℕ} (f : Fin n → ℝ) :
    (List.finRange n).foldl (fun z i => z + f i) 0 = ∑ i, f i := by
  simpa [← List.foldl_map, ← List.ofFn_eq_map, List.sum_eq_foldl] using (List.sum_ofFn (f := f))

private theorem computed_sum_bounds {n : ℕ} (x expErr addErr : Fin n → ℝ)
    (u : ℝ) (hu : 0 ≤ u) (hu1 : u < 1)
    (he : ∀ i, |expErr i| ≤ u) (ha : ∀ i, |addErr i| ≤ u) :
    (1-u)^(n+1) * (∑ i : Fin n, Real.exp (x i)) ≤
      roundedSum (fun i => Real.exp (x i)*(1+expErr i)) addErr ∧
    roundedSum (fun i => Real.exp (x i)*(1+expErr i)) addErr ≤
      (1+u)^(n+1) * (∑ i : Fin n, Real.exp (x i)) := by
  let e : Fin n → ℝ := fun i => Real.exp (x i)
  let w : Fin n → ℝ := fun i => e i * (1+expErr i)
  have hlo : ∀ i, (1-u)*e i ≤ w i := by
    intro i
    have hi := (abs_le.mp (he i)).1
    dsimp [w]
    nlinarith [mul_nonneg (Real.exp_pos (x i)).le (show 0 ≤ expErr i+u by linarith)]
  have hhi : ∀ i, w i ≤ (1+u)*e i := by
    intro i
    have hi := (abs_le.mp (he i)).2
    dsimp [w]
    nlinarith [mul_nonneg (Real.exp_pos (x i)).le (show 0 ≤ u-expErr i by linarith)]
  have h := generic_fold_bounds (List.finRange n) e w addErr u hu hu1
    (fun i => (Real.exp_pos (x i)).le) hlo hhi ha 0 0 0
    (by norm_num) (by norm_num) (by norm_num)
  simpa [List.length_finRange, Nat.add_comm, exact_fold_eq_sum, roundedSum, e, w] using h
end HighamBenchCandidate

namespace HighamBenchCandidate
private theorem computedY_error {n : ℕ} (x expErr addErr : Fin n → ℝ)
    (logErr u : ℝ) (hn : 0 < n) (hu : 0 ≤ u) (hu2 : u ≤ 1/2)
    (he : ∀ i, |expErr i| ≤ u) (ha : ∀ i, |addErr i| ≤ u)
    (hl : |logErr| ≤ u) :
    |computedY x expErr addErr logErr - exactY x| ≤
      (|exactY x| + ((n+1 : ℕ) : ℝ))*u +
        5*((n+1 : ℕ) : ℝ)*u^2 := by
  let s : ℝ := ∑ i : Fin n, Real.exp (x i)
  let sh : ℝ := roundedSum (fun i => Real.exp (x i)*(1+expErr i)) addErr
  let p : ℝ := ((n+1 : ℕ) : ℝ)
  have hp : 0 ≤ p := by positivity
  have hL : 0 < 1-u := by linarith
  have hH : 0 < 1+u := by linarith
  have hs : 0 < s := by
    dsimp [s]
    apply Finset.sum_pos
    · intro i hi; exact Real.exp_pos _
    · exact ⟨⟨0, hn⟩, Finset.mem_univ _⟩
  have hb := computed_sum_bounds x expErr addErr u hu (by linarith) he ha
  change (1-u)^(n+1)*s ≤ sh ∧ sh ≤ (1+u)^(n+1)*s at hb
  have hls : 0 < (1-u)^(n+1)*s := mul_pos (pow_pos hL _) hs
  have hsh : 0 < sh := lt_of_lt_of_le hls hb.1
  have hhs : 0 < (1+u)^(n+1)*s := mul_pos (pow_pos hH _) hs
  have hlolog := Real.log_le_log hls hb.1
  have hhilog := Real.log_le_log hsh hb.2
  have hlogL : Real.log ((1-u)^(n+1)*s) = p*Real.log (1-u)+Real.log s := by
    rw [Real.log_mul (pow_pos hL _).ne' hs.ne', Real.log_pow]
  have hlogH : Real.log ((1+u)^(n+1)*s) = p*Real.log (1+u)+Real.log s := by
    rw [Real.log_mul (pow_pos hH _).ne' hs.ne', Real.log_pow]
  have hlogLe : Real.log (1+u) ≤ u := by
    have h := Real.log_le_sub_one_of_pos hH
    linarith
  have hlogGe : -(u+2*u^2) ≤ Real.log (1-u) := log_one_sub_lower u hu2
  have hdelLow : -p*(u+2*u^2) ≤ Real.log sh - Real.log s := by
    rw [hlogL] at hlolog
    nlinarith [mul_le_mul_of_nonneg_left hlogGe hp]
  have hdelHigh : Real.log sh - Real.log s ≤ p*u := by
    rw [hlogH] at hhilog
    nlinarith [mul_le_mul_of_nonneg_left hlogLe hp]
  have hdelAbs : |Real.log sh - Real.log s| ≤ p*u+2*p*u^2 := by
    apply abs_le.mpr
    constructor <;> nlinarith
  have hlogfactor : |1+logErr| ≤ 1+u := by
    have h1 := (abs_le.mp hl).1
    have h2 := (abs_le.mp hl).2
    rw [abs_of_pos (by linarith : 0 < 1+logErr)]
    linarith
  have hysub : computedY x expErr addErr logErr - exactY x =
      (Real.log sh-Real.log s)*(1+logErr) + Real.log s*logErr := by
    dsimp [computedY, exactY, sh, s]
    ring
  rw [hysub]
  have hmul : |(Real.log sh-Real.log s)*(1+logErr)| ≤
      (p*u+2*p*u^2)*(1+u) := by
    rw [abs_mul]
    exact mul_le_mul hdelAbs hlogfactor (abs_nonneg _) (by positivity)
  have hyerr : |Real.log s*logErr| ≤ (abs (Real.log s))*u := by
    rw [abs_mul]
    exact mul_le_mul_of_nonneg_left hl (abs_nonneg _)
  have htri := abs_add_le ((Real.log sh-Real.log s)*(1+logErr)) (Real.log s*logErr)
  have hu1 : u ≤ 1 := by linarith
  have hu2n : 0 ≤ u^2 := sq_nonneg u
  have hu3 : u^3 ≤ u^2 := by nlinarith [mul_nonneg hu2n (sub_nonneg.mpr hu1)]
  have hp_u3 : p*u^3 ≤ p*u^2 := mul_le_mul_of_nonneg_left hu3 hp
  dsimp [p, exactY, s] at *
  nlinarith [htri, hmul, hyerr, hp_u3]
end HighamBenchCandidate

namespace HighamBenchCandidate
private theorem abs_le_infinityNorm {n : ℕ} (v : Fin n → ℝ) (j : Fin n) :
    |v j| ≤ infinityNorm v := by
  let l : List ℝ := (List.finRange n).map (fun i => |v i|)
  have hmem : |v j| ∈ l := List.mem_map.mpr ⟨j, List.mem_finRange j, rfl⟩
  have hne : l ≠ [] := List.ne_nil_of_mem hmem
  have hle := List.le_max_of_mem hmem
  unfold infinityNorm
  rw [← List.foldl_map]
  rw [List.foldl_max_eq_max hne]
  exact le_trans hle le_sup_right

private theorem infinityNorm_le {n : ℕ} (hn : 0 < n) (v : Fin n → ℝ)
    (B : ℝ) (hB : 0 ≤ B) (hv : ∀ j, |v j| ≤ B) : infinityNorm v ≤ B := by
  let l : List ℝ := (List.finRange n).map (fun i => |v i|)
  have hmem : |v ⟨0, hn⟩| ∈ l := List.mem_map.mpr ⟨⟨0, hn⟩, List.mem_finRange _, rfl⟩
  have hne : l ≠ [] := List.ne_nil_of_mem hmem
  have hmax : l.max hne ≤ B := (List.max_le_iff hne).mpr (by
    intro a ha
    obtain ⟨j, hj, rfl⟩ := List.mem_map.mp ha
    exact hv j)
  unfold infinityNorm
  rw [← List.foldl_map]
  rw [List.foldl_max_eq_max hne]
  exact sup_le hB hmax

private theorem exactG_norm_pos {n : ℕ} (x : Fin n → ℝ) (hn : 0 < n) :
    0 < infinityNorm (exactG x) := by
  let j : Fin n := ⟨0, hn⟩
  have h := abs_le_infinityNorm (exactG x) j
  have hg : 0 < |exactG x j| := by
    dsimp [exactG]
    exact abs_pos.mpr (Real.exp_ne_zero _)
  exact lt_of_lt_of_le hg h
end HighamBenchCandidate

private theorem exp_rounded_bound (A B u z c : ℝ)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hz : |z| ≤ A*u+B*u^2) (hc : |c| ≤ u)
    (hsmall : (A+B)*u ≤ 1) :
    |Real.exp z*(1+c)-1| ≤
      (A+1)*u + (B+2*(A+B)^2+(A+B))*u^2 := by
  have hu2 : u^2 ≤ u := by nlinarith [mul_nonneg hu (sub_nonneg.mpr hu1)]
  have hzlin : |z| ≤ (A+B)*u := by
    nlinarith [mul_nonneg hB (sub_nonneg.mpr (by linarith : 0 ≤ u-u^2))]
  have hz1 : |z| ≤ 1 := le_trans hzlin hsmall
  have hrem := Real.norm_exp_sub_one_sub_id_le (show ‖z‖ ≤ 1 by simpa using hz1)
  rw [Real.norm_eq_abs, Real.norm_eq_abs] at hrem
  have hfact : |1+c| ≤ 1+u := by
    have hc1 := (abs_le.mp hc).1
    have hc2 := (abs_le.mp hc).2
    rw [abs_of_nonneg (by linarith : 0 ≤ 1+c)]
    linarith
  have hzsq : z^2 ≤ (A+B)^2*u^2 := by
    calc
      z^2 = |z|^2 := (sq_abs z).symm
      _ ≤ ((A+B)*u)^2 := (sq_le_sq₀ (abs_nonneg _) (mul_nonneg (add_nonneg hA hB) hu)).2 hzlin
      _ = (A+B)^2*u^2 := by ring
  have hidentity : Real.exp z*(1+c)-1 =
      z+c+(Real.exp z-1-z)*(1+c)+z*c := by ring
  rw [hidentity]
  have h1 := abs_add_le (z+c) ((Real.exp z-1-z)*(1+c)+z*c)
  have h2 := abs_add_le z c
  have h3 := abs_add_le ((Real.exp z-1-z)*(1+c)) (z*c)
  have h4 : |(Real.exp z-1-z)*(1+c)| ≤ z^2*(1+u) := by
    rw [abs_mul]
    rw [sq_abs] at hrem
    exact mul_le_mul hrem hfact (abs_nonneg _) (sq_nonneg _)
  have h5 : |z*c| ≤ ((A+B)*u)*u := by
    rw [abs_mul]
    exact mul_le_mul hzlin hc (abs_nonneg _) (mul_nonneg (add_nonneg hA hB) hu)
  have h3u : u^3 ≤ u^2 := by nlinarith [mul_nonneg (sq_nonneg u) (sub_nonneg.mpr hu1)]
  have hsqfact : z^2*(1+u) ≤ 2*(A+B)^2*u^2 := by
    have hfu : 0 ≤ 1+u := by linarith
    have haux := mul_le_mul_of_nonneg_right hzsq hfu
    have hsqnonneg : 0 ≤ (A+B)^2*u^2 := mul_nonneg (sq_nonneg _) (sq_nonneg _)
    nlinarith [mul_nonneg hsqnonneg (sub_nonneg.mpr (by linarith : 0 ≤ 1-u))]
  have habs : |z+c+(Real.exp z-1-z)*(1+c)+z*c| ≤
      |z|+|c|+|(Real.exp z-1-z)*(1+c)|+|z*c| := by
    calc
      _ ≤ |z+c|+|(Real.exp z-1-z)*(1+c)+z*c| := by simpa [add_assoc] using h1
      _ ≤ |z|+|c|+|(Real.exp z-1-z)*(1+c)|+|z*c| := by linarith
  nlinarith [habs, h4, h5, hsqfact, hz, hc]

namespace HighamBenchCandidate

theorem target :
    ∀ (n : ℕ) (x : Fin n → ℝ) (hn : 0 < n),
      0 < infinityNorm (exactG x) ∧
      ∃ C : ℝ, 0 ≤ C ∧ ∃ radius : ℝ, 0 < radius ∧
        ∀ (u : ℝ), 0 < u → u < radius →
          ∀ (expErr addErr subErr finalExpErr : Fin n → ℝ) (logErr : ℝ),
            (∀ i, |expErr i| ≤ u) →
            (∀ i, |addErr i| ≤ u) →
            addErr ⟨0, hn⟩ = 0 →
            |logErr| ≤ u →
            (∀ i, |subErr i| ≤ u) →
            (∀ i, |finalExpErr i| ≤ u) →
            infinityNorm (fun j =>
                computedG x expErr addErr subErr finalExpErr logErr j - exactG x j) /
              infinityNorm (exactG x) ≤
              (|exactY x| + infinityNorm (fun j => x j - exactY x) +
                (n : ℝ) + 2) * u + C * u ^ 2 := by
  intro n x hn
  have hgnorm : 0 < infinityNorm (exactG x) := exactG_norm_pos x hn
  refine ⟨hgnorm, ?_⟩
  let p : ℝ := ((n+1 : ℕ) : ℝ)
  let M : ℝ := infinityNorm (fun j => x j - exactY x)
  let D : ℝ := |exactY x| + p
  let B₁ : ℝ := 5*p
  let A : ℝ := M+D
  let B : ℝ := D+2*B₁
  let C : ℝ := B+2*(A+B)^2+(A+B)
  let radius : ℝ := min (1/2) (1/(A+B+1))
  have hM : 0 ≤ M := by
    have hm := abs_le_infinityNorm (fun j => x j - exactY x) (⟨0, hn⟩ : Fin n)
    exact le_trans (abs_nonneg _) hm
  have hp : 0 ≤ p := by dsimp [p]; positivity
  have hD : 0 ≤ D := by dsimp [D]; positivity
  have hB₁ : 0 ≤ B₁ := by dsimp [B₁]; positivity
  have hA : 0 ≤ A := add_nonneg hM hD
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hden : 0 < A+B+1 := by linarith
  have hradius : 0 < radius := by
    dsimp [radius]
    exact lt_min (by norm_num) (one_div_pos.mpr hden)
  refine ⟨C, hC, radius, hradius, ?_⟩
  intro u hu hura expErr addErr subErr finalExpErr logErr he ha _ hl hb hc
  have hu0 : 0 ≤ u := hu.le
  have hu2 : u ≤ 1/2 := le_of_lt (lt_of_lt_of_le hura (min_le_left _ _))
  have hu1 : u ≤ 1 := by linarith
  have hsmall : (A+B)*u ≤ 1 := by
    have hrad : u < 1/(A+B+1) := lt_of_lt_of_le hura (min_le_right _ _)
    have hprod : u*(A+B+1) < 1 := (lt_div_iff₀ hden).mp hrad
    nlinarith
  have hy : |computedY x expErr addErr logErr - exactY x| ≤ D*u+B₁*u^2 := by
    simpa [D, B₁, p] using computedY_error x expErr addErr logErr u hn hu0 hu2 he ha hl
  have hK : 0 ≤ (A+1)*u+C*u^2 := by positivity
  have hpoint : ∀ j : Fin n,
      |computedG x expErr addErr subErr finalExpErr logErr j - exactG x j| ≤
        infinityNorm (exactG x) * ((A+1)*u+C*u^2) := by
    intro j
    let a : ℝ := x j - exactY x
    let d : ℝ := computedY x expErr addErr logErr - exactY x
    let z : ℝ := a*subErr j-d*(1+subErr j)
    have haM : |a| ≤ M := by
      simpa [a, M] using abs_le_infinityNorm (fun j => x j - exactY x) j
    have hmulA : |a*subErr j| ≤ M*u := by
      rw [abs_mul]
      exact mul_le_mul haM (hb j) (abs_nonneg _) hM
    have hfactor : |1+subErr j| ≤ 1+u := by
      have hb1 := (abs_le.mp (hb j)).1
      have hb2 := (abs_le.mp (hb j)).2
      rw [abs_of_nonneg (by linarith : 0 ≤ 1+subErr j)]
      linarith
    have hd : |d| ≤ D*u+B₁*u^2 := hy
    have hmulD : |d*(1+subErr j)| ≤ (D*u+B₁*u^2)*(1+u) := by
      rw [abs_mul]
      exact mul_le_mul hd hfactor (abs_nonneg _) (by positivity)
    have hzu3 : u^3 ≤ u^2 := by nlinarith [mul_nonneg (sq_nonneg u) (sub_nonneg.mpr hu1)]
    have hB1u3 : B₁*u^3 ≤ B₁*u^2 := mul_le_mul_of_nonneg_left hzu3 hB₁
    have hz : |z| ≤ A*u+B*u^2 := by
      dsimp [z, A, B]
      nlinarith [abs_sub (a*subErr j) (d*(1+subErr j)),
        hmulA, hmulD, hB1u3]
    have hscalar := exp_rounded_bound A B u z (finalExpErr j)
      hA hB hu0 hu1 hz (hc j) hsmall
    have hscalar' : |Real.exp z*(1+finalExpErr j)-1| ≤ (A+1)*u+C*u^2 := by
      simpa [C] using hscalar
    have hgid : computedG x expErr addErr subErr finalExpErr logErr j =
        exactG x j * (Real.exp z*(1+finalExpErr j)) := by
      dsimp [computedG, exactG]
      have hexp : (x j - computedY x expErr addErr logErr)*(1+subErr j) =
          (x j - exactY x)+z := by
        dsimp [z, a, d]
        ring
      rw [hexp, Real.exp_add]
      ring
    have hgpos : 0 < exactG x j := Real.exp_pos _
    have hgle : exactG x j ≤ infinityNorm (exactG x) := by
      simpa [abs_of_pos hgpos] using abs_le_infinityNorm (exactG x) j
    rw [hgid]
    have habsid : |exactG x j*(Real.exp z*(1+finalExpErr j))-exactG x j| =
        exactG x j*|Real.exp z*(1+finalExpErr j)-1| := by
      calc
        _ = |exactG x j*(Real.exp z*(1+finalExpErr j)-1)| := by congr 1; ring
        _ = exactG x j*|Real.exp z*(1+finalExpErr j)-1| := by rw [abs_mul, abs_of_pos hgpos]
    rw [habsid]
    exact le_trans (mul_le_mul_of_nonneg_left hscalar' hgpos.le)
      (mul_le_mul_of_nonneg_right hgle hK)
  have hnorm := infinityNorm_le hn
    (fun j => computedG x expErr addErr subErr finalExpErr logErr j - exactG x j)
    (infinityNorm (exactG x)*((A+1)*u+C*u^2))
    (mul_nonneg hgnorm.le hK) hpoint
  apply (div_le_iff₀ hgnorm).mpr
  have hcoeff : (A+1)*u+C*u^2 =
      (|exactY x|+infinityNorm (fun j => x j-exactY x)+(n:ℝ)+2)*u+C*u^2 := by
    dsimp [A, D, M, p]
    push_cast
    ring
  rw [← hcoeff]
  simpa [mul_comm] using hnorm
end HighamBenchCandidate
