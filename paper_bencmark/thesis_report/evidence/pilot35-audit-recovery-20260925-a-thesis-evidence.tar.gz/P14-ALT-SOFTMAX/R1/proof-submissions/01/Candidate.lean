import Mathlib
import NumStability.Algorithms.Summation.Recursive.Core

namespace HighamBenchCandidate

open NumStability

/-- Local errors for the unshifted log-sum-exp computation followed by the
division-free softmax formula. The binary operations are supplied by `fp`. -/
structure AlternativeExecution (n : ℕ) (fp : FPModel) where
  inputExpError : Fin n → ℝ
  logError : ℝ
  outputExpError : Fin n → ℝ
  inputExpError_bound : ∀ i, |inputExpError i| ≤ fp.u
  logError_bound : |logError| ≤ fp.u
  outputExpError_bound : ∀ i, |outputExpError i| ≤ fp.u

noncomputable def exactSum (n : ℕ) (x : Fin n → ℝ) : ℝ :=
  ∑ i : Fin n, Real.exp (x i)

noncomputable def exactLogSumExp (n : ℕ) (x : Fin n → ℝ) : ℝ :=
  Real.log (exactSum n x)

noncomputable def exactSoftmax (n : ℕ) (x : Fin n → ℝ) : Fin n → ℝ :=
  fun j => Real.exp (x j - exactLogSumExp n x)

noncomputable def computedExponentials {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : Fin n → ℝ :=
  fun i => Real.exp (x i) * (1 + run.inputExpError i)

noncomputable def computedSum {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : ℝ :=
  fl_recursiveSum fp n (computedExponentials run x)

noncomputable def computedLogSumExp {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : ℝ :=
  Real.log (computedSum run x) * (1 + run.logError)

noncomputable def computedAlternativeSoftmax {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : Fin n → ℝ :=
  fun j => Real.exp (fp.fl_sub (x j) (computedLogSumExp run x)) *
    (1 + run.outputExpError j)

private lemma gamma_quadratic_bound (fp : FPModel) (k : ℕ)
    (hsmall : (k : ℝ) * fp.u ≤ 1 / 2) :
    gamma fp k ≤ (k : ℝ) * fp.u +
      2 * ((k : ℝ) * fp.u) ^ 2 := by
  have hv : gammaValid fp k := by
    unfold gammaValid
    linarith
  rw [gamma_eq_linear_plus_quadratic_remainder fp k hv]
  have hd : 0 < 1 - (k : ℝ) * fp.u := by linarith
  have ha : 0 ≤ ((k : ℝ) * fp.u) ^ 2 := sq_nonneg _
  have hq : ((k : ℝ) * fp.u) ^ 2 /
      (1 - (k : ℝ) * fp.u) ≤ 2 * ((k : ℝ) * fp.u) ^ 2 := by
    apply (div_le_iff₀ hd).2
    nlinarith [mul_nonneg ha (show 0 ≤ 1 - 2 * ((k : ℝ) * fp.u) by linarith)]
  linarith

private lemma weighted_factors_bound {n : ℕ}
    (a δ θ : Fin n → ℝ) (u g : ℝ)
    (ha : ∀ i, 0 ≤ a i) (hu : 0 ≤ u) (hg : 0 ≤ g)
    (hδ : ∀ i, |δ i| ≤ u) (hθ : ∀ i, |θ i| ≤ g) :
    |(∑ i : Fin n, a i * (1 + δ i) * (1 + θ i)) -
        ∑ i : Fin n, a i| ≤
      (u + g + u * g) * ∑ i : Fin n, a i := by
  have hpoint (i : Fin n) :
      |a i * (1 + δ i) * (1 + θ i) - a i| ≤
        a i * (u + g + u * g) := by
    have hfac : |δ i + θ i + δ i * θ i| ≤ u + g + u * g := by
      calc
        |δ i + θ i + δ i * θ i| ≤ |δ i + θ i| + |δ i * θ i| :=
          abs_add_le _ _
        _ ≤ |δ i| + |θ i| + |δ i * θ i| := by
          linarith [abs_add_le (δ i) (θ i)]
        _ ≤ u + g + u * g := by
          rw [abs_mul]
          have hp : |δ i| * |θ i| ≤ u * g := by
            gcongr
            · exact hδ i
            · exact hθ i
          linarith [hδ i, hθ i]
    calc
      |a i * (1 + δ i) * (1 + θ i) - a i| =
          a i * |δ i + θ i + δ i * θ i| := by
            have heq : a i * (1 + δ i) * (1 + θ i) - a i =
                a i * (δ i + θ i + δ i * θ i) := by ring
            rw [heq, abs_mul, abs_of_nonneg (ha i)]
      _ ≤ a i * (u + g + u * g) :=
        mul_le_mul_of_nonneg_left hfac (ha i)
  calc
    |(∑ i : Fin n, a i * (1 + δ i) * (1 + θ i)) -
        ∑ i : Fin n, a i| =
        |∑ i : Fin n, (a i * (1 + δ i) * (1 + θ i) - a i)| := by
          rw [Finset.sum_sub_distrib]
    _ ≤ ∑ i : Fin n, |a i * (1 + δ i) * (1 + θ i) - a i| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i : Fin n, a i * (u + g + u * g) := by
      exact Finset.sum_le_sum (fun i _ => hpoint i)
    _ = (u + g + u * g) * ∑ i : Fin n, a i := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (by intro i _; ring)

private lemma gamma_total_coeff_bound (fp : FPModel) (n : ℕ)
    (hn : 0 < n) (hsmall : (n : ℝ) * fp.u ≤ 1 / 4) :
    fp.u + gamma fp (n - 1) + fp.u * gamma fp (n - 1) ≤
      (n : ℝ) * fp.u + 8 * (n : ℝ) ^ 2 * fp.u ^ 2 := by
  let k : ℝ := (n - 1 : ℕ)
  have hkn : k + 1 = (n : ℝ) := by
    dsimp [k]
    exact_mod_cast Nat.sub_add_cancel hn
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hu : 0 ≤ fp.u := fp.u_nonneg
  have hu1 : fp.u ≤ 1 := by nlinarith [mul_nonneg (sub_nonneg.mpr hn1) hu]
  have hk : 0 ≤ k := by dsimp [k]; positivity
  have hku : k * fp.u ≤ (n : ℝ) * fp.u := by
    apply mul_le_mul_of_nonneg_right _ hu
    linarith
  have hsmallk : k * fp.u ≤ 1 / 2 := by linarith
  have hg : gamma fp (n - 1) ≤ k * fp.u + 2 * (k * fp.u) ^ 2 := by
    simpa [k] using gamma_quadratic_bound fp (n - 1) hsmallk
  have hg_mul : fp.u * gamma fp (n - 1) ≤
      fp.u * (k * fp.u + 2 * (k * fp.u) ^ 2) :=
    mul_le_mul_of_nonneg_left hg hu
  have ht2 : (k * fp.u) ^ 2 ≤ ((n : ℝ) * fp.u) ^ 2 := by
    nlinarith [sq_nonneg ((n : ℝ) * fp.u - k * fp.u)]
  have hthird : fp.u * (k * fp.u) ^ 2 ≤ (k * fp.u) ^ 2 := by
    nlinarith [mul_nonneg (show 0 ≤ 1 - fp.u by linarith)
      (sq_nonneg (k * fp.u))]
  have hkut : fp.u * (k * fp.u) ≤ ((n : ℝ) * fp.u) ^ 2 := by
    have hN : fp.u ≤ (n : ℝ) * fp.u := by
      nlinarith [mul_nonneg (sub_nonneg.mpr hn1) hu]
    nlinarith [mul_nonneg (sub_nonneg.mpr hN) (mul_nonneg hk hu),
      mul_nonneg (sub_nonneg.mpr hku) (mul_nonneg (by positivity : (0:ℝ) ≤ n) hu)]
  nlinarith [sq_nonneg ((n : ℝ) * fp.u)]

private lemma exactSum_pos (n : ℕ) (hn : 0 < n) (x : Fin n → ℝ) :
    0 < exactSum n x := by
  unfold exactSum
  apply Finset.sum_pos
  · intro i _
    exact Real.exp_pos _
  · exact ⟨⟨0, hn⟩, Finset.mem_univ _⟩

private lemma computedSum_error (n : ℕ) (hn : 0 < n)
    (x : Fin n → ℝ) (fp : FPModel) (run : AlternativeExecution n fp)
    (hsmall : (n : ℝ) * fp.u ≤ 1 / 4) :
    |computedSum run x - exactSum n x| ≤
      exactSum n x * ((n : ℝ) * fp.u + 8 * (n : ℝ) ^ 2 * fp.u ^ 2) := by
  have hvn : gammaValid fp n := by
    unfold gammaValid
    linarith
  have hv : gammaValid fp (n - 1) :=
    gammaValid_mono fp (Nat.sub_le n 1) hvn
  obtain ⟨θ, hθ, hsum⟩ :=
    recursiveSum_backward_error fp n (computedExponentials run x) hv
  have hrew : computedSum run x =
      ∑ i : Fin n, Real.exp (x i) * (1 + run.inputExpError i) * (1 + θ i) := by
    simpa [computedSum, computedExponentials, mul_assoc] using hsum
  have hb : |computedSum run x - exactSum n x| ≤
      (fp.u + gamma fp (n - 1) + fp.u * gamma fp (n - 1)) *
        exactSum n x := by
    rw [hrew]
    simpa [exactSum] using
      weighted_factors_bound (fun i : Fin n => Real.exp (x i))
        run.inputExpError θ fp.u (gamma fp (n - 1))
        (fun i => (Real.exp_pos _).le) fp.u_nonneg
        (gamma_nonneg fp hv) run.inputExpError_bound hθ
  have hc := gamma_total_coeff_bound fp n hn hsmall
  have hs := (exactSum_pos n hn x).le
  nlinarith [mul_nonneg (sub_nonneg.mpr hc) hs]

private lemma log_one_add_remainder {r : ℝ} (hr : |r| ≤ 1 / 2) :
    |Real.log (1 + r) - r| ≤ 2 * r ^ 2 := by
  have hlt : |-r| < 1 := by rw [abs_neg]; linarith
  have h := Real.abs_log_sub_add_sum_range_le hlt 1
  have h' : |Real.log (1 + r) - r| ≤ r ^ 2 / (1 - |r|) := by
    simpa [pow_two, sub_eq_add_neg, add_comm, add_left_comm, add_assoc] using h
  have hden : 0 < 1 - |r| := by linarith
  have hbound : r ^ 2 / (1 - |r|) ≤ 2 * r ^ 2 := by
    apply (div_le_iff₀ hden).2
    nlinarith [mul_nonneg (sq_nonneg r)
      (show 0 ≤ 1 - 2 * |r| by linarith)]
  exact h'.trans hbound

private lemma computedLogSumExp_error (n : ℕ) (hn : 0 < n)
    (x : Fin n → ℝ) (fp : FPModel) (run : AlternativeExecution n fp)
    (hsmall : (n : ℝ) * fp.u ≤ 1 / 100) :
    |computedLogSumExp run x - exactLogSumExp n x| ≤
      (|exactLogSumExp n x| + (n : ℝ)) * fp.u +
        100 * (n : ℝ) ^ 2 * fp.u ^ 2 := by
  let s := exactSum n x
  let sh := computedSum run x
  let y := exactLogSumExp n x
  let t : ℝ := (n : ℝ) * fp.u
  let r : ℝ := (sh - s) / s
  have hs : 0 < s := exactSum_pos n hn x
  have ht0 : 0 ≤ t := by dsimp [t]; exact mul_nonneg (by positivity) fp.u_nonneg
  have ht : t ≤ 1 / 100 := hsmall
  have hu : 0 ≤ fp.u := fp.u_nonneg
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hu1 : fp.u ≤ 1 := by
    dsimp [t] at ht
    nlinarith [mul_nonneg (sub_nonneg.mpr hn1) hu]
  have hsum : |sh - s| ≤ s * (t + 8 * t ^ 2) := by
    have hq : (n : ℝ) * fp.u ≤ 1 / 4 := by linarith
    convert computedSum_error n hn x fp run hq using 1 <;>
      dsimp [sh, s, t] <;> ring
  have hr : |r| ≤ t + 8 * t ^ 2 := by
    dsimp [r]
    rw [abs_div, abs_of_pos hs]
    exact (div_le_iff₀ hs).2 (by nlinarith [hsum])
  have hA : t + 8 * t ^ 2 ≤ 2 * t := by nlinarith
  have hrt : |r| ≤ 2 * t := hr.trans hA
  have hrhalf : |r| ≤ 1 / 2 := by linarith
  have hmul : sh = s * (1 + r) := by
    dsimp [r]
    field_simp [ne_of_gt hs]
    ring
  have h1r : 0 < 1 + r := by
    have hlow := neg_abs_le r
    linarith
  have hlog : Real.log sh = y + Real.log (1 + r) := by
    rw [hmul, Real.log_mul (ne_of_gt hs) (ne_of_gt h1r)]
    rfl
  have hr2 : r ^ 2 ≤ 4 * t ^ 2 := by
    have hp : 0 ≤ (2 * t - |r|) * (2 * t + |r|) :=
      mul_nonneg (by linarith) (by positivity)
    nlinarith [sq_abs r]
  have hrem := log_one_add_remainder hrhalf
  have hlogabs : |Real.log (1 + r)| ≤ t + 16 * t ^ 2 := by
    have htri : |Real.log (1 + r)| ≤
        |Real.log (1 + r) - r| + |r| := by
      convert abs_add_le (Real.log (1 + r) - r) r using 1 <;> ring
    linarith
  have hδ := run.logError_bound
  have hδ1 : |1 + run.logError| ≤ 1 + fp.u := by
    have ha := abs_add_le (1 : ℝ) run.logError
    norm_num at ha
    linarith
  have hmain : |computedLogSumExp run x - y| ≤
      |y| * fp.u + (t + 16 * t ^ 2) * (1 + fp.u) := by
    have heq : computedLogSumExp run x - y =
        y * run.logError + Real.log (1 + r) * (1 + run.logError) := by
      rw [computedLogSumExp, hlog]
      ring
    rw [heq]
    calc
      |y * run.logError + Real.log (1 + r) * (1 + run.logError)| ≤
          |y * run.logError| +
            |Real.log (1 + r) * (1 + run.logError)| := abs_add_le _ _
      _ = |y| * |run.logError| +
            |Real.log (1 + r)| * |1 + run.logError| := by rw [abs_mul, abs_mul]
      _ ≤ |y| * fp.u + (t + 16 * t ^ 2) * (1 + fp.u) := by
        gcongr
  have hbound : (t + 16 * t ^ 2) * (1 + fp.u) ≤
      t + 100 * t ^ 2 := by
    have htu : t * fp.u ≤ t ^ 2 := by
      dsimp [t]
      nlinarith [mul_nonneg (sub_nonneg.mpr hn1) (sq_nonneg fp.u)]
    have hcubic : fp.u * t ^ 2 ≤ t ^ 2 := by
      nlinarith [mul_nonneg (show 0 ≤ 1 - fp.u by linarith) (sq_nonneg t)]
    nlinarith
  dsimp [y] at hmain ⊢
  have hbound' : t + 100 * t ^ 2 =
      (n : ℝ) * fp.u + 100 * (n : ℝ) ^ 2 * fp.u ^ 2 := by
    dsimp [t]
    ring
  nlinarith [hbound]

private lemma exp_output_error (u E D K d δ : ℝ)
    (hu : 0 ≤ u) (hu1 : u ≤ 1) (hK : 0 ≤ K)
    (hd : |d| ≤ E * u + D * u ^ 2)
    (hdK : |d| ≤ K * u) (hsmall : K * u ≤ 1)
    (hδ : |δ| ≤ u) :
    |Real.exp d * (1 + δ) - 1| ≤
      (E + 1) * u + (D + 2 * K ^ 2 + K) * u ^ 2 := by
  have hd1 : |d| ≤ 1 := by linarith
  have hrem := Real.abs_exp_sub_one_sub_id_le hd1
  have hdiff : |Real.exp d - 1| ≤ |d| + d ^ 2 := by
    have htri := abs_add_le (Real.exp d - 1 - d) d
    have heq : Real.exp d - 1 - d + d = Real.exp d - 1 := by ring
    rw [heq] at htri
    linarith
  have hexp : Real.exp d ≤ 1 + |d| + d ^ 2 := by
    have hle := le_abs_self (Real.exp d - 1 - d)
    have hdle := le_abs_self d
    linarith
  have hd2 : d ^ 2 ≤ K ^ 2 * u ^ 2 := by
    have hp : 0 ≤ (K * u - |d|) * (K * u + |d|) :=
      mul_nonneg (by linarith) (by positivity)
    nlinarith [sq_abs d]
  have hd2u : u * d ^ 2 ≤ K ^ 2 * u ^ 2 := by
    nlinarith [mul_nonneg (show 0 ≤ 1 - u by linarith) (sq_nonneg d)]
  have hrel : |Real.exp d * (1 + δ) - 1| ≤
      |Real.exp d - 1| + Real.exp d * |δ| := by
    have heq : Real.exp d * (1 + δ) - 1 =
        (Real.exp d - 1) + Real.exp d * δ := by ring
    rw [heq]
    have htri := abs_add_le (Real.exp d - 1) (Real.exp d * δ)
    rw [abs_mul, abs_of_pos (Real.exp_pos d)] at htri
    exact htri
  have hδmul : Real.exp d * |δ| ≤ u * (1 + |d| + d ^ 2) := by
    have h₁ : Real.exp d * |δ| ≤ Real.exp d * u :=
      mul_le_mul_of_nonneg_left hδ (Real.exp_pos d).le
    have h₂ : Real.exp d * u ≤ (1 + |d| + d ^ 2) * u :=
      mul_le_mul_of_nonneg_right hexp hu
    nlinarith
  have hdu : u * |d| ≤ K * u ^ 2 := by
    nlinarith [mul_nonneg hu (sub_nonneg.mpr hdK)]
  nlinarith

set_option maxHeartbeats 1000000

/-- Theorem 3.4, with its second-order remainder uniform over all local
rounding errors at fixed positive dimension and input vector. -/
theorem target :
    ∀ (n : ℕ) (_hn : 0 < n) (x : Fin n → ℝ),
      ∃ (C radius : ℝ), 0 ≤ C ∧ 0 < radius ∧
        ∀ (fp : FPModel) (run : AlternativeExecution n fp),
          fp.u < radius →
          0 < ‖exactSoftmax n x‖ ∧
            ‖computedAlternativeSoftmax run x - exactSoftmax n x‖ /
                ‖exactSoftmax n x‖ ≤
              (|exactLogSumExp n x| +
                  ‖fun j : Fin n => x j - exactLogSumExp n x‖ +
                  (n : ℝ) + 2) * fp.u + C * fp.u ^ 2 := by
  intro n hn x
  let y := exactLogSumExp n x
  let g := exactSoftmax n x
  let M : ℝ := ‖fun j : Fin n => x j - y‖
  let A : ℝ := |y| + (n : ℝ)
  let B : ℝ := 100 * (n : ℝ) ^ 2
  let E : ℝ := A + M
  let D : ℝ := A + 2 * B
  let K : ℝ := E + D + 10
  let C : ℝ := D + 2 * K ^ 2 + K
  let radius : ℝ := 1 / (100 * K)
  have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hM : 0 ≤ M := norm_nonneg _
  have hE : 0 ≤ E := by dsimp [E]; positivity
  have hD : 0 ≤ D := by dsimp [D]; positivity
  have hK : 0 < K := by dsimp [K]; positivity
  have hK1 : 1 ≤ K := by dsimp [K]; linarith
  have hKn : (n : ℝ) ≤ K := by
    dsimp [K, E, D, A]
    linarith only [hB, hM, abs_nonneg y]
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hR : 0 < radius := by dsimp [radius]; positivity
  refine ⟨C, radius, hC, hR, ?_⟩
  intro fp run hsmall
  have hu : 0 ≤ fp.u := fp.u_nonneg
  have hKu : K * fp.u ≤ 1 / 100 := by
    have hh : fp.u * (100 * K) < 1 :=
      (lt_div_iff₀ (by positivity : (0 : ℝ) < 100 * K)).mp hsmall
    nlinarith
  have hu1 : fp.u ≤ 1 := by
    have hle : fp.u ≤ K * fp.u := by
      nlinarith [mul_nonneg (sub_nonneg.mpr hK1) hu]
    linarith
  have hnu : (n : ℝ) * fp.u ≤ 1 / 100 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hKn) hu]
  have hy : |computedLogSumExp run x - y| ≤ A * fp.u + B * fp.u ^ 2 := by
    simpa [y, A, B] using computedLogSumExp_error n hn x fp run hnu
  have hgpos (j : Fin n) : 0 < g j := by
    dsimp [g, exactSoftmax]
    exact Real.exp_pos _
  have hgNorm : 0 < ‖g‖ := by
    let j : Fin n := ⟨0, hn⟩
    have h₁ : 0 < ‖g j‖ := by
      rw [Real.norm_eq_abs, abs_of_pos (hgpos j)]
      exact hgpos j
    exact lt_of_lt_of_le h₁ (norm_le_pi_norm g j)
  have hF : 0 ≤ (E + 2) * fp.u + C * fp.u ^ 2 := by positivity
  have hvec : ‖computedAlternativeSoftmax run x - g‖ ≤
      ‖g‖ * ((E + 2) * fp.u + C * fp.u ^ 2) := by
    apply (pi_norm_le_iff_of_nonneg (mul_nonneg (norm_nonneg g) hF)).2
    intro j
    let q : ℝ := x j - y
    let yh : ℝ := computedLogSumExp run x
    let z : ℝ := fp.fl_sub (x j) yh
    let d : ℝ := z - q
    have hq : |q| ≤ M := by
      simpa [q, M, Real.norm_eq_abs] using
        norm_le_pi_norm (fun k : Fin n => x k - y) j
    obtain ⟨δ, hδ, hz⟩ := fp.model_sub (x j) yh
    have hdeq : d = -(yh - y) + q * δ - (yh - y) * δ := by
      dsimp [d, z, q]
      rw [hz]
      ring
    have hd₀ : |d| ≤ |yh - y| + |q| * fp.u + |yh - y| * fp.u := by
      have htri : |d| ≤ |yh - y| + |q| * |δ| + |yh - y| * |δ| := by
        calc
          |d| = |(-(yh - y) + q * δ) + (-(yh - y) * δ)| := by
            rw [hdeq]
            congr 1
            ring
          _ ≤ |-(yh - y) + q * δ| + |-(yh - y) * δ| := abs_add_le _ _
          _ ≤ |yh - y| + |q| * |δ| + |yh - y| * |δ| := by
            have h₂ := abs_add_le (-(yh - y)) (q * δ)
            simp only [abs_neg, abs_mul] at h₂ ⊢
            linarith only [h₂]
      have h₁ : |q| * |δ| ≤ |q| * fp.u :=
        mul_le_mul_of_nonneg_left hδ (abs_nonneg q)
      have h₂ : |yh - y| * |δ| ≤ |yh - y| * fp.u :=
        mul_le_mul_of_nonneg_left hδ (abs_nonneg _)
      linarith
    have hy' : |yh - y| ≤ A * fp.u + B * fp.u ^ 2 := hy
    have hhu : |yh - y| * fp.u ≤ A * fp.u ^ 2 + B * fp.u ^ 2 := by
      have h₁ : |yh - y| * fp.u ≤
          (A * fp.u + B * fp.u ^ 2) * fp.u :=
        mul_le_mul_of_nonneg_right hy' hu
      have h₂ : B * fp.u ^ 3 ≤ B * fp.u ^ 2 := by
        nlinarith [mul_nonneg hB
          (mul_nonneg (sq_nonneg fp.u) (show 0 ≤ 1 - fp.u by linarith))]
      nlinarith
    have hd : |d| ≤ E * fp.u + D * fp.u ^ 2 := by
      have hq' : |q| * fp.u ≤ M * fp.u :=
        mul_le_mul_of_nonneg_right hq hu
      dsimp [E, D]
      nlinarith only [hd₀, hy', hhu, hq']
    have hdK : |d| ≤ K * fp.u := by
      have h₂ : D * fp.u ^ 2 ≤ D * fp.u := by
        nlinarith [mul_nonneg hD
          (mul_nonneg hu (show 0 ≤ 1 - fp.u by linarith))]
      dsimp [K]
      nlinarith only [hd, h₂, hu]
    have hrel := exp_output_error fp.u E D K d (run.outputExpError j)
      hu hu1 hK.le hd hdK (by linarith only [hKu]) (run.outputExpError_bound j)
    have hrel' : |Real.exp d * (1 + run.outputExpError j) - 1| ≤
        (E + 2) * fp.u + C * fp.u ^ 2 := by
      dsimp [C]
      linarith only [hrel, hu]
    have hexp : Real.exp z = Real.exp q * Real.exp d := by
      have hzd : z = q + d := by dsimp [d]; ring
      rw [hzd, Real.exp_add]
    have hpoint : |computedAlternativeSoftmax run x j - g j| ≤
        g j * ((E + 2) * fp.u + C * fp.u ^ 2) := by
      have heq : computedAlternativeSoftmax run x j - g j =
          Real.exp q * (Real.exp d * (1 + run.outputExpError j) - 1) := by
        dsimp [computedAlternativeSoftmax, g, exactSoftmax, q, z]
        rw [hexp]
        ring
      rw [heq, abs_mul, abs_of_pos (Real.exp_pos q)]
      change Real.exp q * |Real.exp d * (1 + run.outputExpError j) - 1| ≤
        Real.exp q * ((E + 2) * fp.u + C * fp.u ^ 2)
      exact mul_le_mul_of_nonneg_left hrel' (Real.exp_pos q).le
    have hgj : g j ≤ ‖g‖ := by
      have hle := norm_le_pi_norm g j
      simpa [Real.norm_eq_abs, abs_of_pos (hgpos j)] using hle
    have hpoint' : |computedAlternativeSoftmax run x j - g j| ≤
        ‖g‖ * ((E + 2) * fp.u + C * fp.u ^ 2) :=
      hpoint.trans (mul_le_mul_of_nonneg_right hgj hF)
    simpa [Pi.sub_apply, Real.norm_eq_abs] using hpoint'
  constructor
  · simpa [g] using hgNorm
  · have hvec' : ‖computedAlternativeSoftmax run x - g‖ ≤
        ((E + 2) * fp.u + C * fp.u ^ 2) * ‖g‖ := by
      calc
        _ ≤ ‖g‖ * ((E + 2) * fp.u + C * fp.u ^ 2) := hvec
        _ = _ := mul_comm _ _
    have hquot := (div_le_iff₀ hgNorm).2 hvec'
    simpa [g, y, E, A, M, add_assoc, add_left_comm, add_comm,
      mul_add, add_mul] using hquot

end HighamBenchCandidate
