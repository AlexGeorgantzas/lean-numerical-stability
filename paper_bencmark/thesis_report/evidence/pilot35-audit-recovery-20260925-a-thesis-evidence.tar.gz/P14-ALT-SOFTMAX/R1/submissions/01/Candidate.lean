import Mathlib
import NumStability.Algorithms.Summation.Recursive.Core

namespace HighamBenchCandidate

open NumStability

/-- Local errors for the unshifted log-sum-exp computation followed by the
division-free softmax formula. The binary operations are supplied by `fp`. -/
structure AlternativeExecution (n : ℕ) (fp : FPModel) where
  inputExpError : Fin n → ℝ
  logError : ℝ
  outputExpError : Fin n → ℝ
  inputExpError_bound : ∀ i, |inputExpError i| ≤ fp.u
  logError_bound : |logError| ≤ fp.u
  outputExpError_bound : ∀ i, |outputExpError i| ≤ fp.u

noncomputable def exactSum (n : ℕ) (x : Fin n → ℝ) : ℝ :=
  ∑ i : Fin n, Real.exp (x i)

noncomputable def exactLogSumExp (n : ℕ) (x : Fin n → ℝ) : ℝ :=
  Real.log (exactSum n x)

noncomputable def exactSoftmax (n : ℕ) (x : Fin n → ℝ) : Fin n → ℝ :=
  fun j => Real.exp (x j - exactLogSumExp n x)

noncomputable def computedExponentials {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : Fin n → ℝ :=
  fun i => Real.exp (x i) * (1 + run.inputExpError i)

noncomputable def computedSum {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : ℝ :=
  fl_recursiveSum fp n (computedExponentials run x)

noncomputable def computedLogSumExp {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : ℝ :=
  Real.log (computedSum run x) * (1 + run.logError)

noncomputable def computedAlternativeSoftmax {n : ℕ} {fp : FPModel}
    (run : AlternativeExecution n fp) (x : Fin n → ℝ) : Fin n → ℝ :=
  fun j => Real.exp (fp.fl_sub (x j) (computedLogSumExp run x)) *
    (1 + run.outputExpError j)

/-- Theorem 3.4, with its second-order remainder uniform over all local
rounding errors at fixed positive dimension and input vector. -/
theorem target :
    ∀ (n : ℕ) (_hn : 0 < n) (x : Fin n → ℝ),
      ∃ (C radius : ℝ), 0 ≤ C ∧ 0 < radius ∧
        ∀ (fp : FPModel) (run : AlternativeExecution n fp),
          fp.u < radius →
          0 < ‖exactSoftmax n x‖ ∧
            ‖computedAlternativeSoftmax run x - exactSoftmax n x‖ /
                ‖exactSoftmax n x‖ ≤
              (|exactLogSumExp n x| +
                  ‖fun j : Fin n => x j - exactLogSumExp n x‖ +
                  (n : ℝ) + 2) * fp.u + C * fp.u ^ 2 := by
  sorry

end HighamBenchCandidate
