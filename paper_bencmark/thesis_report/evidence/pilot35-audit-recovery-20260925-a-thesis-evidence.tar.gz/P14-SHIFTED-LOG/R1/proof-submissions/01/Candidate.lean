import Mathlib
import NumStability.Algorithms.Summation.Recursive.Core
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.SpecialFunctions.Log.Basic

set_option maxHeartbeats 1000000

namespace HighamBenchCandidate

open NumStability
open scoped BigOperators

/- `m + 2` is the paper's input count `n`; this covers every `n ≥ 2`.
   The equivalence lists each index other than the chosen maximum exactly once. -/
abbrev NonmaxOrder (m : ℕ) (k : Fin (m + 2)) :=
  Fin (m + 1) ≃ {i : Fin (m + 2) // i ≠ k}

noncomputable def exactShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k) : ℝ :=
  ∑ j : Fin (m + 1), Real.exp (x (order j).val - x k)

/- FPModel supplies the relative subtraction error. The exponential evaluation
   is supplied separately because FPModel has no rounded exp primitive. -/
def ShiftedExpModel (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (fp : FPModel) (roundedExp : ℝ → ℝ) : Prop :=
  ∀ j : Fin (m + 1), ∃ δ₂ : ℝ,
    |δ₂| ≤ fp.u ∧
      roundedExp (fp.fl_sub (x (order j).val) (x k)) =
        Real.exp (fp.fl_sub (x (order j).val) (x k)) * (1 + δ₂)

noncomputable def computedShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (fp : FPModel) (roundedExp : ℝ → ℝ) : ℝ :=
  fl_recursiveSum fp (m + 1)
    (fun j => roundedExp (fp.fl_sub (x (order j).val) (x k)))

noncomputable def inputMin (m : ℕ) (x : Fin (m + 2) → ℝ) : ℝ :=
  Finset.univ.inf' (Finset.univ_nonempty) x

/- The final addition of the exact maximum is deliberately exact here:
   equation (4.8) discards its later rounding factor δ₄. -/
noncomputable def intermediateResult (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (fp : FPModel) (roundedExp roundedLog1p : ℝ → ℝ) : ℝ :=
  x k + roundedLog1p (computedShiftedSum m x k order fp roundedExp)

private lemma exp_local_bound (t D u δ₁ δ₂ : ℝ)
    (hD : 0 ≤ D) (hu : 0 ≤ u) (hu1 : u ≤ 1) (hDu1 : D * u ≤ 1)
    (ht : |t| ≤ D) (hδ₁ : |δ₁| ≤ u) (hδ₂ : |δ₂| ≤ u) :
    |Real.exp (t * (1 + δ₁)) * (1 + δ₂) - Real.exp t| ≤
      Real.exp t * ((D + 1) * u + (2 * D ^ 2 + D) * u ^ 2) := by
  let r := t * δ₁
  have hr : |r| ≤ D * u := by
    dsimp [r]
    rw [abs_mul]
    exact (mul_le_mul (ht) hδ₁ (abs_nonneg _) hD)
  have hru : D * u ≤ 1 := hDu1
  have hr1 : |r| ≤ 1 := hr.trans hru
  have hrem : |Real.exp r - 1 - r| ≤ |r| ^ 2 := by
    simpa only [Real.norm_eq_abs] using (Real.norm_exp_sub_one_sub_id_le (x := r) hr1)
  have he : |Real.exp r - 1| ≤ |r| + |r| ^ 2 := by
    have htri := abs_add_le (Real.exp r - 1 - r) r
    have heq : (Real.exp r - 1 - r) + r = Real.exp r - 1 := by ring
    rw [heq] at htri
    linarith
  have heexp : Real.exp r ≤ 1 + |r| + |r| ^ 2 := by
    have h := le_abs_self (Real.exp r - 1)
    linarith
  have hrew : Real.exp (t * (1 + δ₁)) = Real.exp t * Real.exp r := by
    rw [show t * (1 + δ₁) = t + r by dsimp [r]; ring, Real.exp_add]
  rw [hrew]
  have hmain : |Real.exp r * (1 + δ₂) - 1| ≤
      |r| + |r| ^ 2 + (1 + |r| + |r| ^ 2) * u := by
    have heexp0 := Real.exp_pos r
    have htri := abs_add_le (Real.exp r - 1) (Real.exp r * δ₂)
    have heq : (Real.exp r - 1) + Real.exp r * δ₂ = Real.exp r * (1 + δ₂) - 1 := by ring
    rw [heq] at htri
    rw [abs_mul, abs_of_pos heexp0] at htri
    have hmul := mul_le_mul_of_nonneg_left hδ₂ heexp0.le
    nlinarith
  have hpoly : |r| + |r| ^ 2 + (1 + |r| + |r| ^ 2) * u ≤
      (D + 1) * u + (2 * D ^ 2 + D) * u ^ 2 := by
    have hru0 : 0 ≤ |r| := abs_nonneg _
    have hDu : 0 ≤ D * u := mul_nonneg hD hu
    have hr2 : |r| ^ 2 ≤ (D * u) ^ 2 := pow_le_pow_left₀ hru0 hr 2
    nlinarith [mul_nonneg (sub_nonneg.mpr hr) hu, mul_nonneg (sub_nonneg.mpr hr2) hu]
  calc
    |Real.exp t * Real.exp r * (1 + δ₂) - Real.exp t| =
        Real.exp t * |Real.exp r * (1 + δ₂) - 1| := by
          convert congrArg (fun z : ℝ => |z|) (show Real.exp t * Real.exp r * (1 + δ₂) - Real.exp t = Real.exp t * (Real.exp r * (1 + δ₂) - 1) by ring) using 1 <;> rw [abs_mul, abs_of_pos (Real.exp_pos t)]
    _ ≤ Real.exp t * ((D + 1) * u + (2 * D ^ 2 + D) * u ^ 2) := by
      gcongr
      exact hmain.trans hpoly

private lemma log_local_bound (s d : ℝ) (hs : 0 ≤ s)
    (hd : |d| ≤ (1 + s) / 2) :
    |Real.log (1 + s + d) - Real.log (1 + s)| ≤
      |d| / (1 + s) + 2 * (|d| / (1 + s)) ^ 2 := by
  let r := d / (1 + s)
  have hspos : 0 < 1 + s := by linarith
  have hrabs : |r| = |d| / (1 + s) := by simp [r, abs_div, abs_of_pos hspos]
  have hrhalf : |r| ≤ 1 / 2 := by
    rw [hrabs]
    apply (div_le_iff₀ hspos).2
    nlinarith
  have hrlt : |r| < 1 := by linarith
  have hlogrem : |Real.log (1 + r) - r| ≤ |r| ^ 2 / (1 - |r|) := by
    have h := Real.abs_log_sub_add_sum_range_le (x := -r) (by simpa only [abs_neg] using hrlt) 1
    simpa [Finset.sum_range_succ, Finset.sum_range_zero, abs_neg, sub_eq_add_neg, add_comm,
      add_left_comm, add_assoc] using h
  have hrden : 0 < 1 - |r| := by linarith
  have hrem2 : |r| ^ 2 / (1 - |r|) ≤ 2 * |r| ^ 2 := by
    apply (div_le_iff₀ hrden).2
    nlinarith [sq_nonneg |r|]
  have hlogabs : |Real.log (1 + r)| ≤ |r| + 2 * |r| ^ 2 := by
    have htri := abs_add_le (Real.log (1 + r) - r) r
    have heq : (Real.log (1 + r) - r) + r = Real.log (1 + r) := by ring
    rw [heq] at htri
    linarith
  have h1r : 0 < 1 + r := by
    have := neg_abs_le r
    linarith
  have harg : 1 + s + d = (1 + s) * (1 + r) := by
    dsimp [r]
    field_simp
  have hlogeq : Real.log (1 + s + d) - Real.log (1 + s) = Real.log (1 + r) := by
    rw [harg, Real.log_mul (ne_of_gt hspos) (ne_of_gt h1r)]
    ring
  rw [hlogeq, ← hrabs]
  exact hlogabs

private lemma recursive_sum_local_error {n : ℕ} (fp : NumStability.FPModel)
    (w v : Fin n → ℝ) (E G : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hE : 0 ≤ E) (hG : 0 ≤ G)
    (hlocal : ∀ i, |v i - w i| ≤ w i * E)
    (hvalid : NumStability.gammaValid fp (n - 1))
    (hgamma : NumStability.gamma fp (n - 1) ≤ G) :
    |NumStability.fl_recursiveSum fp n v - ∑ i, w i| ≤
      (∑ i, w i) * (E + G * (1 + E)) := by
  have hwabs : ∀ i, |v i| ≤ w i * (1 + E) := by
    intro i
    have htri := abs_add_le (v i - w i) (w i)
    have heq : (v i - w i) + w i = v i := by ring
    rw [heq, abs_of_nonneg (hw i)] at htri
    nlinarith [hlocal i]
  have hsumlocal : |(∑ i, v i) - ∑ i, w i| ≤ (∑ i, w i) * E := by
    rw [← Finset.sum_sub_distrib]
    calc
      |∑ i, (v i - w i)| ≤ ∑ i, |v i - w i| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ i, w i * E := Finset.sum_le_sum (fun i _ => hlocal i)
      _ = (∑ i, w i) * E := by rw [Finset.sum_mul]
  have hsumabs : (∑ i, |v i|) ≤ (∑ i, w i) * (1 + E) := by
    calc
      (∑ i, |v i|) ≤ ∑ i, w i * (1 + E) := Finset.sum_le_sum (fun i _ => hwabs i)
      _ = (∑ i, w i) * (1 + E) := by rw [Finset.sum_mul]
  have hfl := NumStability.recursiveSum_forward_error_bound fp n v hvalid
  have hsum_nonneg : 0 ≤ ∑ i, w i := Finset.sum_nonneg (fun i _ => hw i)
  have habs_nonneg : 0 ≤ ∑ i, |v i| := Finset.sum_nonneg (fun i _ => abs_nonneg _)
  have hγnonneg := NumStability.gamma_nonneg fp hvalid
  have hfl' : |NumStability.fl_recursiveSum fp n v - ∑ i, v i| ≤
      G * ((∑ i, w i) * (1 + E)) := by
    calc
      |NumStability.fl_recursiveSum fp n v - ∑ i, v i|
        ≤ NumStability.gamma fp (n - 1) * ∑ i, |v i| := hfl
      _ ≤ G * ∑ i, |v i| := mul_le_mul_of_nonneg_right hgamma habs_nonneg
      _ ≤ G * ((∑ i, w i) * (1 + E)) := mul_le_mul_of_nonneg_left hsumabs hG
  have htri := abs_add_le
    (NumStability.fl_recursiveSum fp n v - ∑ i, v i)
    ((∑ i, v i) - ∑ i, w i)
  have heq : (NumStability.fl_recursiveSum fp n v - ∑ i, v i) +
      ((∑ i, v i) - ∑ i, w i) =
      NumStability.fl_recursiveSum fp n v - ∑ i, w i := by ring
  rw [heq] at htri
  nlinarith

private lemma gamma_quadratic (fp : NumStability.FPModel) (m : ℕ)
    (hhalf : (m : ℝ) * fp.u ≤ 1 / 2) :
    NumStability.gamma fp m ≤
      (m : ℝ) * fp.u + 2 * ((m : ℝ) * fp.u) ^ 2 := by
  have hu0 := fp.u_nonneg
  have hvalid : NumStability.gammaValid fp m := by
    unfold NumStability.gammaValid
    linarith
  have hden : 0 < 1 - (m : ℝ) * fp.u := by linarith
  have hdenhalf : 1 / 2 ≤ 1 - (m : ℝ) * fp.u := by linarith
  rw [NumStability.gamma_eq_linear_plus_quadratic_remainder fp m hvalid]
  have hsq : 0 ≤ ((m : ℝ) * fp.u) ^ 2 := sq_nonneg _
  have hdiv : ((m : ℝ) * fp.u) ^ 2 / (1 - (m : ℝ) * fp.u) ≤
      2 * ((m : ℝ) * fp.u) ^ 2 := by
    apply (div_le_iff₀ hden).2
    nlinarith
  linarith

private lemma final_log_error (s shat yhat u L K : ℝ)
    (hs : 0 ≤ s) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hL : 0 ≤ L) (hK : 0 ≤ K)
    (hsmall : (L + K) * u ≤ 1 / 2)
    (hsum : |shat - s| ≤ s * (L * u + K * u ^ 2))
    (hlog : ∃ δ : ℝ, |δ| ≤ u ∧ yhat = Real.log (1 + shat) * (1 + δ)) :
    |Real.log (1 + s) - yhat| ≤
      (Real.log (1 + s) + s / (1 + s) * (L + 1)) * u +
        (L + 2 * K + 4 * (L + K) ^ 2) * u ^ 2 := by
  let q := s / (1 + s)
  let r := |shat - s| / (1 + s)
  have hs1 : 0 < 1 + s := by linarith
  have hq0 : 0 ≤ q := div_nonneg hs hs1.le
  have hq1 : q ≤ 1 := by
    dsimp [q]
    apply (div_le_iff₀ hs1).2
    linarith
  have hu2 : u ^ 2 ≤ u := by nlinarith
  have hE : 0 ≤ L * u + K * u ^ 2 := by positivity
  have hr0 : 0 ≤ r := div_nonneg (abs_nonneg _) hs1.le
  have hrbound : r ≤ q * (L * u + K * u ^ 2) := by
    dsimp [r, q]
    simpa [div_mul_eq_mul_div] using (div_le_div_of_nonneg_right hsum hs1.le)
  have hrsmall : r ≤ 1 / 2 := by
    have hEsmall : L * u + K * u ^ 2 ≤ (L + K) * u := by nlinarith
    have hqE := mul_le_mul_of_nonneg_left hEsmall hq0
    have hqP := mul_le_mul_of_nonneg_right hq1 (mul_nonneg (by positivity : 0 ≤ L + K) hu)
    nlinarith
  have hdlow : |shat - s| ≤ (1 + s) / 2 := by
    dsimp [r] at hrsmall
    apply (div_le_iff₀ hs1).mp at hrsmall
    linarith
  have hlogdiff := log_local_bound s (shat - s) hs (by simpa [add_comm, add_left_comm, add_assoc] using hdlow)
  have harg : 1 + s + (shat - s) = 1 + shat := by ring
  rw [harg] at hlogdiff
  have hlog0 : 0 ≤ Real.log (1 + s) := Real.log_nonneg (by linarith)
  obtain ⟨δ, hδ, hyhat⟩ := hlog
  have hδu : |δ| ≤ u := hδ
  have hloghat : |Real.log (1 + shat)| ≤ Real.log (1 + s) + |Real.log (1 + shat) - Real.log (1 + s)| := by
    have h := abs_add_le (Real.log (1 + shat) - Real.log (1 + s)) (Real.log (1 + s))
    have heq : (Real.log (1 + shat) - Real.log (1 + s)) + Real.log (1 + s) = Real.log (1 + shat) := by ring
    rw [heq, abs_of_nonneg hlog0] at h
    linarith
  have herr : |Real.log (1 + s) - yhat| ≤
      Real.log (1 + s) * u + (1 + u) * (r + 2 * r ^ 2) := by
    rw [hyhat]
    have htri := abs_add_le (Real.log (1 + s) - Real.log (1 + shat))
      (-(Real.log (1 + shat) * δ))
    have heq : (Real.log (1 + s) - Real.log (1 + shat)) + -(Real.log (1 + shat) * δ) =
        Real.log (1 + s) - Real.log (1 + shat) * (1 + δ) := by ring
    rw [heq, abs_neg, abs_mul] at htri
    rw [abs_sub_comm (Real.log (1 + s)) (Real.log (1 + shat))] at htri
    have hmul := mul_le_mul_of_nonneg_left hδu (abs_nonneg (Real.log (1 + shat)))
    have hlogdiff' : |Real.log (1 + shat) - Real.log (1 + s)| ≤ r + 2 * r ^ 2 := by
      simpa [r, abs_sub_comm] using hlogdiff
    have hhatU := mul_le_mul_of_nonneg_right hloghat hu
    have hDU := mul_le_mul_of_nonneg_right hlogdiff' (by linarith : 0 ≤ 1 + u)
    nlinarith only [htri, hmul, hhatU, hDU]
  have hP : 0 ≤ L + K := by linarith
  have hrP : r ≤ (L + K) * u := by
    have hEsmall : L * u + K * u ^ 2 ≤ (L + K) * u := by nlinarith
    have hqE := mul_le_mul_of_nonneg_left hEsmall hq0
    have hqP := mul_le_mul_of_nonneg_right hq1 (mul_nonneg hP hu)
    linarith
  have hr2 : r ^ 2 ≤ (L + K) ^ 2 * u ^ 2 := by
    nlinarith [sq_nonneg ((L + K) * u - r)]
  have huR : u * r ≤ q * (L + K) * u ^ 2 := by
    have huB := mul_le_mul_of_nonneg_left hrbound hu
    have h1u : 0 ≤ 1 - u := by linarith
    nlinarith [mul_nonneg hq0 (mul_nonneg hK (mul_nonneg (sq_nonneg u) h1u))]
  have hR : r ≤ q * L * u + q * K * u ^ 2 := by nlinarith [hrbound]
  have hR2 : 2 * (1 + u) * r ^ 2 ≤ 4 * (L + K) ^ 2 * u ^ 2 := by
    calc
      2 * (1 + u) * r ^ 2 ≤ 2 * (1 + u) * ((L + K) ^ 2 * u ^ 2) := by gcongr
      _ ≤ 4 * ((L + K) ^ 2 * u ^ 2) := by gcongr <;> nlinarith
      _ = 4 * (L + K) ^ 2 * u ^ 2 := by ring
  have hCnonneg : 0 ≤ L + 2 * K + 4 * (L + K) ^ 2 := by positivity
  have hqK := mul_le_mul_of_nonneg_right hq1 (mul_nonneg hK (sq_nonneg u))
  have hqLK := mul_le_mul_of_nonneg_right hq1 (mul_nonneg hP (sq_nonneg u))
  nlinarith

private lemma scalar_poly_bound (A B M u : ℝ)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hM : 0 ≤ M)
    (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    (A * u + B * u ^ 2) + (M * u + 2 * M ^ 2 * u ^ 2) *
        (1 + A * u + B * u ^ 2) ≤
      (M + A) * u +
        (B + 2 * M ^ 2 + M * (A + B) + 2 * M ^ 2 * (A + B)) * u ^ 2 := by
  have h3 : u ^ 3 ≤ u ^ 2 := by
    nlinarith [mul_nonneg (sq_nonneg u) (show 0 ≤ 1-u by linarith)]
  have h4 : u ^ 4 ≤ u ^ 2 := by
    nlinarith [mul_nonneg (sq_nonneg u) (show 0 ≤ 1-u^2 by nlinarith)]
  have hMB : M * B * u ^ 3 ≤ M * B * u ^ 2 :=
    mul_le_mul_of_nonneg_left h3 (mul_nonneg hM hB)
  have hMA : 2 * M ^ 2 * A * u ^ 3 ≤ 2 * M ^ 2 * A * u ^ 2 :=
    mul_le_mul_of_nonneg_left h3 (by positivity)
  have hM2B : 2 * M ^ 2 * B * u ^ 4 ≤ 2 * M ^ 2 * B * u ^ 2 :=
    mul_le_mul_of_nonneg_left h4 (by positivity)
  nlinarith only [hMB, hMA, hM2B]

private lemma shifted_sum_bound (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (D : ℝ) (hD : 0 ≤ D)
    (hgap : ∀ j : Fin (m + 1), |x (order j).val - x k| ≤ D)
    (fp : NumStability.FPModel) (roundedExp : ℝ → ℝ)
    (hu1 : fp.u ≤ 1) (hDu1 : D * fp.u ≤ 1)
    (hmhalf : (m : ℝ) * fp.u ≤ 1 / 2)
    (hExp : ShiftedExpModel m x k order fp roundedExp) :
    let A := D + 1
    let B := 2 * D ^ 2 + D
    let M := (m : ℝ)
    let K := B + 2 * M ^ 2 + M * (A + B) + 2 * M ^ 2 * (A + B)
    |computedShiftedSum m x k order fp roundedExp - exactShiftedSum m x k order| ≤
      exactShiftedSum m x k order * ((M + A) * fp.u + K * fp.u ^ 2) := by
  dsimp
  let A : ℝ := D + 1
  let B : ℝ := 2 * D ^ 2 + D
  let M : ℝ := m
  let K : ℝ := B + 2 * M ^ 2 + M * (A + B) + 2 * M ^ 2 * (A + B)
  let E : ℝ := A * fp.u + B * fp.u ^ 2
  let G : ℝ := M * fp.u + 2 * M ^ 2 * fp.u ^ 2
  let w : Fin (m + 1) → ℝ := fun j => Real.exp (x (order j).val - x k)
  let v : Fin (m + 1) → ℝ := fun j => roundedExp (fp.fl_sub (x (order j).val) (x k))
  have hA : 0 ≤ A := by dsimp [A]; linarith
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hM : 0 ≤ M := by dsimp [M]; positivity
  have hu0 := fp.u_nonneg
  have hE : 0 ≤ E := by dsimp [E]; positivity
  have hG : 0 ≤ G := by dsimp [G]; positivity
  have hw : ∀ j, 0 ≤ w j := fun j => (Real.exp_pos _).le
  have hlocal : ∀ j, |v j - w j| ≤ w j * E := by
    intro j
    obtain ⟨δ₂, hδ₂, hExp₂⟩ := hExp j
    obtain ⟨δ₁, hδ₁, hSub⟩ := fp.model_sub (x (order j).val) (x k)
    have hloc := exp_local_bound (x (order j).val - x k) D fp.u δ₁ δ₂
      hD hu0 hu1 hDu1 (hgap j) hδ₁ hδ₂
    dsimp [v, w, E, A, B]
    rw [hExp₂, hSub]
    exact hloc
  have hvalid : NumStability.gammaValid fp m := by
    unfold NumStability.gammaValid
    linarith
  have hgamma : NumStability.gamma fp m ≤ G := by
    convert gamma_quadratic fp m hmhalf using 1 <;> dsimp [G, M] <;> ring
  have hsum := recursive_sum_local_error fp w v E G hw hE hG hlocal hvalid (by simpa using hgamma)
  have hpoly : E + G * (1 + E) ≤ (M + A) * fp.u + K * fp.u ^ 2 := by
    convert scalar_poly_bound A B M fp.u hA hB hM hu0 hu1 using 1 <;> dsimp [E, G, K] <;> ring
  have hs0 : 0 ≤ ∑ j, w j := Finset.sum_nonneg (fun j _ => hw j)
  have hmul := mul_le_mul_of_nonneg_left hpoly hs0
  simpa [computedShiftedSum, exactShiftedSum, v, w, M, A, K] using hsum.trans hmul


/- Big-O is uniform over all admissible rounding executions at fixed input and
   order: one constant C and one positive radius work for every FPModel and
   every local exp/log1p evaluation satisfying the source relative-error laws. -/
theorem target :
    ∀ (m : ℕ) (x : Fin (m + 2) → ℝ) (k : Fin (m + 2))
      (order : NonmaxOrder m k),
      (∀ i : Fin (m + 2), x i ≤ x k) →
      ∃ C ε : ℝ, 0 ≤ C ∧ 0 < ε ∧
        ∀ (fp : FPModel), fp.u ≤ ε →
        ∀ (roundedExp roundedLog1p : ℝ → ℝ),
          ShiftedExpModel m x k order fp roundedExp →
          (∃ δ₃ : ℝ, |δ₃| ≤ fp.u ∧
            roundedLog1p (computedShiftedSum m x k order fp roundedExp) =
              Real.log (1 + computedShiftedSum m x k order fp roundedExp) *
                (1 + δ₃)) →
          let s := exactShiftedSum m x k order
          let y := x k + Real.log (1 + s)
          let yHat := intermediateResult m x k order fp roundedExp roundedLog1p
          |y - yHat| ≤
            (Real.log (1 + s) +
              s / (1 + s) * ((m + 2 : ℕ) + x k - inputMin m x)) * fp.u +
              C * fp.u ^ 2 := by
  intro m x k order hmax
  let D : ℝ := x k - inputMin m x
  let A : ℝ := D + 1
  let B : ℝ := 2 * D ^ 2 + D
  let M : ℝ := m
  let K : ℝ := B + 2 * M ^ 2 + M * (A + B) + 2 * M ^ 2 * (A + B)
  let L : ℝ := M + A
  let P : ℝ := L + K
  let C : ℝ := L + 2 * K + 4 * P ^ 2
  let ε : ℝ := 1 / (4 * (P + 1))
  have hmin : ∀ i : Fin (m + 2), inputMin m x ≤ x i := by
    intro i
    unfold inputMin
    exact Finset.inf'_le x (Finset.mem_univ i)
  have hD : 0 ≤ D := by dsimp [D]; linarith [hmin k]
  have hgap : ∀ j : Fin (m + 1), |x (order j).val - x k| ≤ D := by
    intro j
    have hlow := hmin (order j).val
    have hhigh := hmax (order j).val
    rw [abs_of_nonpos (by linarith)]
    dsimp [D]
    linarith
  have hA : 0 ≤ A := by dsimp [A]; linarith
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hM : 0 ≤ M := by dsimp [M]; positivity
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hL : 0 ≤ L := by dsimp [L]; positivity
  have hP : 0 ≤ P := by dsimp [P]; positivity
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hε : 0 < ε := by dsimp [ε]; positivity
  have hεeq : 4 * (P + 1) * ε = 1 := by
    dsimp [ε]
    field_simp
  refine ⟨C, ε, hC, hε, ?_⟩
  intro fp huε roundedExp roundedLog1p hExp hLog
  have hu0 := fp.u_nonneg
  have hprod : 4 * (P + 1) * fp.u ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_left huε (by positivity : 0 ≤ 4 * (P + 1))
    nlinarith [hεeq]
  have hPu : P * fp.u ≤ 1 / 2 := by
    nlinarith [mul_nonneg hP hu0]
  have hu1 : fp.u ≤ 1 := by nlinarith
  have hDleP : D ≤ P := by dsimp [P, L, A]; linarith
  have hMleP : M ≤ P := by dsimp [P, L]; linarith
  have hDu1 : D * fp.u ≤ 1 := by
    have hh := mul_le_mul_of_nonneg_right hDleP hu0
    linarith
  have hmhalf : (m : ℝ) * fp.u ≤ 1 / 2 := by
    have hh := mul_le_mul_of_nonneg_right hMleP hu0
    simpa [M] using hh.trans hPu
  let s := exactShiftedSum m x k order
  let shat := computedShiftedSum m x k order fp roundedExp
  have hs : 0 ≤ s := by
    dsimp [s, exactShiftedSum]
    exact Finset.sum_nonneg (fun j _ => (Real.exp_pos _).le)
  have hsum : |shat - s| ≤ s * (L * fp.u + K * fp.u ^ 2) := by
    simpa [s, shat, L, M, A, K, B] using
      shifted_sum_bound m x k order D hD hgap fp roundedExp hu1 hDu1 hmhalf hExp
  have hsmall : (L + K) * fp.u ≤ 1 / 2 := by
    simpa [P] using hPu
  have hlog : ∃ δ : ℝ, |δ| ≤ fp.u ∧
      roundedLog1p shat = Real.log (1 + shat) * (1 + δ) := by
    simpa [shat] using hLog
  have hfinal := final_log_error s shat (roundedLog1p shat) fp.u L K
    hs hu0 hu1 hL hK hsmall hsum hlog
  have hcoeff : L + 1 = (m + 2 : ℕ) + x k - inputMin m x := by
    dsimp [L, M, A, D]
    push_cast
    ring
  dsimp
  change |(x k + Real.log (1 + s)) -
      (x k + roundedLog1p shat)| ≤
    (Real.log (1 + s) +
      s / (1 + s) * ((m + 2 : ℕ) + x k - inputMin m x)) * fp.u +
      C * fp.u ^ 2
  calc
    |(x k + Real.log (1 + s)) - (x k + roundedLog1p shat)| =
        |Real.log (1 + s) - roundedLog1p shat| := by congr 1; ring
    _ ≤ (Real.log (1 + s) + s / (1 + s) * (L + 1)) * fp.u + C * fp.u ^ 2 := by
      simpa [C, P] using hfinal
    _ = (Real.log (1 + s) +
          s / (1 + s) * ((m + 2 : ℕ) + x k - inputMin m x)) * fp.u +
          C * fp.u ^ 2 := by rw [hcoeff]

end HighamBenchCandidate
