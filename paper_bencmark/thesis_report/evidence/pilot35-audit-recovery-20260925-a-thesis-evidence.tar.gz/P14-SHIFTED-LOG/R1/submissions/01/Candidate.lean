import NumStability.Algorithms.Summation.Recursive.Core
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.SpecialFunctions.Log.Basic

namespace HighamBenchCandidate

open NumStability
open scoped BigOperators

/- `m + 2` is the paper's input count `n`; this covers every `n ≥ 2`.
   The equivalence lists each index other than the chosen maximum exactly once. -/
abbrev NonmaxOrder (m : ℕ) (k : Fin (m + 2)) :=
  Fin (m + 1) ≃ {i : Fin (m + 2) // i ≠ k}

noncomputable def exactShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k) : ℝ :=
  ∑ j : Fin (m + 1), Real.exp (x (order j).val - x k)

/- FPModel supplies the relative subtraction error. The exponential evaluation
   is supplied separately because FPModel has no rounded exp primitive. -/
def ShiftedExpModel (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (fp : FPModel) (roundedExp : ℝ → ℝ) : Prop :=
  ∀ j : Fin (m + 1), ∃ δ₂ : ℝ,
    |δ₂| ≤ fp.u ∧
      roundedExp (fp.fl_sub (x (order j).val) (x k)) =
        Real.exp (fp.fl_sub (x (order j).val) (x k)) * (1 + δ₂)

noncomputable def computedShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (fp : FPModel) (roundedExp : ℝ → ℝ) : ℝ :=
  fl_recursiveSum fp (m + 1)
    (fun j => roundedExp (fp.fl_sub (x (order j).val) (x k)))

noncomputable def inputMin (m : ℕ) (x : Fin (m + 2) → ℝ) : ℝ :=
  Finset.univ.inf' (Finset.univ_nonempty) x

/- The final addition of the exact maximum is deliberately exact here:
   equation (4.8) discards its later rounding factor δ₄. -/
noncomputable def intermediateResult (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (order : NonmaxOrder m k)
    (fp : FPModel) (roundedExp roundedLog1p : ℝ → ℝ) : ℝ :=
  x k + roundedLog1p (computedShiftedSum m x k order fp roundedExp)

/- Big-O is uniform over all admissible rounding executions at fixed input and
   order: one constant C and one positive radius work for every FPModel and
   every local exp/log1p evaluation satisfying the source relative-error laws. -/
theorem target :
    ∀ (m : ℕ) (x : Fin (m + 2) → ℝ) (k : Fin (m + 2))
      (order : NonmaxOrder m k),
      (∀ i : Fin (m + 2), x i ≤ x k) →
      ∃ C ε : ℝ, 0 ≤ C ∧ 0 < ε ∧
        ∀ (fp : FPModel), fp.u ≤ ε →
        ∀ (roundedExp roundedLog1p : ℝ → ℝ),
          ShiftedExpModel m x k order fp roundedExp →
          (∃ δ₃ : ℝ, |δ₃| ≤ fp.u ∧
            roundedLog1p (computedShiftedSum m x k order fp roundedExp) =
              Real.log (1 + computedShiftedSum m x k order fp roundedExp) *
                (1 + δ₃)) →
          let s := exactShiftedSum m x k order
          let y := x k + Real.log (1 + s)
          let yHat := intermediateResult m x k order fp roundedExp roundedLog1p
          |y - yHat| ≤
            (Real.log (1 + s) +
              s / (1 + s) * ((m + 2 : ℕ) + x k - inputMin m x)) * fp.u +
              C * fp.u ^ 2 := by
  sorry

end HighamBenchCandidate
