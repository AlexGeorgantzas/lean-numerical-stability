import Mathlib

namespace HighamBenchCandidate

/-- An order containing each index other than the chosen maximum exactly once. -/
def ValidOrder {n : ℕ} (k : Fin n) (order : List (Fin n)) : Prop :=
  order.Nodup ∧ ∀ i : Fin n, i ∈ order ↔ i ≠ k

/-- The exact sum of the shifted exponential terms, in the selected order. -/
noncomputable def shiftedSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) : ℝ :=
  (order.map fun i => Real.exp (x i - x k)).sum

/-- A shifted exponential after relative errors in the subtraction and exponential. -/
noncomputable def computedTerm {n : ℕ} (x : Fin n → ℝ) (k i : Fin n)
    (δsub δexp : Fin n → ℝ) : ℝ :=
  Real.exp ((x i - x k) * (1 + δsub i)) * (1 + δexp i)

/-- Recursive accumulation, starting at zero, with a relative error at each addition. -/
noncomputable def computedSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) (δsub δexp δadd : Fin n → ℝ) : ℝ :=
  order.foldl
    (fun acc i => (acc + computedTerm x k i δsub δexp) * (1 + δadd i)) 0

/-- The value after the rounded log1p evaluation and before the final addition. -/
noncomputable def intermediateValue {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) (δsub δexp δadd : Fin n → ℝ)
    (δlog : ℝ) : ℝ :=
  x k + Real.log (1 + computedSum x k order δsub δexp δadd) * (1 + δlog)

theorem target :
    ∀ (n : ℕ) (_hn : 2 ≤ n) (x : Fin n → ℝ) (k : Fin n),
      (∀ i : Fin n, x i ≤ x k) →
      ∀ (xmin : ℝ),
        ((∀ i : Fin n, xmin ≤ x i) ∧ (∃ i : Fin n, x i = xmin)) →
        ∀ (order : List (Fin n)), ValidOrder k order →
          ∃ (C u₀ : ℝ), 0 ≤ C ∧ 0 < u₀ ∧
            ∀ (u : ℝ), 0 < u → u ≤ u₀ →
              ∀ (δsub δexp δadd : Fin n → ℝ) (δlog : ℝ),
                (∀ i ∈ order,
                  |δsub i| ≤ u ∧ |δexp i| ≤ u ∧ |δadd i| ≤ u) →
                |δlog| ≤ u →
                let s := shiftedSum x k order
                let y := x k + Real.log (1 + s)
                let yHat := intermediateValue x k order δsub δexp δadd δlog
                |y - yHat| ≤
                  (Real.log (1 + s) + s / (1 + s) *
                    ((n : ℝ) + x k - xmin)) * u + C * u ^ 2 := by
  sorry

end HighamBenchCandidate
