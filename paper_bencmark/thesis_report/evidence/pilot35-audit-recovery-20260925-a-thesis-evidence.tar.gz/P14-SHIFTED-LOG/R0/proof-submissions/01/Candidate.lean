import Mathlib

namespace HighamBenchCandidate

/-- An order containing each index other than the chosen maximum exactly once. -/
def ValidOrder {n : ℕ} (k : Fin n) (order : List (Fin n)) : Prop :=
  order.Nodup ∧ ∀ i : Fin n, i ∈ order ↔ i ≠ k

/-- The exact sum of the shifted exponential terms, in the selected order. -/
noncomputable def shiftedSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) : ℝ :=
  (order.map fun i => Real.exp (x i - x k)).sum

/-- A shifted exponential after relative errors in the subtraction and exponential. -/
noncomputable def computedTerm {n : ℕ} (x : Fin n → ℝ) (k i : Fin n)
    (δsub δexp : Fin n → ℝ) : ℝ :=
  Real.exp ((x i - x k) * (1 + δsub i)) * (1 + δexp i)

/-- Recursive accumulation, starting at zero, with a relative error at each addition. -/
noncomputable def computedSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) (δsub δexp δadd : Fin n → ℝ) : ℝ :=
  order.foldl
    (fun acc i => (acc + computedTerm x k i δsub δexp) * (1 + δadd i)) 0

/-- The value after the rounded log1p evaluation and before the final addition. -/
noncomputable def intermediateValue {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) (δsub δexp δadd : Fin n → ℝ)
    (δlog : ℝ) : ℝ :=
  x k + Real.log (1 + computedSum x k order δsub δexp δadd) * (1 + δlog)

private lemma shiftedSum_nonneg {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (order : List (Fin n)) : 0 ≤ shiftedSum x k order := by
  unfold shiftedSum
  apply List.sum_nonneg
  intro a ha
  obtain ⟨i, _, rfl⟩ := List.mem_map.mp ha
  exact (Real.exp_pos _).le

private lemma abs_exp_sub_one_le (z : ℝ) :
    |Real.exp z - 1| ≤ Real.exp |z| - 1 := by
  rcases le_total 0 z with hz | hz
  · rw [abs_of_nonneg hz]
    have h : 1 ≤ Real.exp z := by linarith [Real.add_one_le_exp z]
    rw [abs_of_nonneg (by linarith : 0 ≤ Real.exp z - 1)]
  · rw [abs_of_nonpos hz]
    have h : Real.exp z ≤ 1 := Real.exp_le_one_iff.mpr hz
    rw [abs_of_nonpos (by linarith : Real.exp z - 1 ≤ 0)]
    have h₁ := Real.add_one_le_exp z
    have h₂ := Real.add_one_le_exp (-z)
    linarith

private lemma term_error_bound (r R u δ₁ δ₂ : ℝ)
    (hu : 0 ≤ u) (hr : |r| ≤ R)
    (hδ₁ : |δ₁| ≤ u) (hδ₂ : |δ₂| ≤ u) :
    |Real.exp (r * (1 + δ₁)) * (1 + δ₂) - Real.exp r| ≤
      Real.exp r * (Real.exp ((R + 1) * u) - 1) := by
  have hR : 0 ≤ R := le_trans (abs_nonneg _) hr
  have hru : |r * δ₁| ≤ R * u := by
    rw [abs_mul]
    exact mul_le_mul hr hδ₁ (abs_nonneg _) hR
  have he : Real.exp (r * δ₁) ≤ Real.exp (R * u) :=
    Real.exp_le_exp.mpr (le_trans (le_abs_self _) hru)
  have he0 : 0 ≤ Real.exp (r * δ₁) := (Real.exp_pos _).le
  have hE0 : 0 ≤ Real.exp (R * u) := (Real.exp_pos _).le
  have habs : |Real.exp (r * δ₁) - 1| ≤ Real.exp (R * u) - 1 :=
    (abs_exp_sub_one_le _).trans (by gcongr)
  have hq : 1 + u ≤ Real.exp u := by simpa [add_comm] using Real.add_one_le_exp u
  have hm :
      |Real.exp (r * δ₁) * (1 + δ₂) - 1| ≤
        Real.exp (R * u) * (1 + u) - 1 := by
    have hid : Real.exp (r * δ₁) * (1 + δ₂) - 1 =
        (Real.exp (r * δ₁) - 1) + Real.exp (r * δ₁) * δ₂ := by ring
    rw [hid]
    calc
      _ ≤ |Real.exp (r * δ₁) - 1| + |Real.exp (r * δ₁) * δ₂| := abs_add_le _ _
      _ ≤ (Real.exp (R * u) - 1) + Real.exp (R * u) * u := by
        rw [abs_mul, abs_of_nonneg he0]
        gcongr
      _ = _ := by ring
  have hscale : Real.exp (R * u) * (1 + u) ≤ Real.exp ((R + 1) * u) := by
    calc
      _ ≤ Real.exp (R * u) * Real.exp u := by gcongr
      _ = _ := by rw [← Real.exp_add]; congr 1; ring
  have hmain :
      |Real.exp (r * δ₁) * (1 + δ₂) - 1| ≤
        Real.exp ((R + 1) * u) - 1 := by linarith
  have hid : r * (1 + δ₁) = r + r * δ₁ := by ring
  rw [hid, Real.exp_add]
  have hfactor : Real.exp r * (Real.exp (r * δ₁) * (1 + δ₂)) - Real.exp r =
      Real.exp r * (Real.exp (r * δ₁) * (1 + δ₂) - 1) := by ring
  rw [mul_assoc, hfactor, abs_mul, abs_of_nonneg (Real.exp_pos r).le]
  exact mul_le_mul_of_nonneg_left hmain (Real.exp_pos r).le

private lemma fold_error_bound {α : Type*} (w v δ : α → ℝ)
    (u p q : ℝ) (hu : 0 ≤ u) (hp : 1 ≤ p) (hq : 1 + u ≤ q)
    (l : List α)
    (hw : ∀ i ∈ l, 0 ≤ w i)
    (hv : ∀ i ∈ l, |v i - w i| ≤ w i * (p - 1))
    (hδ : ∀ i ∈ l, |δ i| ≤ u) :
    ∀ (P a A : ℝ), p ≤ P → 0 ≤ A → |a - A| ≤ A * (P - 1) →
      |l.foldl (fun acc i => (acc + v i) * (1 + δ i)) a -
        (A + (l.map w).sum)| ≤
        (A + (l.map w).sum) * (P * q ^ l.length - 1) := by
  induction l with
  | nil =>
      intro P a A hP hA ha
      simpa using ha
  | cons i l ih =>
      intro P a A hP hA ha
      have hwi : 0 ≤ w i := hw i (by simp)
      have hvi : |v i - w i| ≤ w i * (p - 1) := hv i (by simp)
      have hδi : |δ i| ≤ u := hδ i (by simp)
      have hq0 : 1 ≤ q := by linarith
      have hP0 : 0 ≤ P := by linarith
      have hPq : p ≤ P * q := by
        nlinarith [mul_nonneg (sub_nonneg.mpr hP) (sub_nonneg.mpr hq0),
          mul_nonneg hP0 (sub_nonneg.mpr hq0)]
      have hAw : 0 ≤ A + w i := by positivity
      have hsum : |a + v i| ≤ A + w i + |a - A| + |v i - w i| := by
        have heq : a + v i = (a - A) + (v i - w i) + (A + w i) := by ring
        rw [heq]
        calc
          _ ≤ |(a - A) + (v i - w i)| + |A + w i| := abs_add_le _ _
          _ ≤ |a - A| + |v i - w i| + (A + w i) := by
            rw [abs_of_nonneg hAw]
            linarith [abs_add_le (a - A) (v i - w i)]
          _ = _ := by ring
      have hstep :
          |(a + v i) * (1 + δ i) - (A + w i)| ≤
            (A + w i) * (P * q - 1) := by
        have hid : (a + v i) * (1 + δ i) - (A + w i) =
            (a - A) + (v i - w i) + δ i * (a + v i) := by ring
        have htri :
            |(a + v i) * (1 + δ i) - (A + w i)| ≤
              |a - A| + |v i - w i| + |δ i| * |a + v i| := by
          rw [hid]
          calc
            _ ≤ |(a - A) + (v i - w i)| + |δ i * (a + v i)| := abs_add_le _ _
            _ ≤ |a - A| + |v i - w i| + |δ i| * |a + v i| := by
              rw [abs_mul]
              linarith [abs_add_le (a - A) (v i - w i)]
        have habsδ : 0 ≤ |δ i| := abs_nonneg _
        have hmain :
            |(a + v i) * (1 + δ i) - (A + w i)| ≤
              (|a - A| + |v i - w i|) * (1 + u) + u * (A + w i) := by
          have hm := mul_le_mul_of_nonneg_left hsum habsδ
          have hm' := mul_le_mul_of_nonneg_right hδi
            (by positivity : 0 ≤ A + w i + |a - A| + |v i - w i|)
          nlinarith
        have hbound :
            (|a - A| + |v i - w i|) * (1 + u) + u * (A + w i) ≤
              (A * (P - 1) + w i * (p - 1)) * (1 + u) + u * (A + w i) := by
          gcongr
        have hmul₁ : P * (1 + u) ≤ P * q := by gcongr
        have hmul₂ : p * (1 + u) ≤ P * q := by
          calc
            _ ≤ P * (1 + u) := by gcongr
            _ ≤ P * q := hmul₁
        calc
          _ ≤ (|a - A| + |v i - w i|) * (1 + u) + u * (A + w i) := hmain
          _ ≤ (A * (P - 1) + w i * (p - 1)) * (1 + u) + u * (A + w i) := hbound
          _ ≤ (A + w i) * (P * q - 1) := by
            nlinarith [mul_nonneg hA (sub_nonneg.mpr hmul₁),
              mul_nonneg hwi (sub_nonneg.mpr hmul₂)]
      have htail := ih (fun j hj => hw j (by simp [hj]))
        (fun j hj => hv j (by simp [hj]))
        (fun j hj => hδ j (by simp [hj]))
        (P * q) ((a + v i) * (1 + δ i)) (A + w i) hPq hAw hstep
      simpa only [List.foldl_cons, List.map_cons, List.sum_cons,
        List.length_cons, pow_succ, mul_assoc, mul_comm, mul_left_comm,
        add_assoc] using htail

private lemma shifted_sum_error_bound {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (xmin : ℝ) (order : List (Fin n))
    (hmax : ∀ i, x i ≤ x k) (hmin : ∀ i, xmin ≤ x i)
    (horder : ValidOrder k order) (u : ℝ) (hu : 0 ≤ u)
    (δsub δexp δadd : Fin n → ℝ)
    (hδ : ∀ i ∈ order,
      |δsub i| ≤ u ∧ |δexp i| ≤ u ∧ |δadd i| ≤ u) :
    |computedSum x k order δsub δexp δadd - shiftedSum x k order| ≤
      shiftedSum x k order *
        (Real.exp (((n : ℝ) + x k - xmin) * u) - 1) := by
  let R : ℝ := x k - xmin
  have hR : 0 ≤ R := sub_nonneg.mpr (hmin k)
  have hlen : order.length + 1 ≤ n := by
    have hnot : k ∉ order := by
      intro hk
      exact ((horder.2 k).mp hk) rfl
    have hn : (k :: order).Nodup := List.nodup_cons.mpr ⟨hnot, horder.1⟩
    simpa using (hn.length_le_card : (k :: order).length ≤ Fintype.card (Fin n))
  have hlenR : (order.length : ℝ) + 1 ≤ (n : ℝ) := by exact_mod_cast hlen
  let w : Fin n → ℝ := fun i => Real.exp (x i - x k)
  let v : Fin n → ℝ := fun i => computedTerm x k i δsub δexp
  let p : ℝ := Real.exp ((R + 1) * u)
  let q : ℝ := Real.exp u
  have hp : 1 ≤ p := by
    dsimp [p]
    have ht : 0 ≤ (R + 1) * u := mul_nonneg (by linarith) hu
    exact Real.one_le_exp ht
  have hq : 1 + u ≤ q := by
    dsimp [q]
    simpa [add_comm] using Real.add_one_le_exp u
  have hw : ∀ i ∈ order, 0 ≤ w i := by
    intro i hi
    exact (Real.exp_pos _).le
  have hv : ∀ i ∈ order, |v i - w i| ≤ w i * (p - 1) := by
    intro i hi
    have hxi : |x i - x k| ≤ R := by
      rw [abs_of_nonpos (sub_nonpos.mpr (hmax i))]
      dsimp [R]
      linarith [hmin i]
    simpa [v, w, p, computedTerm] using
      term_error_bound (x i - x k) R u (δsub i) (δexp i) hu hxi
        (hδ i hi).1 (hδ i hi).2.1
  have hadd : ∀ i ∈ order, |δadd i| ≤ u := by
    intro i hi
    exact (hδ i hi).2.2
  have hfold := fold_error_bound w v δadd u p q hu hp hq order hw hv hadd
    p 0 0 le_rfl le_rfl (by simp)
  have heq : p * q ^ order.length =
      Real.exp ((R + 1 + order.length) * u) := by
    dsimp [p, q]
    rw [← Real.exp_nat_mul, ← Real.exp_add]
    congr 1
    push_cast
    ring
  have hexp : p * q ^ order.length ≤
      Real.exp (((n : ℝ) + x k - xmin) * u) := by
    rw [heq]
    apply Real.exp_le_exp.mpr
    apply mul_le_mul_of_nonneg_right _ hu
    dsimp [R]
    linarith
  have hs : 0 ≤ shiftedSum x k order := by
    unfold shiftedSum
    apply List.sum_nonneg
    intro a ha
    obtain ⟨i, _, rfl⟩ := List.mem_map.mp ha
    exact (Real.exp_pos _).le
  change |computedSum x k order δsub δexp δadd - shiftedSum x k order| ≤ _
  unfold computedSum shiftedSum
  simpa [w, v] using (hfold.trans (by
    simpa [w, v] using mul_le_mul_of_nonneg_left
      (sub_le_sub_right hexp 1) hs))

private lemma exp_sub_one_quadratic (t : ℝ) (ht : 0 ≤ t) (htsmall : t ≤ 1 / 2) :
    Real.exp t - 1 ≤ t + 2 * t ^ 2 := by
  have hpos : 0 < 1 - t := by linarith
  have hlog : t ≤ Real.log ((1 - t)⁻¹) := by
    rw [Real.log_inv]
    linarith [Real.log_le_sub_one_of_pos hpos]
  have hexp : Real.exp t ≤ (1 - t)⁻¹ := by
    have h := Real.exp_le_exp.mpr hlog
    rwa [Real.exp_log (inv_pos.mpr hpos)] at h
  have hpoly : (1 - t)⁻¹ ≤ 1 + t + 2 * t ^ 2 := by
    rw [inv_eq_one_div, div_le_iff₀ hpos]
    have haux : 0 ≤ t ^ 2 * (1 - 2 * t) :=
      mul_nonneg (sq_nonneg _) (by linarith)
    nlinarith
  linarith

private lemma abs_log_sub_log_le (A B : ℝ) (hA : 0 < A)
    (hsmall : |B - A| < A) :
    |Real.log B - Real.log A| ≤ |B - A| / (A - |B - A|) := by
  have hB : 0 < B := by linarith [neg_abs_le (B - A)]
  have hden : 0 < A - |B - A| := by linarith
  have hupper : Real.log B - Real.log A ≤ (B - A) / A := by
    have h := Real.log_le_sub_one_of_pos (div_pos hB hA)
    rw [Real.log_div (ne_of_gt hB) (ne_of_gt hA)] at h
    calc
      _ ≤ B / A - 1 := h
      _ = (B - A) / A := by field_simp
  have hlower : Real.log A - Real.log B ≤ (A - B) / B := by
    have h := Real.log_le_sub_one_of_pos (div_pos hA hB)
    rw [Real.log_div (ne_of_gt hA) (ne_of_gt hB)] at h
    calc
      _ ≤ A / B - 1 := h
      _ = (A - B) / B := by field_simp
  have hdenA : A - |B - A| ≤ A := by linarith [abs_nonneg (B - A)]
  have hdenB : A - |B - A| ≤ B := by linarith [neg_abs_le (B - A)]
  apply abs_le.mpr
  constructor
  · have hnum : A - B ≤ |B - A| := by linarith [neg_abs_le (B - A)]
    have hfrac : (A - B) / B ≤ |B - A| / (A - |B - A|) := by
      calc
        _ ≤ |B - A| / B := div_le_div_of_nonneg_right hnum hB.le
        _ ≤ _ := div_le_div_of_nonneg_left (abs_nonneg _) hden hdenB
    linarith
  · have hnum : B - A ≤ |B - A| := le_abs_self _
    have hfrac : (B - A) / A ≤ |B - A| / (A - |B - A|) := by
      calc
        _ ≤ |B - A| / A := div_le_div_of_nonneg_right hnum hA.le
        _ ≤ _ := div_le_div_of_nonneg_left (abs_nonneg _) hden hdenA
    linarith

private lemma shifted_log_error_bound (s sh e : ℝ) (hs : 0 ≤ s)
    (he : 0 ≤ e) (hesmall : e ≤ 1 / 2)
    (herr : |sh - s| ≤ s * e) :
    |Real.log (1 + sh) - Real.log (1 + s)| ≤
      (s / (1 + s)) * (e + 2 * e ^ 2) := by
  let A : ℝ := 1 + s
  let d : ℝ := |sh - s|
  have hA : 0 < A := by dsimp [A]; linarith
  have hd : 0 ≤ d := abs_nonneg _
  have hse : 0 ≤ s * e := mul_nonneg hs he
  have hAe : s * e ≤ A * e := by
    apply mul_le_mul_of_nonneg_right _ he
    dsimp [A]
    linarith
  have hden₂ : 0 < 1 - e := by linarith
  have hden₁ : 0 < A - s * e := by
    have hh : 0 < A * (1 - e) := mul_pos hA hden₂
    nlinarith
  have hden : 0 < A - d := by linarith
  have hlog : |Real.log (1 + sh) - Real.log (1 + s)| ≤ d / (A - d) := by
    have hh : |(1 + sh) - A| < A := by
      simpa [A, d] using (sub_pos.mp hden)
    simpa [A, d] using abs_log_sub_log_le A (1 + sh) hA hh
  have hfrac : d / (A - d) ≤ s * e / (A - s * e) := by
    apply (div_le_div_iff₀ hden hden₁).mpr
    nlinarith [mul_nonneg (sub_nonneg.mpr herr) hA.le]
  have hfrac₂ : s * e / (A - s * e) ≤ s * e / (A * (1 - e)) := by
    apply div_le_div_of_nonneg_left hse (mul_pos hA hden₂) ?_
    nlinarith
  have hefrac : e / (1 - e) ≤ e + 2 * e ^ 2 := by
    rw [div_le_iff₀ hden₂]
    have hh : 0 ≤ e ^ 2 * (1 - 2 * e) :=
      mul_nonneg (sq_nonneg _) (by linarith)
    nlinarith
  have hsdiv : 0 ≤ s / A := div_nonneg hs hA.le
  calc
    _ ≤ d / (A - d) := hlog
    _ ≤ s * e / (A - s * e) := hfrac
    _ ≤ s * e / (A * (1 - e)) := hfrac₂
    _ = (s / A) * (e / (1 - e)) := by field_simp
    _ ≤ (s / A) * (e + 2 * e ^ 2) := mul_le_mul_of_nonneg_left hefrac hsdiv
    _ = _ := rfl

theorem target :
    ∀ (n : ℕ) (_hn : 2 ≤ n) (x : Fin n → ℝ) (k : Fin n),
      (∀ i : Fin n, x i ≤ x k) →
      ∀ (xmin : ℝ),
        ((∀ i : Fin n, xmin ≤ x i) ∧ (∃ i : Fin n, x i = xmin)) →
        ∀ (order : List (Fin n)), ValidOrder k order →
          ∃ (C u₀ : ℝ), 0 ≤ C ∧ 0 < u₀ ∧
            ∀ (u : ℝ), 0 < u → u ≤ u₀ →
              ∀ (δsub δexp δadd : Fin n → ℝ) (δlog : ℝ),
                (∀ i ∈ order,
                  |δsub i| ≤ u ∧ |δexp i| ≤ u ∧ |δadd i| ≤ u) →
                |δlog| ≤ u →
                let s := shiftedSum x k order
                let y := x k + Real.log (1 + s)
                let yHat := intermediateValue x k order δsub δexp δadd δlog
                |y - yHat| ≤
                  (Real.log (1 + s) + s / (1 + s) *
                    ((n : ℝ) + x k - xmin)) * u + C * u ^ 2 := by
  intro n hn x k hmax xmin hmin order horder
  let B : ℝ := (n : ℝ) + x k - xmin
  have hnR : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hB : 0 < B := by
    dsimp [B]
    linarith [hmin.1 k]
  let K : ℝ := 10 * B ^ 2
  have hK : 0 ≤ K := by dsimp [K]; positivity
  let C : ℝ := 2 * K + B
  have hC : 0 ≤ C := by dsimp [C]; positivity
  let u₀ : ℝ := min 1 (1 / (4 * B))
  have hu₀ : 0 < u₀ := by
    dsimp [u₀]
    apply lt_min
    · norm_num
    · positivity
  refine ⟨C, u₀, hC, hu₀, ?_⟩
  intro u hu hu₀' δsub δexp δadd δlog hδ hδlog
  have hu1 : u ≤ 1 := le_trans hu₀' (by exact min_le_left _ _)
  have huB : u ≤ 1 / (4 * B) := le_trans hu₀' (by exact min_le_right _ _)
  let t : ℝ := B * u
  let e : ℝ := Real.exp t - 1
  have ht : 0 ≤ t := mul_nonneg hB.le hu.le
  have ht4 : t ≤ 1 / 4 := by
    dsimp [t]
    calc
      B * u ≤ B * (1 / (4 * B)) := mul_le_mul_of_nonneg_left huB hB.le
      _ = 1 / 4 := by field_simp
  have he : 0 ≤ e := by
    dsimp [e]
    linarith [Real.add_one_le_exp t]
  have heq : e ≤ t + 2 * t ^ 2 := exp_sub_one_quadratic t ht (by linarith)
  have hehalf : e ≤ 1 / 2 := by
    have ht2 : t ^ 2 ≤ (1 / 4 : ℝ) ^ 2 := by nlinarith
    nlinarith
  have he2 : e ≤ 2 * t := by
    have hh : 0 ≤ t * (1 - 2 * t) := mul_nonneg ht (by linarith)
    nlinarith
  have he2sq : e ^ 2 ≤ 4 * t ^ 2 := by
    have hh : 0 ≤ (2 * t - e) * (2 * t + e) :=
      mul_nonneg (by linarith) (by linarith)
    nlinarith
  let s : ℝ := shiftedSum x k order
  let sh : ℝ := computedSum x k order δsub δexp δadd
  have hs : 0 ≤ s := shiftedSum_nonneg x k order
  have herr : |sh - s| ≤ s * e := by
    simpa [s, sh, e, t, B] using
      shifted_sum_error_bound x k xmin order hmax hmin.1 horder u hu.le
        δsub δexp δadd hδ
  let α : ℝ := s / (1 + s)
  have hα : 0 ≤ α := by dsimp [α]; positivity
  have hα1 : α ≤ 1 := by
    dsimp [α]
    apply (div_le_iff₀ (by linarith : 0 < 1 + s)).mpr
    linarith
  let L : ℝ := |Real.log (1 + sh) - Real.log (1 + s)|
  have hL0 : 0 ≤ L := abs_nonneg _
  have hL : L ≤ α * B * u + K * u ^ 2 := by
    have hsum : e + 2 * e ^ 2 ≤ t + 10 * t ^ 2 := by
      nlinarith [he2sq]
    have hmul : α * (e + 2 * e ^ 2) ≤ α * (t + 10 * t ^ 2) :=
      mul_le_mul_of_nonneg_left hsum hα
    have hlast : α * (t + 10 * t ^ 2) ≤ α * B * u + K * u ^ 2 := by
      dsimp [t, K]
      nlinarith [mul_nonneg (sub_nonneg.mpr hα1)
        (show 0 ≤ 10 * B ^ 2 * u ^ 2 by positivity)]
    exact (shifted_log_error_bound s sh e hs he hehalf herr).trans (hmul.trans hlast)
  have hlog0 : 0 ≤ Real.log (1 + s) := Real.log_nonneg (by linarith)
  have hδone : |1 + δlog| ≤ 1 + u := by
    calc
      _ ≤ |(1 : ℝ)| + |δlog| := abs_add_le _ _
      _ ≤ 1 + u := by simpa using add_le_add_left hδlog 1
  have hfirst :
      |(x k + Real.log (1 + s)) -
          (x k + Real.log (1 + sh) * (1 + δlog))| ≤
        L * (1 + u) + Real.log (1 + s) * u := by
    let a : ℝ := Real.log (1 + s)
    let b : ℝ := Real.log (1 + sh)
    have hid : (x k + a) - (x k + b * (1 + δlog)) =
        (a - b) * (1 + δlog) - a * δlog := by ring
    have htri : |(x k + a) - (x k + b * (1 + δlog))| ≤
        |a - b| * |1 + δlog| + |a| * |δlog| := by
      rw [hid]
      calc
        _ ≤ |(a - b) * (1 + δlog)| + |a * δlog| := by
          simpa [sub_eq_add_neg] using
            (abs_add_le ((a - b) * (1 + δlog)) (-(a * δlog)))
        _ = _ := by rw [abs_mul, abs_mul]
    have hab : |a - b| = L := by dsimp [a, b, L]; rw [abs_sub_comm]
    have haa : |a| = a := abs_of_nonneg hlog0
    calc
      _ ≤ |a - b| * |1 + δlog| + |a| * |δlog| := htri
      _ ≤ L * (1 + u) + a * u := by
        rw [hab, haa]
        exact add_le_add
          (mul_le_mul_of_nonneg_left hδone hL0)
          (mul_le_mul_of_nonneg_left hδlog hlog0)
      _ = _ := rfl
  have hαB : α * B ≤ B := mul_le_of_le_one_left hB.le hα1
  have hu3 : u ^ 3 ≤ u ^ 2 := by
    have hh : 0 ≤ u ^ 2 * (1 - u) := mul_nonneg (sq_nonneg _) (by linarith)
    nlinarith
  have hsecond :
      L * (1 + u) + Real.log (1 + s) * u ≤
        (Real.log (1 + s) + α * B) * u + C * u ^ 2 := by
    have hmul := mul_le_mul_of_nonneg_right hL (by linarith : 0 ≤ 1 + u)
    have h₁ : α * B * u ^ 2 ≤ B * u ^ 2 :=
      mul_le_mul_of_nonneg_right hαB (sq_nonneg _)
    have h₂ : K * u ^ 3 ≤ K * u ^ 2 :=
      mul_le_mul_of_nonneg_left hu3 hK
    change L * (1 + u) + Real.log (1 + s) * u ≤
      (Real.log (1 + s) + α * B) * u + (2 * K + B) * u ^ 2
    nlinarith only [hmul, h₁, h₂]
  exact hfirst.trans hsecond

end HighamBenchCandidate
