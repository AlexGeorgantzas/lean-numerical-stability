import Mathlib

namespace HighamBenchCandidate

/-- The exact exponential term at a position before the selected maximum. -/
noncomputable def exactTerm {m : ℕ} (x : Fin (m + 1) → ℝ)
    (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1))) (i : Fin m) : ℝ :=
  Real.exp (x (p i.castSucc) - x k)

/-- Subtract, round the shifted argument, then evaluate and round the exponential. -/
noncomputable def computedTerm {m : ℕ} (x : Fin (m + 1) → ℝ)
    (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1)))
    (subErr expErr : Fin m → ℝ) (i : Fin m) : ℝ :=
  Real.exp ((x (p i.castSucc) - x k) * (1 + subErr i)) * (1 + expErr i)

/-- The additions performed in increasing position order, starting from zero. -/
noncomputable def computedSum {m : ℕ} (x : Fin (m + 1) → ℝ)
    (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1)))
    (subErr expErr addErr : Fin m → ℝ) : ℝ :=
  (List.finRange m).foldl
    (fun acc i => (acc + computedTerm x k p subErr expErr i) * (1 + addErr i)) 0

private noncomputable def run (n : ℕ) (c e : ℕ → ℝ) : ℝ :=
  (List.range n).foldl (fun acc i => (acc + c i) * (1 + e i)) 0

private def ideal (n : ℕ) (w : ℕ → ℝ) : ℝ :=
  ∑ i ∈ Finset.range n, w i

private def firstOrder (n : ℕ) (w b : ℕ → ℝ) : ℝ :=
  ∑ i ∈ Finset.range n, (b i + ((n - i : ℕ) : ℝ) * w i)

private lemma ideal_succ (n : ℕ) (w : ℕ → ℝ) :
    ideal (n + 1) w = ideal n w + w n := by
  simp [ideal, Finset.sum_range_succ]

private lemma run_succ (n : ℕ) (c e : ℕ → ℝ) :
    run (n + 1) c e = (run n c e + c n) * (1 + e n) := by
  simp [run, List.range_succ, List.foldl_append]

private lemma firstOrder_succ (n : ℕ) (w b : ℕ → ℝ) :
    firstOrder (n + 1) w b = firstOrder n w b + b n + ideal (n + 1) w := by
  unfold firstOrder ideal
  rw [Finset.sum_range_succ, Finset.sum_range_succ]
  have hsum :
      (∑ i ∈ Finset.range n, (b i + ((n + 1 - i : ℕ) : ℝ) * w i)) =
        (∑ i ∈ Finset.range n, (b i + ((n - i : ℕ) : ℝ) * w i)) +
          ∑ i ∈ Finset.range n, w i := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    have hi' : i ≤ n := Nat.le_of_lt (Finset.mem_range.mp hi)
    have he : n + 1 - i = n - i + 1 := by omega
    rw [he, Nat.cast_add]
    ring
  rw [hsum]
  simp
  ring

private lemma run_bound (w b K : ℕ → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hb : ∀ i, 0 ≤ b i) (hK : ∀ i, 0 ≤ K i) :
    ∀ n : ℕ, ∃ C : ℝ, 0 ≤ C ∧
      ∀ (u : ℝ) (c e : ℕ → ℝ), 0 ≤ u → u ≤ 1 →
        (∀ i < n, |c i - w i| ≤ u * b i + K i * u ^ 2) →
        (∀ i < n, |e i| ≤ u) →
        |run n c e - ideal n w| ≤ u * firstOrder n w b + C * u ^ 2 := by
  intro n
  induction n with
  | zero =>
      refine ⟨0, le_refl 0, ?_⟩
      intro u c e hu hu1 hc he
      simp [run, ideal, firstOrder]
  | succ n ih =>
      obtain ⟨C, hC, ih⟩ := ih
      have hS : 0 ≤ ideal (n + 1) w := by
        apply Finset.sum_nonneg
        intro i hi
        exact hw i
      have hB : 0 ≤ firstOrder n w b := by
        apply Finset.sum_nonneg
        intro i hi
        exact add_nonneg (hb i) (mul_nonneg (Nat.cast_nonneg _) (hw i))
      refine ⟨2 * (C + K n) + firstOrder n w b + b n,
        by nlinarith [hC, hK n, hB, hb n], ?_⟩
      intro u c e hu hu1 hc he
      have hprev := ih u c e hu hu1 (by
        intro i hi
        exact hc i (by omega)) (by
        intro i hi
        exact he i (by omega))
      have hterm := hc n (by omega)
      have herr := he n (by omega)
      let R := run n c e
      let S := ideal n w
      let B := firstOrder n w b
      let E := |R - S|
      let F := |c n - w n|
      have hEF : E + F ≤ u * (B + b n) + (C + K n) * u ^ 2 := by
        dsimp [E, F, R, S, B]
        nlinarith
      have hbase : |R + c n| ≤ ideal (n + 1) w + E + F := by
        have h1 := abs_add_le (R - S) (c n - w n)
        have h2 := abs_add_le ((R - S) + (c n - w n)) (ideal (n + 1) w)
        rw [abs_of_nonneg hS] at h2
        have heq : R + c n = (R - S) + (c n - w n) + ideal (n + 1) w := by
          rw [ideal_succ]
          ring
        rw [heq]
        dsimp [E, F]
        linarith
      have hmain :
          |run (n + 1) c e - ideal (n + 1) w| ≤ E + F + u * |R + c n| := by
        rw [run_succ, ideal_succ]
        have heq : (R + c n) * (1 + e n) - (S + w n) =
            (R - S) + (c n - w n) + e n * (R + c n) := by ring
        change |(R + c n) * (1 + e n) - (S + w n)| ≤ _
        rw [heq]
        calc
          _ ≤ |R - S| + |c n - w n| + |e n * (R + c n)| := by
            have h1 := abs_add_le (R - S) (c n - w n)
            have h2 := abs_add_le ((R - S) + (c n - w n)) (e n * (R + c n))
            linarith
          _ ≤ E + F + u * |R + c n| := by
            rw [abs_mul]
            simpa [E, F] using
              add_le_add_left (mul_le_mul_of_nonneg_right herr (abs_nonneg (R + c n)))
                (|R - S| + |c n - w n|)
      have hu2 : 0 ≤ u ^ 2 := sq_nonneg u
      have hcu : (C + K n) * u ^ 3 ≤ (C + K n) * u ^ 2 := by
        have hmul : 0 ≤ (C + K n) * (u ^ 2 * (1 - u)) :=
          mul_nonneg (add_nonneg hC (hK n)) (mul_nonneg hu2 (by linarith))
        nlinarith
      rw [firstOrder_succ]
      have hprod : u * |R + c n| ≤
          u * (ideal (n + 1) w + u * (B + b n) + (C + K n) * u ^ 2) :=
        mul_le_mul_of_nonneg_left (by linarith [hbase, hEF]) hu
      dsimp [B] at hEF hprod
      nlinarith [hmain, hEF, hprod, hcu]

private lemma exp_shift_bound (t d u : ℝ) (hu : 0 ≤ u)
    (hd : |d| ≤ u) (htu : |t| * u ≤ 1) :
    |Real.exp (t * (1 + d)) - Real.exp t| ≤
      Real.exp t * (|t| * u + t ^ 2 * u ^ 2) := by
  have hz : |t * d| ≤ |t| * u := by
    rw [abs_mul]
    exact mul_le_mul_of_nonneg_left hd (abs_nonneg t)
  have hz1 : |t * d| ≤ 1 := hz.trans htu
  have htaylor := Real.abs_exp_sub_one_sub_id_le hz1
  have hlin : |Real.exp (t * d) - 1| ≤ |t * d| + (t * d) ^ 2 := by
    have h := abs_add_le (Real.exp (t * d) - 1 - t * d) (t * d)
    have heq : Real.exp (t * d) - 1 - t * d + t * d = Real.exp (t * d) - 1 := by ring
    rw [heq] at h
    linarith
  have hzsq : (t * d) ^ 2 ≤ t ^ 2 * u ^ 2 := by
    have hh : 0 ≤ (|t| * u - |t * d|) * (|t| * u + |t * d|) :=
      mul_nonneg (sub_nonneg.mpr hz)
        (add_nonneg (mul_nonneg (abs_nonneg _) hu) (abs_nonneg _))
    nlinarith [sq_abs (t * d), sq_abs t]
  have hmain : |Real.exp (t * (1 + d)) - Real.exp t| =
      Real.exp t * |Real.exp (t * d) - 1| := by
    rw [show t * (1 + d) = t + t * d by ring, Real.exp_add]
    have heq : Real.exp t * Real.exp (t * d) - Real.exp t =
        Real.exp t * (Real.exp (t * d) - 1) := by ring
    rw [heq, abs_mul, abs_of_pos (Real.exp_pos t)]
  rw [hmain]
  have hbound : |Real.exp (t * d) - 1| ≤ |t| * u + t ^ 2 * u ^ 2 := by
    nlinarith [hlin, hz, hzsq]
  exact mul_le_mul_of_nonneg_left hbound (Real.exp_pos t).le

private lemma rounded_term_bound (t d e u : ℝ)
    (hu : 0 ≤ u) (hu1 : u ≤ 1) (hd : |d| ≤ u) (he : |e| ≤ u)
    (htu : |t| * u ≤ 1) :
    |Real.exp (t * (1 + d)) * (1 + e) - Real.exp t| ≤
      u * ((1 + |t|) * Real.exp t) +
        ((2 * t ^ 2 + |t|) * Real.exp t) * u ^ 2 := by
  let q := Real.exp (t * (1 + d))
  let w := Real.exp t
  have hw : 0 ≤ w := (Real.exp_pos t).le
  have hq : 0 ≤ q := (Real.exp_pos _).le
  have hshift := exp_shift_bound t d u hu hd htu
  have hqbound : |q| ≤ w + |q - w| := by
    have h := abs_add_le (q - w) w
    rw [abs_of_nonneg hw] at h
    have heq : q - w + w = q := by ring
    rw [heq] at h
    linarith
  have hstep : |q * (1 + e) - w| ≤ |q - w| + |q| * u := by
    have heq : q * (1 + e) - w = (q - w) + q * e := by ring
    rw [heq]
    calc
      _ ≤ |q - w| + |q * e| := abs_add_le _ _
      _ ≤ |q - w| + |q| * u := by
        rw [abs_mul]
        gcongr
  have hstep2 : |q * (1 + e) - w| ≤ (1 + u) * |q - w| + u * w := by
    nlinarith [hstep, mul_le_mul_of_nonneg_right hqbound hu]
  have hpos : 0 ≤ |t| * u + t ^ 2 * u ^ 2 := by positivity
  have hshift2 : |q - w| ≤ w * (|t| * u + t ^ 2 * u ^ 2) := hshift
  have hmul := mul_le_mul_of_nonneg_left hshift2 (by linarith : 0 ≤ 1 + u)
  have hu3 : u ^ 3 ≤ u ^ 2 := by
    have hh : 0 ≤ u ^ 2 * (1 - u) := mul_nonneg (sq_nonneg _) (by linarith)
    nlinarith
  have hprod : 0 ≤ w * t ^ 2 := mul_nonneg hw (sq_nonneg _)
  dsimp [q, w] at *
  nlinarith [hstep2, hmul, hu3, mul_nonneg hprod (sub_nonneg.mpr hu3)]

/-- Equation (4.5), with a remainder uniform in the admissible rounding errors. -/
theorem target :
    ∀ (m : ℕ) (x : Fin (m + 1) → ℝ) (k : Fin (m + 1))
      (p : Equiv.Perm (Fin (m + 1))),
      0 < m →
      (∀ j : Fin (m + 1), x j ≤ x k) →
      p (Fin.last m) = k →
      ∃ C : ℝ, 0 ≤ C ∧ ∃ u₀ : ℝ, 0 < u₀ ∧
        ∀ u : ℝ, 0 ≤ u → u ≤ u₀ →
          ∀ subErr expErr addErr : Fin m → ℝ,
            (∀ i : Fin m, |subErr i| ≤ u) →
            (∀ i : Fin m, |expErr i| ≤ u) →
            (∀ i : Fin m, |addErr i| ≤ u) →
            |computedSum x k p subErr expErr addErr -
                ∑ i : Fin m, exactTerm x k p i| ≤
              u * (∑ i : Fin m,
                (1 + x k - x (p i.castSucc) + ((m - i.val : ℕ) : ℝ)) *
                  exactTerm x k p i) + C * u ^ 2 := by
  intro m x k p hm hmax hp
  let idx : ℕ → Fin m := fun i => ⟨i % m, Nat.mod_lt i hm⟩
  have hidx (i : Fin m) : idx i.val = i := by
    apply Fin.ext
    simp [idx, Nat.mod_eq_of_lt i.isLt]
  let t : ℕ → ℝ := fun i => x (p (idx i).castSucc) - x k
  let w : ℕ → ℝ := fun i => Real.exp (t i)
  let b : ℕ → ℝ := fun i => (1 + |t i|) * w i
  let K : ℕ → ℝ := fun i => (2 * (t i) ^ 2 + |t i|) * w i
  have htneg (i : ℕ) : t i ≤ 0 := by
    dsimp [t]
    exact sub_nonpos.mpr (hmax _)
  have hw (i : ℕ) : 0 ≤ w i := (Real.exp_pos _).le
  have hb (i : ℕ) : 0 ≤ b i := by
    dsimp [b]
    positivity
  have hK (i : ℕ) : 0 ≤ K i := by
    dsimp [K]
    positivity
  obtain ⟨C, hC, hbound⟩ := run_bound w b K hw hb hK m
  let D : ℝ := ∑ i : Fin m, |t i.val|
  have hD : 0 ≤ D := Finset.sum_nonneg (fun i hi => abs_nonneg _)
  let u₀ : ℝ := 1 / (1 + D)
  have hden : 0 < 1 + D := by linarith
  have hu₀ : 0 < u₀ := by dsimp [u₀]; positivity
  have hu₀le : u₀ ≤ 1 := by
    dsimp [u₀]
    apply (div_le_iff₀ hden).2
    linarith
  have hu₀mul : (1 + D) * u₀ = 1 := by
    dsimp [u₀]
    field_simp
  refine ⟨C, hC, u₀, hu₀, ?_⟩
  intro u hu hu₀' subErr expErr addErr hsub hexp hadd
  let c : ℕ → ℝ := fun i => computedTerm x k p subErr expErr (idx i)
  let e : ℕ → ℝ := fun i => addErr (idx i)
  have hlocal : ∀ i < m, |c i - w i| ≤ u * b i + K i * u ^ 2 := by
    intro i hi
    have htle : |t i| ≤ D := by
      let j : Fin m := ⟨i, hi⟩
      change |t j.val| ≤ ∑ j : Fin m, |t j.val|
      exact Finset.single_le_sum (f := fun a : Fin m => |t a.val|)
        (fun a ha => abs_nonneg _) (Finset.mem_univ j)
    have htu : |t i| * u ≤ 1 := by
      calc
        |t i| * u ≤ |t i| * u₀ := mul_le_mul_of_nonneg_left hu₀' (abs_nonneg _)
        _ ≤ (1 + D) * u₀ :=
          mul_le_mul_of_nonneg_right (by linarith) hu₀.le
        _ = 1 := hu₀mul
    have hterm := rounded_term_bound (t i) (subErr (idx i)) (expErr (idx i)) u
      hu (hu₀'.trans hu₀le) (hsub _) (hexp _) htu
    simpa [c, w, b, K, computedTerm, t] using hterm
  have hround : ∀ i < m, |e i| ≤ u := by
    intro i hi
    exact hadd _
  have hrun : computedSum x k p subErr expErr addErr = run m c e := by
    unfold computedSum run
    rw [← List.map_coe_finRange_eq_range, List.foldl_map]
    congr 1
    funext acc i
    simp [c, e, hidx i]
  have hideal : ideal m w = ∑ i : Fin m, exactTerm x k p i := by
    unfold ideal
    rw [← Fin.sum_univ_eq_sum_range w m]
    apply Finset.sum_congr rfl
    intro i hi
    simp [w, t, exactTerm, hidx i]
  have hfirst : firstOrder m w b =
      ∑ i : Fin m,
        (1 + x k - x (p i.castSucc) + ((m - i.val : ℕ) : ℝ)) *
          exactTerm x k p i := by
    unfold firstOrder
    rw [← Fin.sum_univ_eq_sum_range
      (fun i => b i + ((m - i : ℕ) : ℝ) * w i) m]
    apply Finset.sum_congr rfl
    intro i hi
    have habs : |t i.val| = x k - x (p i.castSucc) := by
      rw [abs_of_nonpos (htneg i.val)]
      simp [t, hidx i]
    simp only [b, w, t, hidx i, exactTerm] at *
    rw [habs]
    ring
  simpa only [hrun, hideal, hfirst] using
    hbound u c e hu (hu₀'.trans hu₀le) hlocal hround

end HighamBenchCandidate
