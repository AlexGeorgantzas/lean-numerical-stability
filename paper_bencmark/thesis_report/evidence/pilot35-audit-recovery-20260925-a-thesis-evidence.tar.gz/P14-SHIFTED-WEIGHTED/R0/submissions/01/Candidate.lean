import Mathlib

namespace HighamBenchCandidate

/-- The exact exponential term at a position before the selected maximum. -/
noncomputable def exactTerm {m : ℕ} (x : Fin (m + 1) → ℝ)
    (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1))) (i : Fin m) : ℝ :=
  Real.exp (x (p i.castSucc) - x k)

/-- Subtract, round the shifted argument, then evaluate and round the exponential. -/
noncomputable def computedTerm {m : ℕ} (x : Fin (m + 1) → ℝ)
    (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1)))
    (subErr expErr : Fin m → ℝ) (i : Fin m) : ℝ :=
  Real.exp ((x (p i.castSucc) - x k) * (1 + subErr i)) * (1 + expErr i)

/-- The additions performed in increasing position order, starting from zero. -/
noncomputable def computedSum {m : ℕ} (x : Fin (m + 1) → ℝ)
    (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1)))
    (subErr expErr addErr : Fin m → ℝ) : ℝ :=
  (List.finRange m).foldl
    (fun acc i => (acc + computedTerm x k p subErr expErr i) * (1 + addErr i)) 0

/-- Equation (4.5), with a remainder uniform in the admissible rounding errors. -/
theorem target :
    ∀ (m : ℕ) (x : Fin (m + 1) → ℝ) (k : Fin (m + 1))
      (p : Equiv.Perm (Fin (m + 1))),
      0 < m →
      (∀ j : Fin (m + 1), x j ≤ x k) →
      p (Fin.last m) = k →
      ∃ C : ℝ, 0 ≤ C ∧ ∃ u₀ : ℝ, 0 < u₀ ∧
        ∀ u : ℝ, 0 ≤ u → u ≤ u₀ →
          ∀ subErr expErr addErr : Fin m → ℝ,
            (∀ i : Fin m, |subErr i| ≤ u) →
            (∀ i : Fin m, |expErr i| ≤ u) →
            (∀ i : Fin m, |addErr i| ≤ u) →
            |computedSum x k p subErr expErr addErr -
                ∑ i : Fin m, exactTerm x k p i| ≤
              u * (∑ i : Fin m,
                (1 + x k - x (p i.castSucc) + ((m - i.val : ℕ) : ℝ)) *
                  exactTerm x k p i) + C * u ^ 2 := by
  sorry

end HighamBenchCandidate
