import Mathlib.Data.Real.Basic
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Tactic
import NumStability.Analysis.Summation.ErrorBounds

namespace HighamBenchCandidate

open scoped BigOperators

/- The permutation records the chosen order of the inputs; its last position
   is occupied by the selected maximum. -/
private def orderedNonmax {m : ℕ} (x : Fin (m + 1) → ℝ)
    (p : Equiv.Perm (Fin (m + 1))) (i : Fin m) : ℝ :=
  x (p.symm i.castSucc)

private noncomputable def exactShiftedSum {m : ℕ}
    (x : Fin (m + 1) → ℝ) (p : Equiv.Perm (Fin (m + 1)))
    (k : Fin (m + 1)) : ℝ :=
  ∑ i : Fin m, Real.exp (orderedNonmax x p i - x k)

/- Each subtraction and exponential evaluation has its own relative-error
   factor, including when two shifted inputs happen to be equal. -/
private noncomputable def roundedShiftedTerm {m : ℕ}
    (x : Fin (m + 1) → ℝ) (p : Equiv.Perm (Fin (m + 1)))
    (k : Fin (m + 1)) (δsub δexp : Fin m → ℝ) (i : Fin m) : ℝ :=
  Real.exp ((orderedNonmax x p i - x k) * (1 + δsub i)) * (1 + δexp i)

/- Recursive accumulation in input order. The first addition to zero is
   exact; every subsequent addition has its own rounding factor. -/
private noncomputable def computedShiftedSum {m : ℕ}
    (x : Fin (m + 1) → ℝ) (p : Equiv.Perm (Fin (m + 1)))
    (k : Fin (m + 1)) (δsub δexp δadd : Fin m → ℝ) : ℝ :=
  Fin.foldl m
    (fun acc i =>
      if i.val = 0 then roundedShiftedTerm x p k δsub δexp i
      else (acc + roundedShiftedTerm x p k δsub δexp i) * (1 + δadd i))
    0

private lemma shiftedTerm_error (d u δsub δexp : ℝ)
    (hu : 0 ≤ u) (hu1 : u ≤ 1) (hdsmall : |d| * u ≤ 1)
    (hs : |δsub| ≤ u) (he : |δexp| ≤ u) :
    |Real.exp (d * (1 + δsub)) * (1 + δexp) - Real.exp d| ≤
      Real.exp d * ((1 + |d|) * u + (|d| + 2 * |d| ^ 2) * u ^ 2) := by
  have hz : |d * δsub| ≤ 1 := by
    calc
      |d * δsub| = |d| * |δsub| := abs_mul _ _
      _ ≤ |d| * u := mul_le_mul_of_nonneg_left hs (abs_nonneg _)
      _ ≤ 1 := hdsmall
  have hrem : |Real.exp (d * δsub) - 1 - d * δsub| ≤ (d * δsub) ^ 2 := by
    simpa [Real.norm_eq_abs, sq_abs] using
      (Real.norm_exp_sub_one_sub_id_le (by simpa [Real.norm_eq_abs] using hz))
  have hexp : Real.exp (d * (1 + δsub)) = Real.exp d * Real.exp (d * δsub) := by
    rw [show d * (1 + δsub) = d + d * δsub by ring, Real.exp_add]
  have hdiff : Real.exp (d * (1 + δsub)) * (1 + δexp) - Real.exp d =
      Real.exp d * (d * δsub + δexp + d * δsub * δexp +
        (Real.exp (d * δsub) - 1 - d * δsub) * (1 + δexp)) := by
    rw [hexp]
    ring
  have htri : |d * δsub + δexp + d * δsub * δexp +
        (Real.exp (d * δsub) - 1 - d * δsub) * (1 + δexp)| ≤
      |d * δsub| + |δexp| + |d * δsub| * |δexp| +
        |Real.exp (d * δsub) - 1 - d * δsub| * |1 + δexp| := by
    calc
      _ ≤ |d * δsub + δexp + d * δsub * δexp| +
          |(Real.exp (d * δsub) - 1 - d * δsub) * (1 + δexp)| := abs_add_le _ _
      _ ≤ (|d * δsub + δexp| + |d * δsub * δexp|) +
          |(Real.exp (d * δsub) - 1 - d * δsub) * (1 + δexp)| := by
            gcongr
            exact abs_add_le _ _
      _ ≤ |d * δsub| + |δexp| + |d * δsub| * |δexp| +
          |Real.exp (d * δsub) - 1 - d * δsub| * |1 + δexp| := by
        have hh : |d * δsub + δexp| ≤ |d| * |δsub| + |δexp| := by
          simpa only [abs_mul] using abs_add_le (d * δsub) δexp
        simp only [abs_mul]
        linarith
  have hone : |1 + δexp| ≤ 2 := by
    calc
      |1 + δexp| ≤ |(1 : ℝ)| + |δexp| := abs_add_le _ _
      _ ≤ 2 := by simp; linarith
  have hzbound : |d * δsub| ≤ |d| * u := by
    rw [abs_mul]
    exact mul_le_mul_of_nonneg_left hs (abs_nonneg _)
  have hcross : |d * δsub| * |δexp| ≤ |d| * u ^ 2 := by
    calc
      |d * δsub| * |δexp| ≤ (|d| * u) * u := by
        exact mul_le_mul hzbound he (abs_nonneg _) (mul_nonneg (abs_nonneg _) hu)
      _ = |d| * u ^ 2 := by ring
  have hsq : (d * δsub) ^ 2 ≤ |d| ^ 2 * u ^ 2 := by
    calc
      (d * δsub) ^ 2 = |d * δsub| ^ 2 := (sq_abs _).symm
      _ ≤ (|d| * u) ^ 2 := pow_le_pow_left₀ (abs_nonneg _) hzbound 2
      _ = |d| ^ 2 * u ^ 2 := by ring
  have hremprod : |Real.exp (d * δsub) - 1 - d * δsub| * |1 + δexp| ≤
      2 * |d| ^ 2 * u ^ 2 := by
    calc
      _ ≤ ((d * δsub) ^ 2) * 2 := by
        exact mul_le_mul hrem hone (abs_nonneg _) (sq_nonneg _)
      _ ≤ 2 * |d| ^ 2 * u ^ 2 := by nlinarith
  rw [hdiff, abs_mul, abs_of_pos (Real.exp_pos d)]
  apply mul_le_mul_of_nonneg_left _ (Real.exp_pos d).le
  calc
    _ ≤ |d * δsub| + |δexp| + |d * δsub| * |δexp| +
        |Real.exp (d * δsub) - 1 - d * δsub| * |1 + δexp| := htri
    _ ≤ (1 + |d|) * u + (|d| + 2 * |d| ^ 2) * u ^ 2 := by
      linarith [hzbound, he, hcross, hremprod]

private lemma gamma_quadratic (u : ℝ) (hu : 0 ≤ u) (r : ℕ)
    (hr : (r : ℝ) * u ≤ 1 / 2) :
    NumStability.gamma (NumStability.FPModel.exactWithUnitRoundoff u hu) r ≤
      (r : ℝ) * u + 2 * ((r : ℝ) * u) ^ 2 := by
  let a : ℝ := (r : ℝ) * u
  have ha : 0 ≤ a := mul_nonneg (Nat.cast_nonneg _) hu
  have ha1 : 0 ≤ 1 - 2 * a := by dsimp [a] at *; linarith
  have hden : 0 < 1 - a := by dsimp [a] at *; linarith
  change a / (1 - a) ≤ a + 2 * a ^ 2
  rw [div_le_iff₀ hden]
  nlinarith [mul_nonneg (sq_nonneg a) ha1]

private lemma combine_first_order
    (w y θ u A B R Q : ℝ)
    (hw : 0 ≤ w) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hR : 0 ≤ R) (hQ : 0 ≤ Q)
    (hy : |y - w| ≤ w * (A * u + B * u ^ 2))
    (hθ : |θ| ≤ R * u + Q * u ^ 2) :
    |y * (1 + θ) - w| ≤
      w * (A + R) * u + w * (B + Q + (A + B) * (R + Q)) * u ^ 2 := by
  have hu2 : u ^ 2 ≤ u := by nlinarith [sq_nonneg u]
  have hy' : |y - w| ≤ w * (A + B) * u := by
    calc
      |y - w| ≤ w * (A * u + B * u ^ 2) := hy
      _ ≤ w * (A + B) * u := by
        have : B * u ^ 2 ≤ B * u := mul_le_mul_of_nonneg_left hu2 hB
        nlinarith
  have hθ' : |θ| ≤ (R + Q) * u := by
    have : Q * u ^ 2 ≤ Q * u := mul_le_mul_of_nonneg_left hu2 hQ
    linarith
  have hcross : |y - w| * |θ| ≤ w * (A + B) * (R + Q) * u ^ 2 := by
    calc
      |y - w| * |θ| ≤ (w * (A + B) * u) * ((R + Q) * u) := by
        exact mul_le_mul hy' hθ' (abs_nonneg _) (by positivity)
      _ = w * (A + B) * (R + Q) * u ^ 2 := by ring
  have htri : |y * (1 + θ) - w| ≤ |y - w| + w * |θ| + |y - w| * |θ| := by
    have heq : y * (1 + θ) - w = (y - w) + w * θ + (y - w) * θ := by ring
    rw [heq]
    calc
      _ ≤ |(y - w) + w * θ| + |(y - w) * θ| := abs_add_le _ _
      _ ≤ (|y - w| + |w * θ|) + |(y - w) * θ| := by
        gcongr
        exact abs_add_le _ _
      _ = |y - w| + w * |θ| + |y - w| * |θ| := by
        rw [abs_mul, abs_mul, abs_of_nonneg hw]
  have hthetaw : w * |θ| ≤ w * (R * u + Q * u ^ 2) :=
    mul_le_mul_of_nonneg_left hθ hw
  calc
    |y * (1 + θ) - w| ≤ |y - w| + w * |θ| + |y - w| * |θ| := htri
    _ ≤ w * (A * u + B * u ^ 2) +
          w * (R * u + Q * u ^ 2) +
          w * (A + B) * (R + Q) * u ^ 2 := by linarith
    _ = w * (A + R) * u +
          w * (B + Q + (A + B) * (R + Q)) * u ^ 2 := by ring

private lemma abs_gap_le_sum {m : ℕ} (x : Fin (m + 1) → ℝ)
    (p : Equiv.Perm (Fin (m + 1))) (k : Fin (m + 1)) (i : Fin m) :
    |orderedNonmax x p i - x k| ≤
      2 * (∑ j : Fin (m + 1), |x j|) := by
  have hsingle (j : Fin (m + 1)) :
      |x j| ≤ ∑ t : Fin (m + 1), |x t| := by
    exact Finset.single_le_sum (s := Finset.univ)
      (fun t _ => abs_nonneg (x t)) (Finset.mem_univ j)
  have htri := abs_sub (orderedNonmax x p i) (x k)
  have hi := hsingle (p.symm i.castSucc)
  have hk := hsingle k
  dsimp [orderedNonmax] at htri ⊢
  linarith

private lemma first_exact_fold_expansion (m : ℕ) (v δadd : Fin m → ℝ)
    (u : ℝ) (hu : 0 ≤ u) (hmhalf : (m : ℝ) * u ≤ 1 / 2)
    (hadd : ∀ i, |δadd i| ≤ u) :
    ∃ θ : Fin m → ℝ,
      (∀ i, |θ i| ≤ ((m - i.val : ℕ) : ℝ) * u +
        2 * (((m - i.val : ℕ) : ℝ) * u) ^ 2) ∧
      Fin.foldl m
        (fun acc i => if i.val = 0 then v i
          else (acc + v i) * (1 + δadd i)) 0 =
        ∑ i : Fin m, v i * (1 + θ i) := by
  let δ : Fin m → ℝ := fun i => if i.val = 0 then 0 else δadd i
  let fp := NumStability.FPModel.exactWithUnitRoundoff u hu
  have hδ (i : Fin m) : |δ i| ≤ fp.u := by
    dsimp [δ, fp, NumStability.FPModel.exactWithUnitRoundoff]
    by_cases hi : i.val = 0
    · simp [hi, hu]
    · simpa [hi] using hadd i
  have hvalid (i : Fin m) : NumStability.gammaValid fp (m - i.val) := by
    have hle : ((m - i.val : ℕ) : ℝ) * u ≤ (m : ℝ) * u := by
      exact mul_le_mul_of_nonneg_right (Nat.cast_le.mpr (Nat.sub_le m i.val)) hu
    unfold NumStability.gammaValid
    dsimp [fp, NumStability.FPModel.exactWithUnitRoundoff]
    linarith
  have hexists (i : Fin m) :
      ∃ θ : ℝ, |θ| ≤
          (((m - i.val : ℕ) : ℝ) * u +
            2 * (((m - i.val : ℕ) : ℝ) * u) ^ 2) ∧
        NumStability.sumSuffixErrorProduct m δ i = 1 + θ := by
    obtain ⟨θ, hθ, heq⟩ :=
      NumStability.sumSuffixErrorProduct_exists_theta_le_gamma fp m δ hδ i (hvalid i)
    refine ⟨θ, ?_, heq⟩
    have hle : ((m - i.val : ℕ) : ℝ) * u ≤ 1 / 2 := by
      exact (mul_le_mul_of_nonneg_right
        (Nat.cast_le.mpr (Nat.sub_le m i.val)) hu).trans hmhalf
    have hγ := gamma_quadratic u hu (m - i.val) hle
    dsimp [fp] at hθ
    linarith
  let θ : Fin m → ℝ := fun i => Classical.choose (hexists i)
  have hθ (i : Fin m) : |θ i| ≤ ((m - i.val : ℕ) : ℝ) * u +
      2 * (((m - i.val : ℕ) : ℝ) * u) ^ 2 := by
    exact (Classical.choose_spec (hexists i)).1
  have hfactor (i : Fin m) :
      NumStability.sumSuffixErrorProduct m δ i = 1 + θ i :=
    (Classical.choose_spec (hexists i)).2
  have hfold : Fin.foldl m
        (fun acc i => if i.val = 0 then v i
          else (acc + v i) * (1 + δadd i)) 0 =
      Fin.foldl m (fun acc i => (acc + v i) * (1 + δ i)) 0 := by
    cases m with
    | zero => simp
    | succ n =>
      rw [Fin.foldl_succ, Fin.foldl_succ]
      simp only [Fin.val_zero, if_true, δ, zero_add, add_zero, mul_one]
      congr 1
  refine ⟨θ, hθ, ?_⟩
  rw [hfold]
  have h := NumStability.foldl_add_mul_one_add_suffix_expansion m v 0 δ
  rw [h]
  simp only [zero_mul, zero_add]
  apply Finset.sum_congr rfl
  intro i _
  rw [hfactor i]

private lemma shifted_pointwise_bound
    (d u δsub δexp θ r D M : ℝ)
    (hu : 0 ≤ u) (hu1 : u ≤ 1) (hdsmall : |d| * u ≤ 1)
    (hs : |δsub| ≤ u) (he : |δexp| ≤ u)
    (hθ : |θ| ≤ r * u + 2 * (r * u) ^ 2)
    (hd : d ≤ 0) (hD : |d| ≤ D) (hD0 : 0 ≤ D)
    (hr : 0 ≤ r) (hrM : r ≤ M) (hM : 0 ≤ M) :
    |(Real.exp (d * (1 + δsub)) * (1 + δexp)) * (1 + θ) - Real.exp d| ≤
      u * ((1 - d + r) * Real.exp d) +
      (D + 2 * D ^ 2 + 2 * M ^ 2 +
        (1 + D + (D + 2 * D ^ 2)) * (M + 2 * M ^ 2)) * u ^ 2 := by
  let A := 1 + |d|
  let B := |d| + 2 * |d| ^ 2
  let Q := 2 * r ^ 2
  let Amax := 1 + D
  let Bmax := D + 2 * D ^ 2
  let Qmax := 2 * M ^ 2
  let Kmax := Bmax + Qmax + (Amax + Bmax) * (M + Qmax)
  have hw : 0 ≤ Real.exp d := (Real.exp_pos d).le
  have hw1 : Real.exp d ≤ 1 := Real.exp_le_one_iff.mpr hd
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hQ : 0 ≤ Q := by dsimp [Q]; positivity
  have hterm :
      |Real.exp (d * (1 + δsub)) * (1 + δexp) - Real.exp d| ≤
        Real.exp d * (A * u + B * u ^ 2) := by
    simpa [A, B] using shiftedTerm_error d u δsub δexp hu hu1 hdsmall hs he
  have hθ' : |θ| ≤ r * u + Q * u ^ 2 := by
    convert hθ using 1 <;> dsimp [Q] <;> ring
  have hcombined := combine_first_order
    (Real.exp d) (Real.exp (d * (1 + δsub)) * (1 + δexp))
    θ u A B r Q hw hu hu1 hA hB hr hQ hterm hθ'
  have hAle : A ≤ Amax := by dsimp [A, Amax]; linarith
  have hBle : B ≤ Bmax := by
    have hsq : |d| ^ 2 ≤ D ^ 2 := pow_le_pow_left₀ (abs_nonneg _) hD 2
    dsimp [B, Bmax]
    linarith
  have hQle : Q ≤ Qmax := by
    have hsq : r ^ 2 ≤ M ^ 2 := pow_le_pow_left₀ hr hrM 2
    dsimp [Q, Qmax]
    linarith
  have hKnonneg : 0 ≤ B + Q + (A + B) * (r + Q) := by positivity
  have hKle : Real.exp d * (B + Q + (A + B) * (r + Q)) ≤ Kmax := by
    have hmult : (A + B) * (r + Q) ≤ (Amax + Bmax) * (M + Qmax) := by
      exact mul_le_mul (add_le_add hAle hBle) (add_le_add hrM hQle)
        (add_nonneg hr hQ) (by dsimp [Amax, Bmax]; positivity)
    have hleft : Real.exp d * (B + Q + (A + B) * (r + Q)) ≤
        B + Q + (A + B) * (r + Q) := by
      nlinarith [mul_nonneg (sub_nonneg.mpr hw1) hKnonneg]
    dsimp [Kmax]
    linarith
  have hgap : A = 1 - d := by dsimp [A]; rw [abs_of_nonpos hd]; ring
  calc
    |(Real.exp (d * (1 + δsub)) * (1 + δexp)) * (1 + θ) - Real.exp d|
        ≤ Real.exp d * (A + r) * u +
            Real.exp d * (B + Q + (A + B) * (r + Q)) * u ^ 2 := hcombined
    _ ≤ u * ((1 - d + r) * Real.exp d) + Kmax * u ^ 2 := by
      rw [hgap]
      rw [hgap] at hKle
      have : 0 ≤ u ^ 2 := sq_nonneg u
      nlinarith [mul_nonneg (sub_nonneg.mpr hKle) this]
    _ = _ := by dsimp [Kmax, Amax, Bmax, Qmax]

/- Equation (4.5), with n = m + 1 and paper index i = Lean index i.val + 1.
   The asymptotic remainder is uniform over all admissible local-error runs
   for each fixed input and ordering. -/
theorem target :
    ∀ (m : ℕ) (hm : 0 < m) (x : Fin (m + 1) → ℝ),
      ∃ C ε : ℝ, 0 ≤ C ∧ 0 < ε ∧
        ∀ (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1))),
          (∀ j : Fin (m + 1), x j ≤ x k) →
          p k = Fin.last m →
        ∀ (u : ℝ), 0 ≤ u → u ≤ ε →
          ∀ (δsub δexp δadd : Fin m → ℝ),
            (∀ i, |δsub i| ≤ u) →
            (∀ i, |δexp i| ≤ u) →
            (∀ i, |δadd i| ≤ u) →
            |computedShiftedSum x p k δsub δexp δadd -
                exactShiftedSum x p k| ≤
              u * (∑ i : Fin m,
                (1 + x k - orderedNonmax x p i +
                  ((m - i.val : ℕ) : ℝ)) *
                  Real.exp (orderedNonmax x p i - x k)) + C * u ^ 2 := by
  intro m hm x
  let S : ℝ := ∑ j : Fin (m + 1), |x j|
  let D : ℝ := 2 * S
  let M : ℝ := (m : ℝ)
  let K : ℝ := D + 2 * D ^ 2 + 2 * M ^ 2 +
    (1 + D + (D + 2 * D ^ 2)) * (M + 2 * M ^ 2)
  let C : ℝ := M * K
  let den : ℝ := 1 + 2 * M + D
  let ε : ℝ := 1 / den
  have hS : 0 ≤ S := Finset.sum_nonneg (fun i _ => abs_nonneg (x i))
  have hD : 0 ≤ D := by dsimp [D]; positivity
  have hM : 0 ≤ M := by dsimp [M]; positivity
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hC : 0 ≤ C := mul_nonneg hM hK
  have hden : 0 < den := by dsimp [den]; linarith
  have hε : 0 < ε := div_pos one_pos hden
  refine ⟨C, ε, hC, hε, ?_⟩
  intro k p hmax _hlast u hu huε δsub δexp δadd hsub hexp hadd
  have hbudget : u * den ≤ 1 := by
    dsimp [ε] at huε
    exact (le_div_iff₀ hden).mp huε
  have hu1 : u ≤ 1 := by
    have hden1 : 1 ≤ den := by dsimp [den]; linarith
    nlinarith [mul_nonneg hu (sub_nonneg.mpr hden1)]
  have hmhalf : M * u ≤ 1 / 2 := by
    have hden2 : 2 * M ≤ den := by dsimp [den]; linarith
    nlinarith [mul_nonneg hu (sub_nonneg.mpr hden2)]
  let d : Fin m → ℝ := fun i => orderedNonmax x p i - x k
  let w : Fin m → ℝ := fun i => Real.exp (d i)
  let y : Fin m → ℝ := fun i => roundedShiftedTerm x p k δsub δexp i
  let R : Fin m → ℝ := fun i => ((m - i.val : ℕ) : ℝ)
  have hdle (i : Fin m) : |d i| ≤ D := by
    simpa [d, D, S] using abs_gap_le_sum x p k i
  have hdnonpos (i : Fin m) : d i ≤ 0 := by
    dsimp [d]
    exact sub_nonpos.mpr (hmax (p.symm i.castSucc))
  have hdsmall (i : Fin m) : |d i| * u ≤ 1 := by
    have hDden : D ≤ den := by dsimp [den]; linarith
    have hdiff : 0 ≤ den - |d i| := by linarith [hdle i]
    nlinarith [mul_nonneg hu hdiff]
  have hR0 (i : Fin m) : 0 ≤ R i := by dsimp [R]; positivity
  have hRM (i : Fin m) : R i ≤ M := by
    dsimp [R, M]
    exact_mod_cast Nat.sub_le m i.val
  obtain ⟨θ, hθ, hfold⟩ :=
    first_exact_fold_expansion m y δadd u hu (by simpa [M] using hmhalf) hadd
  have hcomputed : computedShiftedSum x p k δsub δexp δadd =
      ∑ i : Fin m, y i * (1 + θ i) := by
    exact hfold
  have hexact : exactShiftedSum x p k = ∑ i : Fin m, w i := rfl
  have hpoint (i : Fin m) :
      |y i * (1 + θ i) - w i| ≤
        u * ((1 - d i + R i) * w i) + K * u ^ 2 := by
    have hlocal := shifted_pointwise_bound (d i) u (δsub i) (δexp i)
      (θ i) (R i) D M hu hu1 (hdsmall i) (hsub i) (hexp i)
      (by simpa [R] using hθ i) (hdnonpos i) (hdle i) hD
      (hR0 i) (hRM i) hM
    simpa [y, w, d, R, roundedShiftedTerm, K] using hlocal
  calc
    |computedShiftedSum x p k δsub δexp δadd - exactShiftedSum x p k|
        = |∑ i : Fin m, (y i * (1 + θ i) - w i)| := by
            rw [hcomputed, hexact, Finset.sum_sub_distrib]
    _ ≤ ∑ i : Fin m, |y i * (1 + θ i) - w i| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i : Fin m, (u * ((1 - d i + R i) * w i) + K * u ^ 2) :=
      Finset.sum_le_sum (fun i _ => hpoint i)
    _ = u * (∑ i : Fin m, (1 - d i + R i) * w i) + C * u ^ 2 := by
      simp [Finset.sum_add_distrib, Finset.mul_sum, C, M]
      ring
    _ = u * (∑ i : Fin m,
          (1 + x k - orderedNonmax x p i + ((m - i.val : ℕ) : ℝ)) *
            Real.exp (orderedNonmax x p i - x k)) + C * u ^ 2 := by
      congr 1
      congr 1
      apply Finset.sum_congr rfl
      intro i _
      dsimp [d, w, R]
      ring

end HighamBenchCandidate
