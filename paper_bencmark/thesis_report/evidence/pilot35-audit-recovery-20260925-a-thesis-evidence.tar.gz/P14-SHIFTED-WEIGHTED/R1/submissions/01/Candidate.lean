import Mathlib.Data.Real.Basic
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Algebra.BigOperators.Fin

namespace HighamBenchCandidate

open scoped BigOperators

/- The permutation records the chosen order of the inputs; its last position
   is occupied by the selected maximum. -/
private def orderedNonmax {m : ℕ} (x : Fin (m + 1) → ℝ)
    (p : Equiv.Perm (Fin (m + 1))) (i : Fin m) : ℝ :=
  x (p.symm i.castSucc)

private noncomputable def exactShiftedSum {m : ℕ}
    (x : Fin (m + 1) → ℝ) (p : Equiv.Perm (Fin (m + 1)))
    (k : Fin (m + 1)) : ℝ :=
  ∑ i : Fin m, Real.exp (orderedNonmax x p i - x k)

/- Each subtraction and exponential evaluation has its own relative-error
   factor, including when two shifted inputs happen to be equal. -/
private noncomputable def roundedShiftedTerm {m : ℕ}
    (x : Fin (m + 1) → ℝ) (p : Equiv.Perm (Fin (m + 1)))
    (k : Fin (m + 1)) (δsub δexp : Fin m → ℝ) (i : Fin m) : ℝ :=
  Real.exp ((orderedNonmax x p i - x k) * (1 + δsub i)) * (1 + δexp i)

/- Recursive accumulation in input order. The first addition to zero is
   exact; every subsequent addition has its own rounding factor. -/
private noncomputable def computedShiftedSum {m : ℕ}
    (x : Fin (m + 1) → ℝ) (p : Equiv.Perm (Fin (m + 1)))
    (k : Fin (m + 1)) (δsub δexp δadd : Fin m → ℝ) : ℝ :=
  Fin.foldl m
    (fun acc i =>
      if i.val = 0 then roundedShiftedTerm x p k δsub δexp i
      else (acc + roundedShiftedTerm x p k δsub δexp i) * (1 + δadd i))
    0

/- Equation (4.5), with n = m + 1 and paper index i = Lean index i.val + 1.
   The asymptotic remainder is uniform over all admissible local-error runs
   for each fixed input and ordering. -/
theorem target :
    ∀ (m : ℕ) (hm : 0 < m) (x : Fin (m + 1) → ℝ),
      ∃ C ε : ℝ, 0 ≤ C ∧ 0 < ε ∧
        ∀ (k : Fin (m + 1)) (p : Equiv.Perm (Fin (m + 1))),
          (∀ j : Fin (m + 1), x j ≤ x k) →
          p k = Fin.last m →
        ∀ (u : ℝ), 0 ≤ u → u ≤ ε →
          ∀ (δsub δexp δadd : Fin m → ℝ),
            (∀ i, |δsub i| ≤ u) →
            (∀ i, |δexp i| ≤ u) →
            (∀ i, |δadd i| ≤ u) →
            |computedShiftedSum x p k δsub δexp δadd -
                exactShiftedSum x p k| ≤
              u * (∑ i : Fin m,
                (1 + x k - orderedNonmax x p i +
                  ((m - i.val : ℕ) : ℝ)) *
                  Real.exp (orderedNonmax x p i - x k)) + C * u ^ 2 := by
  sorry

end HighamBenchCandidate
