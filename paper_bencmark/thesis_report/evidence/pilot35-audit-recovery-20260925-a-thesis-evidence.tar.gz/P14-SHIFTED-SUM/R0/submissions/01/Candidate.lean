import Mathlib

namespace HighamBenchCandidate

/-- The indices left after removing the selected occurrence of the maximum,
    in their original order. -/
def otherIndices (n : ℕ) (k : Fin n) : List (Fin n) :=
  (List.finRange n).filter (fun i => i ≠ k)

/-- The exact sum in (4.4). -/
noncomputable def exactSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n) : ℝ :=
  ((otherIndices n k).map (fun i => Real.exp (x i - x k))).sum

/-- A shifted exponential computed by a rounded subtraction followed by a
    relative-error exponential evaluation. -/
noncomputable def computedTerm {n : ℕ} (x : Fin n → ℝ) (k i : Fin n)
    (subError expError : Fin n → ℝ) : ℝ :=
  Real.exp ((x i - x k) * (1 + subError i)) * (1 + expError i)

/-- Start with the first term, then perform one rounded addition for each
    subsequent term. -/
def roundedSum : List ℝ → List ℝ → ℝ
  | [], _ => 0
  | w :: ws, errors =>
      (ws.zip errors).foldl (fun acc p => (acc + p.1) * (1 + p.2)) w

/-- The computed sum, with one addition error for each of the `n - 2`
    additions among the `n - 1` retained terms. -/
noncomputable def computedSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (subError expError : Fin n → ℝ) (addError : Fin (n - 2) → ℝ) : ℝ :=
  roundedSum
    ((otherIndices n k).map (fun i => computedTerm x k i subError expError))
    (List.ofFn addError)

/-- The minimum input value. -/
noncomputable def inputMin {n : ℕ} (x : Fin n → ℝ) (k : Fin n) : ℝ :=
  Finset.univ.inf' ⟨k, Finset.mem_univ k⟩ x

/-- Equation (4.6), with the `O(u²)` term uniform over all admissible local
    rounding errors for each fixed input and chosen maximum. -/
theorem target :
    ∀ (n : ℕ) (hn : 2 ≤ n) (x : Fin n → ℝ) (k : Fin n),
      (∀ i : Fin n, x i ≤ x k) →
      let s := exactSum x k
      0 < s ∧
        ∃ (C u₀ : ℝ), 0 ≤ C ∧ 0 < u₀ ∧
          ∀ (u : ℝ), 0 ≤ u → u ≤ u₀ →
            ∀ (subError expError : Fin n → ℝ)
              (addError : Fin (n - 2) → ℝ),
              (∀ i, |subError i| ≤ u) →
              (∀ i, |expError i| ≤ u) →
              (∀ j, |addError j| ≤ u) →
              |computedSum x k subError expError addError - s| / s ≤
                ((n : ℝ) + x k - inputMin x k) * u + C * u ^ 2 := by
  sorry

end HighamBenchCandidate
