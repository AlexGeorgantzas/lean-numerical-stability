import Mathlib

namespace HighamBenchCandidate

/-- The indices left after removing the selected occurrence of the maximum,
    in their original order. -/
def otherIndices (n : ℕ) (k : Fin n) : List (Fin n) :=
  (List.finRange n).filter (fun i => i ≠ k)

/-- The exact sum in (4.4). -/
noncomputable def exactSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n) : ℝ :=
  ((otherIndices n k).map (fun i => Real.exp (x i - x k))).sum

/-- A shifted exponential computed by a rounded subtraction followed by a
    relative-error exponential evaluation. -/
noncomputable def computedTerm {n : ℕ} (x : Fin n → ℝ) (k i : Fin n)
    (subError expError : Fin n → ℝ) : ℝ :=
  Real.exp ((x i - x k) * (1 + subError i)) * (1 + expError i)

/-- Start with the first term, then perform one rounded addition for each
    subsequent term. -/
def roundedSum : List ℝ → List ℝ → ℝ
  | [], _ => 0
  | w :: ws, errors =>
      (ws.zip errors).foldl (fun acc p => (acc + p.1) * (1 + p.2)) w

/-- The computed sum, with one addition error for each of the `n - 2`
    additions among the `n - 1` retained terms. -/
noncomputable def computedSum {n : ℕ} (x : Fin n → ℝ) (k : Fin n)
    (subError expError : Fin n → ℝ) (addError : Fin (n - 2) → ℝ) : ℝ :=
  roundedSum
    ((otherIndices n k).map (fun i => computedTerm x k i subError expError))
    (List.ofFn addError)

/-- The minimum input value. -/
noncomputable def inputMin {n : ℕ} (x : Fin n → ℝ) (k : Fin n) : ℝ :=
  Finset.univ.inf' ⟨k, Finset.mem_univ k⟩ x

private theorem round_step {a b c d u α β e : ℝ}
    (ha : 0 ≤ a) (hc : 0 ≤ c) (hu : 0 ≤ u)
    (hαβ : α ≤ β) (hb : |b - a| ≤ β * a)
    (hd : |d - c| ≤ α * c) (he : |e| ≤ u) :
    |(b + d) * (1 + e) - (a + c)| ≤
      ((1 + β) * (1 + u) - 1) * (a + c) := by
  have hdc : |d - c| ≤ β * c := hd.trans (mul_le_mul_of_nonneg_right hαβ hc)
  have hsum : |(b + d) - (a + c)| ≤ β * (a + c) := by
    calc
      |(b + d) - (a + c)| = |(b - a) + (d - c)| := by ring
      _ ≤ |b - a| + |d - c| := abs_add_le _ _
      _ ≤ β * a + β * c := add_le_add hb hdc
      _ = β * (a + c) := by ring
  have ht : 0 ≤ a + c := add_nonneg ha hc
  have habs : |b + d| ≤ (1 + β) * (a + c) := by
    calc
      |b + d| = |((b + d) - (a + c)) + (a + c)| := by ring
      _ ≤ |(b + d) - (a + c)| + |a + c| := abs_add_le _ _
      _ ≤ β * (a + c) + (a + c) := by simpa [abs_of_nonneg ht] using add_le_add_right hsum (a+c)
      _ = (1 + β) * (a + c) := by ring
  have hmul : |(b + d) * e| ≤ (1 + β) * (a + c) * u := by
    rw [abs_mul]
    exact mul_le_mul habs he (abs_nonneg _) (by nlinarith [habs, abs_nonneg (b+d)])
  calc
    |(b + d) * (1 + e) - (a + c)| = |(b + d - (a + c)) + (b + d) * e| := by ring
    _ ≤ |b + d - (a + c)| + |(b + d) * e| := abs_add_le _ _
    _ ≤ β * (a + c) + (1 + β) * (a + c) * u := add_le_add hsum hmul
    _ = ((1 + β) * (1 + u) - 1) * (a + c) := by ring

private theorem fold_bound (l : List (ℝ × ℝ)) :
    ∀ (errors : List ℝ) (a b u α : ℝ),
      errors.length = l.length → 0 ≤ a → 0 ≤ u → 0 ≤ α →
      |b - a| ≤ α * a →
      (∀ p ∈ l, 0 ≤ p.1 ∧ |p.2 - p.1| ≤ α * p.1) →
      (∀ e ∈ errors, |e| ≤ u) →
      |(l.zip errors).foldl (fun t pe => (t + pe.1.2) * (1 + pe.2)) b -
        (a + (l.map Prod.fst).sum)| ≤
        ((1 + α) * (1 + u) ^ l.length - 1) *
          (a + (l.map Prod.fst).sum) := by
  induction l with
  | nil =>
      intro errors a b u α hlen ha hu hα hb hp he
      cases errors with
      | nil => simpa using hb
      | cons e es => simp at hlen
  | cons p ps ih =>
      intro errors a b u α hlen ha hu hα hb hp he
      cases errors with
      | nil => simp at hlen
      | cons e es =>
          have hlen' : es.length = ps.length := by simpa using hlen
          have hp0 := hp p (by simp)
          have hp' : ∀ q ∈ ps, 0 ≤ q.1 ∧ |q.2 - q.1| ≤ α * q.1 := by
            intro q hq
            exact hp q (by simp [hq])
          have he0 : |e| ≤ u := he e (by simp)
          have he' : ∀ f ∈ es, |f| ≤ u := by
            intro f hf
            exact he f (by simp [hf])
          let β : ℝ := (1 + α) * (1 + u) - 1
          have hαβ : α ≤ β := by
            dsimp [β]
            nlinarith [mul_nonneg hα hu]
          have hβ : 0 ≤ β := le_trans hα hαβ
          have hnew : |(b + p.2) * (1 + e) - (a + p.1)| ≤ β * (a + p.1) :=
            round_step ha hp0.1 hu (le_refl α) hb hp0.2 he0
          have hpβ : ∀ q ∈ ps, 0 ≤ q.1 ∧ |q.2 - q.1| ≤ β * q.1 := by
            intro q hq
            rcases hp' q hq with ⟨hq0, hqerr⟩
            exact ⟨hq0, hqerr.trans (mul_le_mul_of_nonneg_right hαβ hq0)⟩
          have hrec := ih es (a + p.1) ((b + p.2) * (1 + e)) u β
            hlen' (add_nonneg ha hp0.1) hu hβ hnew hpβ he'
          simp only [List.zip_cons_cons, List.foldl_cons, List.map_cons,
            List.sum_cons, List.length_cons, pow_succ]
          dsimp [β] at hrec
          convert hrec using 1 <;> ring

private theorem exp_factor_error {t u δ₁ δ₂ : ℝ}
    (ht : 0 ≤ t) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (htu : t * u ≤ 1) (hδ₁ : |δ₁| ≤ u) (hδ₂ : |δ₂| ≤ u) :
    |Real.exp (-t * δ₁) * (1 + δ₂) - 1| ≤
      (t + 1) * u + (2 * t ^ 2 + t) * u ^ 2 := by
  let z : ℝ := -t * δ₁
  have hzabs : |z| ≤ t * u := by
    dsimp [z]
    rw [abs_mul, abs_neg, abs_of_nonneg ht]
    exact mul_le_mul_of_nonneg_left hδ₁ ht
  have hz1 : |z| ≤ 1 := hzabs.trans htu
  have hzsq : z ^ 2 ≤ t ^ 2 * u ^ 2 := by
    nlinarith [sq_nonneg (t*u-|z|), sq_nonneg (t*u+|z|), sq_abs z,
      mul_nonneg (sub_nonneg.mpr hzabs) (add_nonneg (mul_nonneg ht hu) (abs_nonneg z))]
  have hexp : |Real.exp z - 1| ≤ t*u + t^2*u^2 := by
    have h := Real.abs_exp_sub_one_sub_id_le hz1
    have htri : |Real.exp z - 1| ≤ |Real.exp z - 1 - z| + |z| := by
      calc
        |Real.exp z - 1| = |(Real.exp z - 1 - z) + z| := by ring
        _ ≤ _ := abs_add_le _ _
    linarith
  have hdabs : |1 + δ₂| ≤ 1 + u := by
    calc
      |1 + δ₂| ≤ |(1:ℝ)| + |δ₂| := abs_add_le _ _
      _ ≤ 1 + u := by simpa using add_le_add_left hδ₂ 1
  have h0 : 0 ≤ t*u + t^2*u^2 := by positivity
  have hmul : |Real.exp z - 1| * |1 + δ₂| ≤
      (t*u+t^2*u^2)*(1+u) := by
    exact mul_le_mul hexp hdabs (abs_nonneg _) h0
  have htri : |Real.exp z * (1+δ₂)-1| ≤
      |Real.exp z - 1| * |1+δ₂| + |δ₂| := by
    calc
      |Real.exp z * (1+δ₂)-1| = |(Real.exp z-1)*(1+δ₂)+δ₂| := by ring
      _ ≤ |(Real.exp z-1)*(1+δ₂)|+|δ₂| := abs_add_le _ _
      _ = _ := by rw [abs_mul]
  have hextra : t^2*u^2*u ≤ t^2*u^2 := by
    exact mul_le_of_le_one_right (by positivity) hu1
  dsimp [z] at htri
  linarith [htri, hmul]

private theorem term_error {n : ℕ} (x : Fin n → ℝ) (k i : Fin n)
    (hmax : x i ≤ x k) (u : ℝ) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hMu : (x k - inputMin x k) * u ≤ 1)
    (subError expError : Fin n → ℝ)
    (hs : |subError i| ≤ u) (he : |expError i| ≤ u) :
    |computedTerm x k i subError expError - Real.exp (x i - x k)| ≤
      Real.exp (x i - x k) *
        (((x k - inputMin x k) + 1) * u +
          (2 * (x k - inputMin x k)^2 + (x k - inputMin x k)) * u^2) := by
  let t : ℝ := x k - x i
  let M : ℝ := x k - inputMin x k
  have hmin : inputMin x k ≤ x i := by
    unfold inputMin
    exact Finset.inf'_le x (by simp : i ∈ (Finset.univ : Finset (Fin n)))
  have ht : 0 ≤ t := by dsimp [t]; linarith
  have htM : t ≤ M := by dsimp [t, M]; linarith
  have hM : 0 ≤ M := le_trans ht htM
  have htu : t*u ≤ 1 := (mul_le_mul_of_nonneg_right htM hu).trans hMu
  have hf := exp_factor_error ht hu hu1 htu hs he
  have ht2M2 : t^2 ≤ M^2 := by nlinarith
  have hfactor : |Real.exp (-t * subError i) * (1 + expError i) - 1| ≤
      (M+1)*u + (2*M^2+M)*u^2 := by
    have hlin : t*u ≤ M*u := mul_le_mul_of_nonneg_right htM hu
    have hquad : (2*t^2+t)*u^2 ≤ (2*M^2+M)*u^2 := by
      apply mul_le_mul_of_nonneg_right _ (sq_nonneg u)
      linarith
    linarith [hf]
  have hcalc : computedTerm x k i subError expError - Real.exp (x i - x k) =
      Real.exp (x i - x k) *
        (Real.exp (-t * subError i) * (1+expError i)-1) := by
    unfold computedTerm
    have hneg : x i - x k = -t := by dsimp [t]; ring
    have hexp : Real.exp ((x i - x k) * (1 + subError i)) =
        Real.exp (x i - x k) * Real.exp (-t * subError i) := by
      have harg : (x i - x k) * (1 + subError i) =
          (x i - x k) + (-t * subError i) := by rw [hneg]; ring
      rw [harg, Real.exp_add]
    rw [hexp]
    ring
  rw [hcalc, abs_mul, abs_of_pos (Real.exp_pos _)]
  exact mul_le_mul_of_nonneg_left hfactor (Real.exp_pos _).le

private def quadCoeff : ℕ → ℝ
  | 0 => 0
  | m + 1 => 2 * quadCoeff m + m

private theorem quadCoeff_nonneg (m : ℕ) : 0 ≤ quadCoeff m := by
  induction m with
  | zero => simp [quadCoeff]
  | succ m ih =>
      rw [quadCoeff]
      positivity

private theorem pow_quad_bound (m : ℕ) {u : ℝ} (hu : 0 ≤ u) (hu1 : u ≤ 1) :
    (1 + u)^m ≤ 1 + (m : ℝ)*u + quadCoeff m * u^2 := by
  induction m with
  | zero => simp [quadCoeff]
  | succ m ih =>
      have hp : 0 ≤ 1 + u := by positivity
      have hmul := mul_le_mul_of_nonneg_right ih hp
      have hq := quadCoeff_nonneg m
      have hextra : quadCoeff m * u^2 * u ≤ quadCoeff m * u^2 := by
        exact mul_le_of_le_one_right (by positivity) hu1
      rw [pow_succ, quadCoeff]
      push_cast
      nlinarith [hmul]

private theorem poly_bound (A B K m u P : ℝ)
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hK : 0 ≤ K) (hm : 0 ≤ m)
    (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hP : P ≤ 1 + m*u + K*u^2) :
    (1+A*u+B*u^2)*P-1 ≤
      (A+m)*u + (B+K+A*m+A*K+B*m+B*K)*u^2 := by
  have hfac : 0 ≤ 1+A*u+B*u^2 := by positivity
  have hbase := mul_le_mul_of_nonneg_left hP hfac
  have hu3 : u^3 ≤ u^2 := by nlinarith [sq_nonneg u, mul_nonneg (sq_nonneg u) (sub_nonneg.mpr hu1)]
  have hu4 : u^4 ≤ u^2 := by
    have hu2 : u^2 ≤ 1 := by nlinarith
    nlinarith [mul_nonneg (sq_nonneg u) (sub_nonneg.mpr hu2)]
  have h3 : (A*K+B*m)*u^3 ≤ (A*K+B*m)*u^2 :=
    mul_le_mul_of_nonneg_left hu3 (by positivity)
  have h4 : (B*K)*u^4 ≤ (B*K)*u^2 :=
    mul_le_mul_of_nonneg_left hu4 (by positivity)
  have hexpand : (1+A*u+B*u^2)*(1+m*u+K*u^2)-1 =
      (A+m)*u+(B+K+A*m)*u^2+(A*K+B*m)*u^3+B*K*u^4 := by ring
  linarith [hexpand, hbase, h3, h4]

private theorem otherIndices_length (n : ℕ) (k : Fin n) :
    (otherIndices n k).length + 1 = n := by
  have hfilter : otherIndices n k = (List.finRange n).erase k := by
    unfold otherIndices
    simpa using (List.nodup_finRange n).erase_eq_filter k |>.symm
  rw [hfilter]
  simpa using List.length_erase_add_one (List.mem_finRange k)

private theorem zip_map_fold_eq {ι : Type*} (l : List ι) (errors : List ℝ)
    (w wh : ι → ℝ) (init : ℝ) :
    ((l.map wh).zip errors).foldl
      (fun t p => (t + p.1) * (1 + p.2)) init =
    (((l.map fun i => (w i, wh i)).zip errors).foldl
      (fun t p => (t + p.1.2) * (1 + p.2)) init) := by
  induction l generalizing errors init with
  | nil => simp
  | cons i is ih =>
      cases errors with
      | nil => simp
      | cons e es =>
          simpa only [List.map_cons, List.zip_cons_cons, List.foldl_cons] using
            ih es ((init + wh i) * (1 + e))

/-- Equation (4.6), with the `O(u²)` term uniform over all admissible local
    rounding errors for each fixed input and chosen maximum. -/
theorem target :
    ∀ (n : ℕ) (hn : 2 ≤ n) (x : Fin n → ℝ) (k : Fin n),
      (∀ i : Fin n, x i ≤ x k) →
      let s := exactSum x k
      0 < s ∧
        ∃ (C u₀ : ℝ), 0 ≤ C ∧ 0 < u₀ ∧
          ∀ (u : ℝ), 0 ≤ u → u ≤ u₀ →
            ∀ (subError expError : Fin n → ℝ)
              (addError : Fin (n - 2) → ℝ),
              (∀ i, |subError i| ≤ u) →
              (∀ i, |expError i| ≤ u) →
              (∀ j, |addError j| ≤ u) →
              |computedSum x k subError expError addError - s| / s ≤
                ((n : ℝ) + x k - inputMin x k) * u + C * u ^ 2 := by
  intro n hn x k hmax
  dsimp
  let L := otherIndices n k
  have hlen := otherIndices_length n k
  change L.length + 1 = n at hlen
  cases hL : L with
  | nil =>
      simp [hL] at hlen
      omega
  | cons i is =>
      have hrest : is.length = n - 2 := by
        simp [hL] at hlen
        omega
      let w : Fin n → ℝ := fun j => Real.exp (x j - x k)
      let M : ℝ := x k - inputMin x k
      let A : ℝ := M + 1
      let B : ℝ := 2*M^2+M
      let K : ℝ := quadCoeff is.length
      let C : ℝ := B+K+A*is.length+A*K+B*is.length+B*K
      let u₀ : ℝ := 1/(M+1)
      have hmin : inputMin x k ≤ x k := by
        unfold inputMin
        exact Finset.inf'_le x (by simp : k ∈ (Finset.univ : Finset (Fin n)))
      have hM : 0 ≤ M := by dsimp [M]; linarith
      have hA : 0 ≤ A := by dsimp [A]; linarith
      have hB : 0 ≤ B := by dsimp [B]; positivity
      have hK : 0 ≤ K := quadCoeff_nonneg _
      have hC : 0 ≤ C := by dsimp [C]; positivity
      have hu₀ : 0 < u₀ := by dsimp [u₀]; positivity
      have hu₀1 : u₀ ≤ 1 := by
        dsimp [u₀]
        apply (div_le_iff₀ (by linarith : 0 < M+1)).2
        nlinarith
      have hs : 0 < exactSum x k := by
        have hne : (L.map w) ≠ [] := by simp [hL]
        have hpos : ∀ z ∈ L.map w, 0 < z := by
          intro z hz
          obtain ⟨j, hj, rfl⟩ := List.mem_map.mp hz
          exact Real.exp_pos _
        have hsum := List.sum_pos (L.map w) hpos hne
        simpa [exactSum, L, w] using hsum
      refine ⟨hs, C, u₀, hC, hu₀, ?_⟩
      intro u hu hu₀' subError expError addError hsub hexp hadd
      have hu1 : u ≤ 1 := hu₀'.trans hu₀1
      have hMu : M*u ≤ 1 := by
        have hp : 0 < M+1 := by linarith
        have h := (le_div_iff₀ hp).mp hu₀'
        nlinarith
      let wh : Fin n → ℝ := fun j => computedTerm x k j subError expError
      let α : ℝ := A*u+B*u^2
      have hα : 0 ≤ α := by dsimp [α]; positivity
      have hterm (j : Fin n) : |wh j - w j| ≤ α * w j := by
        have ht := term_error x k j (hmax j) u hu hu1 (by simpa [M] using hMu)
          subError expError (hsub j) (hexp j)
        dsimp [wh, w, α, A, B, M]
        convert ht using 1 <;> ring
      have hpairs : ∀ p ∈ is.map (fun j => (w j, wh j)),
          0 ≤ p.1 ∧ |p.2-p.1| ≤ α*p.1 := by
        intro p hp
        obtain ⟨j, hj, rfl⟩ := List.mem_map.mp hp
        exact ⟨(Real.exp_pos _).le, hterm j⟩
      have herrs : ∀ e ∈ List.ofFn addError, |e| ≤ u := by
        intro e he
        obtain ⟨j, rfl⟩ := List.mem_ofFn.mp he
        exact hadd j
      have hlength : (List.ofFn addError).length =
          (is.map (fun j => (w j, wh j))).length := by
        simp [hrest]
      have hfold := fold_bound (is.map (fun j => (w j, wh j)))
        (List.ofFn addError) (w i) (wh i) u α hlength
        (Real.exp_pos _).le hu hα (hterm i) hpairs herrs
      have hcomp : computedSum x k subError expError addError =
          (((is.map fun j => (w j, wh j)).zip (List.ofFn addError)).foldl
            (fun t p => (t + p.1.2) * (1 + p.2)) (wh i)) := by
        have hh := zip_map_fold_eq is (List.ofFn addError) w wh (wh i)
        simpa [computedSum, roundedSum, L, hL, wh] using hh
      have hsum : exactSum x k = w i +
          ((is.map (fun j => (w j, wh j))).map Prod.fst).sum := by
        calc
          exactSum x k = w i + (is.map w).sum := by simp [exactSum, L, hL, w]
          _ = _ := by simp [List.map_map, Function.comp_def]
      have hraw : |computedSum x k subError expError addError - exactSum x k| ≤
          ((1+α)*(1+u)^is.length-1)*exactSum x k := by
        simpa [hcomp, hsum] using hfold
      have hpow := pow_quad_bound is.length hu hu1
      have hpoly := poly_bound A B K is.length u ((1+u)^is.length)
        hA hB hK (by positivity) hu hu1 hpow
      have hβ : (1+α)*(1+u)^is.length-1 ≤
          ((n:ℝ)+M)*u+C*u^2 := by
        have hncast : (is.length:ℝ)+2=(n:ℝ) := by exact_mod_cast (by omega : is.length+2=n)
        dsimp [α, C] at *
        nlinarith [hpoly]
      have hbound : |computedSum x k subError expError addError - exactSum x k| ≤
          (((n:ℝ)+M)*u+C*u^2)*exactSum x k :=
        hraw.trans (mul_le_mul_of_nonneg_right hβ hs.le)
      apply (div_le_iff₀ hs).2
      convert hbound using 1 <;> ring

end HighamBenchCandidate
