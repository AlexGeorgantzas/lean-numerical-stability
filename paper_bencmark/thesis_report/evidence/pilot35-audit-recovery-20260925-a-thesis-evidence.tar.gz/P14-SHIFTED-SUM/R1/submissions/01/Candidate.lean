import Mathlib

namespace HighamBenchCandidate

/- `m + 2` is the paper's total input count `n`. Removing `k` leaves
   `m + 1` terms; `Fin.succAbove` retains their original order. -/
noncomputable def exactShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) : ℝ :=
  ∑ i : Fin (m + 1), Real.exp (x (k.succAbove i) - x k)

/- The two errors for each shifted exponential are the rounded subtraction
   and the relative-error evaluation of exp, respectively. -/
noncomputable def roundedShiftedWeight (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (subErr expErr : Fin (m + 1) → ℝ)
    (i : Fin (m + 1)) : ℝ :=
  Real.exp ((x (k.succAbove i) - x k) * (1 + subErr i)) *
    (1 + expErr i)

/- Sum from the first computed term, with one rounded addition for each
   following term. `addErr : Fin m → ℝ` records those `m` merges. -/
noncomputable def roundedShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (subErr expErr : Fin (m + 1) → ℝ)
    (addErr : Fin m → ℝ) : ℝ :=
  Fin.foldl m
    (fun acc i =>
      (acc + roundedShiftedWeight m x k subErr expErr i.succ) *
        (1 + addErr i))
    (roundedShiftedWeight m x k subErr expErr 0)

/- Equation (4.6). The quadratic constant and small-u threshold may depend
   on the fixed input and selected maximum, but are uniform over all local
   rounding errors and therefore over the computed sum. -/
theorem target :
    ∀ (m : ℕ) (x : Fin (m + 2) → ℝ) (k : Fin (m + 2))
      (hmax : ∀ i : Fin (m + 2), x i ≤ x k)
      (xmin : ℝ)
      (hmin : (∀ i : Fin (m + 2), xmin ≤ x i) ∧
        ∃ i : Fin (m + 2), x i = xmin),
      0 < exactShiftedSum m x k ∧
      ∃ (C u₀ : ℝ), 0 ≤ C ∧ 0 < u₀ ∧
        ∀ (u : ℝ), 0 ≤ u → u ≤ u₀ →
          ∀ (subErr expErr : Fin (m + 1) → ℝ) (addErr : Fin m → ℝ),
            (∀ i, |subErr i| ≤ u) →
            (∀ i, |expErr i| ≤ u) →
            (∀ i, |addErr i| ≤ u) →
            |roundedShiftedSum m x k subErr expErr addErr -
                exactShiftedSum m x k| / exactShiftedSum m x k ≤
              (((m + 2 : ℕ) : ℝ) + x k - xmin) * u + C * u ^ 2 := by
  sorry

end HighamBenchCandidate
