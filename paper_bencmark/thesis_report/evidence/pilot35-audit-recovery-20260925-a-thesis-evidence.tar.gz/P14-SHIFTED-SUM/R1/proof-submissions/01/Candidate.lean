import Mathlib

namespace HighamBenchCandidate

/- `m + 2` is the paper's total input count `n`. Removing `k` leaves
   `m + 1` terms; `Fin.succAbove` retains their original order. -/
noncomputable def exactShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) : ℝ :=
  ∑ i : Fin (m + 1), Real.exp (x (k.succAbove i) - x k)

/- The two errors for each shifted exponential are the rounded subtraction
   and the relative-error evaluation of exp, respectively. -/
noncomputable def roundedShiftedWeight (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (subErr expErr : Fin (m + 1) → ℝ)
    (i : Fin (m + 1)) : ℝ :=
  Real.exp ((x (k.succAbove i) - x k) * (1 + subErr i)) *
    (1 + expErr i)

/- Sum from the first computed term, with one rounded addition for each
   following term. `addErr : Fin m → ℝ` records those `m` merges. -/
noncomputable def roundedShiftedSum (m : ℕ) (x : Fin (m + 2) → ℝ)
    (k : Fin (m + 2)) (subErr expErr : Fin (m + 1) → ℝ)
    (addErr : Fin m → ℝ) : ℝ :=
  Fin.foldl m
    (fun acc i =>
      (acc + roundedShiftedWeight m x k subErr expErr i.succ) *
        (1 + addErr i))
    (roundedShiftedWeight m x k subErr expErr 0)

private theorem roundedFold_bound :
    ∀ (m : ℕ) (u : ℝ) (hu : 0 ≤ u)
      (a b : Fin (m + 1) → ℝ) (δ : Fin m → ℝ),
      (∀ i, 0 ≤ b i) → (∀ i, |δ i| ≤ u) →
      |Fin.foldl m (fun acc i => (acc + a i.succ) * (1 + δ i)) (a 0) -
          ∑ i, b i| ≤
        ((1 + u) ^ m - 1) * (∑ i, b i) +
          (1 + u) ^ m * (∑ i, |a i - b i|) := by
  intro m
  induction m with
  | zero =>
      intro u hu a b δ hb hδ
      simp
  | succ m ih =>
      intro u hu a b δ hb hδ
      let a' : Fin (m + 1) → ℝ := fun i => a i.castSucc
      let b' : Fin (m + 1) → ℝ := fun i => b i.castSucc
      let δ' : Fin m → ℝ := fun i => δ i.castSucc
      let R : ℝ := Fin.foldl m
        (fun acc i => (acc + a' i.succ) * (1 + δ' i)) (a' 0)
      let S : ℝ := ∑ i, b' i
      let E : ℝ := ∑ i, |a' i - b' i|
      let al : ℝ := a (Fin.last (m + 1))
      let bl : ℝ := b (Fin.last (m + 1))
      let dl : ℝ := δ (Fin.last m)
      let P : ℝ := (1 + u) ^ m
      have hR : |R - S| ≤ (P - 1) * S + P * E := by
        simpa [R, S, E, P, a', b', δ'] using
          ih u hu a' b' δ' (fun i => hb i.castSucc) (fun i => hδ i.castSucc)
      have hS : 0 ≤ S := Finset.sum_nonneg (fun i _ => hb i.castSucc)
      have hE : 0 ≤ E := Finset.sum_nonneg (fun i _ => abs_nonneg _)
      have hbl : 0 ≤ bl := hb _
      have he : 0 ≤ |al - bl| := abs_nonneg _
      have hP : 1 ≤ P := by
        dsimp [P]
        exact one_le_pow₀ (by linarith : (1 : ℝ) ≤ 1 + u)
      have hfac : |1 + dl| ≤ 1 + u := by
        calc
          |1 + dl| ≤ |(1 : ℝ)| + |dl| := abs_add_le _ _
          _ ≤ 1 + u := by simpa using add_le_add_left (hδ (Fin.last m)) 1
      have hdl : |dl| ≤ u := hδ _
      have hstep :
          |(R + al) * (1 + dl) - (S + bl)| ≤
            (1 + u) * (|R - S| + |al - bl|) + u * (S + bl) := by
        have hid : (R + al) * (1 + dl) - (S + bl) =
            ((R - S) + (al - bl)) * (1 + dl) + (S + bl) * dl := by ring
        rw [hid]
        calc
          |((R - S) + (al - bl)) * (1 + dl) + (S + bl) * dl| ≤
              |((R - S) + (al - bl)) * (1 + dl)| + |(S + bl) * dl| :=
                abs_add_le _ _
          _ = |(R - S) + (al - bl)| * |1 + dl| + |S + bl| * |dl| := by
                rw [abs_mul, abs_mul]
          _ ≤ (|R - S| + |al - bl|) * (1 + u) + (S + bl) * u := by
                apply add_le_add
                · exact mul_le_mul (abs_add_le _ _) hfac (abs_nonneg _) (by positivity)
                · rw [abs_of_nonneg (by linarith : 0 ≤ S + bl)]
                  exact mul_le_mul_of_nonneg_left hdl (by linarith)
          _ = (1 + u) * (|R - S| + |al - bl|) + u * (S + bl) := by ring
      have hmain :
          |(R + al) * (1 + dl) - (S + bl)| ≤
            ((1 + u) ^ (m + 1) - 1) * (S + bl) +
              (1 + u) ^ (m + 1) * (E + |al - bl|) := by
        have hnonneg : 0 ≤ (1 + u) := by linarith
        have h1 : (1 + u) * (|R - S| + |al - bl|) + u * (S + bl) ≤
            (1 + u) * ((P - 1) * S + P * E + |al - bl|) +
              u * (S + bl) := by
          gcongr
        calc
          _ ≤ (1 + u) * ((P - 1) * S + P * E + |al - bl|) +
                u * (S + bl) := hstep.trans h1
          _ ≤ ((1 + u) ^ (m + 1) - 1) * (S + bl) +
                (1 + u) ^ (m + 1) * (E + |al - bl|) := by
              rw [pow_succ]
              dsimp [P] at hP ⊢
              nlinarith [mul_nonneg (sub_nonneg.mpr hP) hbl,
                mul_nonneg (sub_nonneg.mpr hP) he]
      have hfold :
          Fin.foldl (m + 1)
            (fun acc i => (acc + a i.succ) * (1 + δ i)) (a 0) =
            (R + al) * (1 + dl) := by
        rw [Fin.foldl_succ_last]
        congr 1
      have hsum : (∑ i : Fin (m + 2), b i) = S + bl := by
        rw [Fin.sum_univ_castSucc]
      have herr : (∑ i : Fin (m + 2), |a i - b i|) = E + |al - bl| := by
        rw [Fin.sum_univ_castSucc]
      rw [hfold, hsum, herr]
      exact hmain

private theorem expRelative_bound (R u t e : ℝ)
    (hR : 0 ≤ R) (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hRu : R * u ≤ 1) (ht : |t| ≤ R * u) (he : |e| ≤ u) :
    |Real.exp t * (1 + e) - 1| ≤
      (R + 1) * u + (R + 2 * R ^ 2) * u ^ 2 := by
  have ht1 : |t| ≤ 1 := ht.trans hRu
  have hrem := Real.abs_exp_sub_one_sub_id_le ht1
  have hsmall : |Real.exp t - 1| ≤ |t| + t ^ 2 := by
    calc
      |Real.exp t - 1| = |(Real.exp t - 1 - t) + t| := by ring
      _ ≤ |Real.exp t - 1 - t| + |t| := abs_add_le _ _
      _ ≤ |t| + t ^ 2 := by linarith
  have htsq : t ^ 2 ≤ (R * u) ^ 2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr ht)
      (add_nonneg (mul_nonneg hR hu) (abs_nonneg t)), sq_abs t]
  have hsmall' : |Real.exp t - 1| ≤ R * u + R ^ 2 * u ^ 2 := by
    nlinarith [hsmall, htsq]
  have hexp : |Real.exp t| ≤ 1 + R * u + R ^ 2 * u ^ 2 := by
    rw [Real.abs_exp]
    have h := le_abs_self (Real.exp t - 1)
    nlinarith [hsmall']
  have hmain :
      |Real.exp t * (1 + e) - 1| ≤
        (R * u + R ^ 2 * u ^ 2) +
          (1 + R * u + R ^ 2 * u ^ 2) * u := by
    have hid : Real.exp t * (1 + e) - 1 =
        (Real.exp t - 1) + Real.exp t * e := by ring
    rw [hid]
    calc
      |(Real.exp t - 1) + Real.exp t * e| ≤
          |Real.exp t - 1| + |Real.exp t * e| := abs_add_le _ _
      _ = |Real.exp t - 1| + |Real.exp t| * |e| := by rw [abs_mul]
      _ ≤ (R * u + R ^ 2 * u ^ 2) +
            (1 + R * u + R ^ 2 * u ^ 2) * u := by
          apply add_le_add hsmall'
          exact mul_le_mul hexp he (abs_nonneg _) (by positivity)
  have hcube : R ^ 2 * u ^ 3 ≤ R ^ 2 * u ^ 2 := by
    nlinarith [mul_nonneg (sq_nonneg R)
      (mul_nonneg (sq_nonneg u) (sub_nonneg.mpr hu1))]
  nlinarith [hmain, hcube]

private theorem oneAddPow_bound (m : ℕ) (u : ℝ) (hu : 0 ≤ u)
    (hmu : (m : ℝ) * u ≤ 1) :
    (1 + u) ^ m ≤ 1 + (m : ℝ) * u + ((m : ℝ) * u) ^ 2 := by
  have hbase : 1 + u ≤ Real.exp u := by
    simpa [add_comm] using Real.add_one_le_exp u
  have hpow : (1 + u) ^ m ≤ Real.exp ((m : ℝ) * u) := by
    calc
      (1 + u) ^ m ≤ (Real.exp u) ^ m :=
        pow_le_pow_left₀ (by linarith) hbase m
      _ = Real.exp ((m : ℝ) * u) := by rw [← Real.exp_nat_mul]
  have hmu0 : 0 ≤ (m : ℝ) * u := mul_nonneg (by positivity) hu
  have hrem := Real.abs_exp_sub_one_sub_id_le
    (show |(m : ℝ) * u| ≤ 1 by simpa [abs_of_nonneg hmu0] using hmu)
  have hexp : Real.exp ((m : ℝ) * u) ≤
      1 + (m : ℝ) * u + ((m : ℝ) * u) ^ 2 := by
    linarith [le_abs_self (Real.exp ((m : ℝ) * u) - 1 - (m : ℝ) * u)]
  exact hpow.trans hexp

private theorem combine_bounds (M A K u P : ℝ)
    (hM : 0 ≤ M) (hA : 0 ≤ A) (hK : 0 ≤ K)
    (hu : 0 ≤ u) (hu1 : u ≤ 1)
    (hP1 : 1 ≤ P) (hP : P ≤ 1 + M * u + M ^ 2 * u ^ 2) :
    (P - 1) + P * (A * u + K * u ^ 2) ≤
      (M + A) * u +
        (M ^ 2 + K + (M + M ^ 2) * (A + K)) * u ^ 2 := by
  have hu2 : u ^ 2 ≤ u := by nlinarith [mul_nonneg hu (sub_nonneg.mpr hu1)]
  have hE0 : 0 ≤ A * u + K * u ^ 2 := by positivity
  have hE : A * u + K * u ^ 2 ≤ (A + K) * u := by
    nlinarith [mul_nonneg hK (sub_nonneg.mpr hu2)]
  have hPu : 0 ≤ P - 1 := by linarith
  have hPdiff : P - 1 ≤ (M + M ^ 2) * u := by
    nlinarith [mul_nonneg (sq_nonneg M) (sub_nonneg.mpr hu2)]
  have hcross : (P - 1) * (A * u + K * u ^ 2) ≤
      (M + M ^ 2) * (A + K) * u ^ 2 := by
    calc
      (P - 1) * (A * u + K * u ^ 2) ≤
          ((M + M ^ 2) * u) * ((A + K) * u) :=
            mul_le_mul hPdiff hE hE0 (by positivity)
      _ = (M + M ^ 2) * (A + K) * u ^ 2 := by ring
  nlinarith [hcross]

/- Equation (4.6). The quadratic constant and small-u threshold may depend
   on the fixed input and selected maximum, but are uniform over all local
   rounding errors and therefore over the computed sum. -/
theorem target :
    ∀ (m : ℕ) (x : Fin (m + 2) → ℝ) (k : Fin (m + 2))
      (hmax : ∀ i : Fin (m + 2), x i ≤ x k)
      (xmin : ℝ)
      (hmin : (∀ i : Fin (m + 2), xmin ≤ x i) ∧
        ∃ i : Fin (m + 2), x i = xmin),
      0 < exactShiftedSum m x k ∧
      ∃ (C u₀ : ℝ), 0 ≤ C ∧ 0 < u₀ ∧
        ∀ (u : ℝ), 0 ≤ u → u ≤ u₀ →
          ∀ (subErr expErr : Fin (m + 1) → ℝ) (addErr : Fin m → ℝ),
            (∀ i, |subErr i| ≤ u) →
            (∀ i, |expErr i| ≤ u) →
            (∀ i, |addErr i| ≤ u) →
            |roundedShiftedSum m x k subErr expErr addErr -
                exactShiftedSum m x k| / exactShiftedSum m x k ≤
              (((m + 2 : ℕ) : ℝ) + x k - xmin) * u + C * u ^ 2 := by
  intro m x k hmax xmin hmin
  let b : Fin (m + 1) → ℝ := fun i =>
    Real.exp (x (k.succAbove i) - x k)
  have hb : ∀ i, 0 ≤ b i := fun i => le_of_lt (Real.exp_pos _)
  have hs : 0 < exactShiftedSum m x k := by
    change 0 < ∑ i : Fin (m + 1), b i
    exact Finset.sum_pos (fun i _ => Real.exp_pos _) (by simp)
  let R : ℝ := x k - xmin
  let M : ℝ := m
  let A : ℝ := R + 1
  let K : ℝ := R + 2 * R ^ 2
  let C : ℝ := M ^ 2 + K + (M + M ^ 2) * (A + K)
  let D : ℝ := 1 + R + M
  have hR : 0 ≤ R := by
    obtain ⟨i, hi⟩ := hmin.2
    dsimp [R]
    linarith [hmax i]
  have hM : 0 ≤ M := by dsimp [M]; positivity
  have hA : 0 ≤ A := by dsimp [A]; linarith
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hD : 0 < D := by dsimp [D]; linarith
  refine ⟨hs, C, 1 / D, hC, by positivity, ?_⟩
  intro u hu hu0 subErr expErr addErr hsub hexp hadd
  have hbudget : u * D ≤ 1 := by
    calc
      u * D ≤ (1 / D) * D := mul_le_mul_of_nonneg_right hu0 (le_of_lt hD)
      _ = 1 := by field_simp
  have hu1 : u ≤ 1 := by
    dsimp [D] at hbudget
    nlinarith [mul_nonneg hR hu, mul_nonneg hM hu]
  have hRu : R * u ≤ 1 := by
    dsimp [D] at hbudget
    nlinarith [mul_nonneg hM hu]
  have hMu : M * u ≤ 1 := by
    dsimp [D] at hbudget
    nlinarith [mul_nonneg hR hu]
  let a : Fin (m + 1) → ℝ := fun i =>
    roundedShiftedWeight m x k subErr expErr i
  let E0 : ℝ := A * u + K * u ^ 2
  have hweight : ∀ i, |a i - b i| ≤ b i * E0 := by
    intro i
    let z : ℝ := x (k.succAbove i) - x k
    let t : ℝ := z * subErr i
    have hz : |z| ≤ R := by
      dsimp [z, R]
      rw [abs_of_nonpos (sub_nonpos.mpr (hmax _))]
      linarith [hmin.1 (k.succAbove i)]
    have ht : |t| ≤ R * u := by
      dsimp [t]
      rw [abs_mul]
      exact mul_le_mul hz (hsub i) (abs_nonneg _) hR
    have hlocal := expRelative_bound R u t (expErr i)
      hR hu hu1 hRu ht (hexp i)
    have hid : z * (1 + subErr i) = z + t := by
      dsimp [t]
      ring
    have hfactor : a i - b i = b i *
        (Real.exp t * (1 + expErr i) - 1) := by
      dsimp [a, b, roundedShiftedWeight]
      rw [show x (k.succAbove i) - x k = z by rfl, hid, Real.exp_add]
      ring
    rw [hfactor, abs_mul, Real.abs_exp]
    exact mul_le_mul_of_nonneg_left (by simpa [E0, A, K] using hlocal) (hb i)
  have hE : (∑ i : Fin (m + 1), |a i - b i|) ≤
      E0 * (∑ i : Fin (m + 1), b i) := by
    calc
      (∑ i : Fin (m + 1), |a i - b i|) ≤
          ∑ i : Fin (m + 1), b i * E0 :=
            Finset.sum_le_sum (fun i _ => hweight i)
      _ = E0 * (∑ i : Fin (m + 1), b i) := by
            rw [← Finset.sum_mul]
            ring
  have hfold := roundedFold_bound m u hu a b addErr hb hadd
  have hP : 0 ≤ (1 + u) ^ m := pow_nonneg (by linarith) _
  have hbound :
      |roundedShiftedSum m x k subErr expErr addErr -
          exactShiftedSum m x k| ≤
        (((1 + u) ^ m - 1) + (1 + u) ^ m * E0) *
          exactShiftedSum m x k := by
    have hh : |roundedShiftedSum m x k subErr expErr addErr -
          exactShiftedSum m x k| ≤
        ((1 + u) ^ m - 1) * (∑ i, b i) +
          (1 + u) ^ m * (∑ i, |a i - b i|) := by
      simpa [roundedShiftedSum, exactShiftedSum, a, b] using hfold
    calc
      _ ≤ ((1 + u) ^ m - 1) * (∑ i, b i) +
            (1 + u) ^ m * (∑ i, |a i - b i|) := hh
      _ ≤ (((1 + u) ^ m - 1) + (1 + u) ^ m * E0) *
            exactShiftedSum m x k := by
          rw [exactShiftedSum]
          dsimp [b] at hE ⊢
          nlinarith [mul_le_mul_of_nonneg_left hE hP]
  have hpow : (1 + u) ^ m ≤ 1 + M * u + M ^ 2 * u ^ 2 := by
    simpa [M, mul_pow] using oneAddPow_bound m u hu hMu
  have hpoly : ((1 + u) ^ m - 1) + (1 + u) ^ m * E0 ≤
      (M + A) * u + C * u ^ 2 := by
    simpa [E0, C] using
      combine_bounds M A K u ((1 + u) ^ m) hM hA hK hu hu1
        (one_le_pow₀ (by linarith : (1 : ℝ) ≤ 1 + u)) hpow
  have hrel :
      |roundedShiftedSum m x k subErr expErr addErr - exactShiftedSum m x k| /
          exactShiftedSum m x k ≤ (M + A) * u + C * u ^ 2 := by
    rw [div_le_iff₀ hs]
    exact hbound.trans (mul_le_mul_of_nonneg_right hpoly (le_of_lt hs))
  have hcoeff : M + A ≤ ((m + 2 : ℕ) : ℝ) + x k - xmin := by
    dsimp [M, A, R]
    push_cast
    linarith
  exact hrel.trans (by nlinarith [mul_le_mul_of_nonneg_right hcoeff hu])

end HighamBenchCandidate
