import Mathlib

namespace HighamBenchCandidate

/-- A binary summation tree. Each leaf is an exact real input, and each
internal node records the relative roundoff of that addition. -/
inductive SummationTree where
  | leaf (x : ℝ) : SummationTree
  | add (left right : SummationTree) (delta : ℝ) : SummationTree

namespace SummationTree

/-- The exact partial sum at a node. -/
def exactSum : SummationTree → ℝ
  | .leaf x => x
  | .add left right _ => exactSum left + exactSum right

/-- Evaluation of the tree by rounded additions on the computed children. -/
def computedSum : SummationTree → ℝ
  | .leaf x => x
  | .add left right delta =>
      (computedSum left + computedSum right) * (1 + delta)

/-- The sum of the first-order local errors `sₖ δₖ`. -/
def firstOrder : SummationTree → ℝ
  | .leaf _ => 0
  | .add left right delta =>
      firstOrder left + firstOrder right +
        (exactSum left + exactSum right) * delta

/-- The inputs, with repetitions retained. -/
def leaves : SummationTree → List ℝ
  | .leaf x => [x]
  | .add left right _ => leaves left ++ leaves right

/-- The sum of absolute values of the fixed input vector. -/
def inputNorm (t : SummationTree) : ℝ :=
  (t.leaves.map abs).sum

/-- The largest number of additions on a root-to-leaf path. -/
def height : SummationTree → ℕ
  | .leaf _ => 0
  | .add left right _ => max (height left) (height right) + 1

/-- Every internal addition satisfies the standard relative-error model. -/
def RoundedBy (u : ℝ) : SummationTree → Prop
  | .leaf _ => True
  | .add left right delta =>
      |delta| ≤ u ∧ RoundedBy u left ∧ RoundedBy u right

end SummationTree

private theorem inputNorm_nonneg (t : SummationTree) : 0 ≤ t.inputNorm := by
  unfold SummationTree.inputNorm
  apply List.sum_nonneg
  intro y hy
  obtain ⟨x, _, rfl⟩ := List.mem_map.mp hy
  exact abs_nonneg x

private theorem abs_exactSum_le_inputNorm (t : SummationTree) :
    |t.exactSum| ≤ t.inputNorm := by
  induction t with
  | leaf x =>
      simp [SummationTree.exactSum, SummationTree.inputNorm, SummationTree.leaves]
  | add l r δ ihl ihr =>
      have h := abs_add_le l.exactSum r.exactSum
      simp only [SummationTree.exactSum]
      rw [show (SummationTree.add l r δ).inputNorm =
          l.inputNorm + r.inputNorm by
        simp [SummationTree.inputNorm, SummationTree.leaves]]
      linarith

private theorem abs_computedSum_le_norm_add_error (t : SummationTree) :
    |t.computedSum| ≤ t.inputNorm + |t.computedSum - t.exactSum| := by
  have he := abs_exactSum_le_inputNorm t
  have ha := abs_add_le t.exactSum (t.computedSum - t.exactSum)
  have hid : t.exactSum + (t.computedSum - t.exactSum) = t.computedSum := by ring
  rw [hid] at ha
  linarith

private theorem tree_error_bounds (u : ℝ) (M : ℕ)
    (hu : 0 ≤ u) (hM : (M : ℝ) * u < 1) :
    ∀ t : SummationTree, t.height ≤ M → t.RoundedBy u →
      (1 - (M : ℝ) * u) * |t.computedSum - t.exactSum| ≤
        ((t.height : ℝ) * u) * t.inputNorm ∧
      (1 - (M : ℝ) * u) *
          |(t.computedSum - t.exactSum) - t.firstOrder| ≤
        (((t.height : ℝ) * u) ^ 2) * t.inputNorm := by
  intro t
  induction t with
  | leaf x =>
      intro _ _
      simp [SummationTree.height, SummationTree.computedSum,
        SummationTree.exactSum, SummationTree.firstOrder]
  | add l r δ ihl ihr =>
      intro ht hr
      change |δ| ≤ u ∧ l.RoundedBy u ∧ r.RoundedBy u at hr
      rcases hr with ⟨hδ, hrl, hrr⟩
      have htl : l.height ≤ M := by
        have : max l.height r.height + 1 ≤ M := ht
        omega
      have htr : r.height ≤ M := by
        have : max l.height r.height + 1 ≤ M := ht
        omega
      obtain ⟨hel, hrl_bound⟩ := ihl htl hrl
      obtain ⟨her, hrr_bound⟩ := ihr htr hrr
      let D : ℝ := 1 - (M : ℝ) * u
      let m : ℝ := max (l.height : ℝ) (r.height : ℝ)
      let NL : ℝ := l.inputNorm
      let NR : ℝ := r.inputNorm
      let EL : ℝ := |l.computedSum - l.exactSum|
      let ER : ℝ := |r.computedSum - r.exactSum|
      let RL : ℝ := |(l.computedSum - l.exactSum) - l.firstOrder|
      let RR : ℝ := |(r.computedSum - r.exactSum) - r.firstOrder|
      have hD : 0 < D := by dsimp [D]; linarith
      have hm : 0 ≤ m := by dsimp [m]; positivity
      have hNL : 0 ≤ NL := inputNorm_nonneg l
      have hNR : 0 ≤ NR := inputNorm_nonneg r
      have hN : 0 ≤ NL + NR := by linarith
      have hLm : (l.height : ℝ) ≤ m := le_max_left _ _
      have hRm : (r.height : ℝ) ≤ m := le_max_right _ _
      have hmM : m + 1 ≤ (M : ℝ) := by
        have h : max l.height r.height + 1 ≤ M := ht
        have h' : ((max l.height r.height : ℕ) : ℝ) + 1 ≤ (M : ℝ) := by
          exact_mod_cast h
        simpa [m] using h'
      have hheight : ((SummationTree.add l r δ).height : ℝ) = m + 1 := by
        simp [SummationTree.height, m]
      have hnorm : (SummationTree.add l r δ).inputNorm = NL + NR := by
        simp [SummationTree.inputNorm, SummationTree.leaves, NL, NR]
      have hEL : D * EL ≤ (m * u) * NL := by
        calc
          D * EL ≤ ((l.height : ℝ) * u) * NL := hel
          _ ≤ (m * u) * NL := by gcongr
      have hER : D * ER ≤ (m * u) * NR := by
        calc
          D * ER ≤ ((r.height : ℝ) * u) * NR := her
          _ ≤ (m * u) * NR := by gcongr
      have hRL : D * RL ≤ (m * u) ^ 2 * NL := by
        calc
          D * RL ≤ (((l.height : ℝ) * u) ^ 2) * NL := hrl_bound
          _ ≤ (m * u) ^ 2 * NL := by gcongr
      have hRR : D * RR ≤ (m * u) ^ 2 * NR := by
        calc
          D * RR ≤ (((r.height : ℝ) * u) ^ 2) * NR := hrr_bound
          _ ≤ (m * u) ^ 2 * NR := by gcongr
      have hEid :
          (SummationTree.add l r δ).computedSum -
            (SummationTree.add l r δ).exactSum =
          (l.computedSum - l.exactSum) +
            (r.computedSum - r.exactSum) +
            δ * (l.computedSum + r.computedSum) := by
        simp only [SummationTree.computedSum, SummationTree.exactSum]
        ring
      have hRid :
          ((SummationTree.add l r δ).computedSum -
              (SummationTree.add l r δ).exactSum) -
              (SummationTree.add l r δ).firstOrder =
          ((l.computedSum - l.exactSum) - l.firstOrder) +
            ((r.computedSum - r.exactSum) - r.firstOrder) +
            δ * ((l.computedSum - l.exactSum) +
              (r.computedSum - r.exactSum)) := by
        simp only [SummationTree.computedSum, SummationTree.exactSum,
          SummationTree.firstOrder]
        ring
      have hcompL := abs_computedSum_le_norm_add_error l
      have hcompR := abs_computedSum_le_norm_add_error r
      change |l.computedSum| ≤ NL + EL at hcompL
      change |r.computedSum| ≤ NR + ER at hcompR
      have hcomp : |l.computedSum + r.computedSum| ≤
          NL + NR + EL + ER := by
        have h := abs_add_le l.computedSum r.computedSum
        linarith
      have hprodE : |δ * (l.computedSum + r.computedSum)| ≤
          u * (NL + NR + EL + ER) := by
        rw [abs_mul]
        calc
          |δ| * |l.computedSum + r.computedSum| ≤
              u * |l.computedSum + r.computedSum| :=
            mul_le_mul_of_nonneg_right hδ (abs_nonneg _)
          _ ≤ u * (NL + NR + EL + ER) :=
            mul_le_mul_of_nonneg_left hcomp hu
      have hEabs :
          |(SummationTree.add l r δ).computedSum -
            (SummationTree.add l r δ).exactSum| ≤
          EL + ER + u * (NL + NR + EL + ER) := by
        rw [hEid]
        have h1 := abs_add_le
          ((l.computedSum - l.exactSum) +
            (r.computedSum - r.exactSum))
          (δ * (l.computedSum + r.computedSum))
        have h2 := abs_add_le
          (l.computedSum - l.exactSum)
          (r.computedSum - r.exactSum)
        dsimp [EL, ER] at *
        linarith
      have hprodR :
          |δ * ((l.computedSum - l.exactSum) +
            (r.computedSum - r.exactSum))| ≤ u * (EL + ER) := by
        rw [abs_mul]
        have hsum := abs_add_le
          (l.computedSum - l.exactSum)
          (r.computedSum - r.exactSum)
        have hprod := mul_le_mul_of_nonneg_left hsum hu
        have hprod' := mul_le_mul_of_nonneg_right hδ
          (abs_nonneg ((l.computedSum - l.exactSum) +
            (r.computedSum - r.exactSum)))
        dsimp [EL, ER]
        nlinarith
      have hRabs :
          |((SummationTree.add l r δ).computedSum -
              (SummationTree.add l r δ).exactSum) -
              (SummationTree.add l r δ).firstOrder| ≤
          RL + RR + u * (EL + ER) := by
        rw [hRid]
        have h1 := abs_add_le
          (((l.computedSum - l.exactSum) - l.firstOrder) +
            ((r.computedSum - r.exactSum) - r.firstOrder))
          (δ * ((l.computedSum - l.exactSum) +
            (r.computedSum - r.exactSum)))
        have h2 := abs_add_le
          ((l.computedSum - l.exactSum) - l.firstOrder)
          ((r.computedSum - r.exactSum) - r.firstOrder)
        dsimp [RL, RR]
        linarith
      have hEsum : D * (EL + ER) ≤ (m * u) * (NL + NR) := by
        calc
          D * (EL + ER) = D * EL + D * ER := by ring
          _ ≤ (m * u) * NL + (m * u) * NR := add_le_add hEL hER
          _ = (m * u) * (NL + NR) := by ring
      have hRsum : D * (RL + RR) ≤ (m * u) ^ 2 * (NL + NR) := by
        calc
          D * (RL + RR) = D * RL + D * RR := by ring
          _ ≤ (m * u) ^ 2 * NL + (m * u) ^ 2 * NR :=
            add_le_add hRL hRR
          _ = (m * u) ^ 2 * (NL + NR) := by ring
      have hEd : D *
          |(SummationTree.add l r δ).computedSum -
            (SummationTree.add l r δ).exactSum| ≤
          (1 + u) * D * (EL + ER) + D * u * (NL + NR) := by
        have h := mul_le_mul_of_nonneg_left hEabs (le_of_lt hD)
        calc
          D * |(SummationTree.add l r δ).computedSum -
              (SummationTree.add l r δ).exactSum| ≤
              D * (EL + ER + u * (NL + NR + EL + ER)) := h
          _ = (1 + u) * D * (EL + ER) + D * u * (NL + NR) := by ring
      have hRd : D *
          |((SummationTree.add l r δ).computedSum -
              (SummationTree.add l r δ).exactSum) -
              (SummationTree.add l r δ).firstOrder| ≤
          D * (RL + RR) + u * D * (EL + ER) := by
        have h := mul_le_mul_of_nonneg_left hRabs (le_of_lt hD)
        calc
          D * |((SummationTree.add l r δ).computedSum -
                (SummationTree.add l r δ).exactSum) -
                (SummationTree.add l r δ).firstOrder| ≤
              D * (RL + RR + u * (EL + ER)) := h
          _ = D * (RL + RR) + u * D * (EL + ER) := by ring
      have hEsumAmp := mul_le_mul_of_nonneg_left hEsum
        (show 0 ≤ 1 + u by linarith)
      have hEsumU := mul_le_mul_of_nonneg_left hEsum hu
      have hcoeffE : (1 + u) * (m * u) + D * u ≤ (m + 1) * u := by
        have hx : 0 ≤ ((M : ℝ) - m - 1) * u ^ 2 :=
          mul_nonneg (by linarith) (sq_nonneg u)
        dsimp [D]
        nlinarith only [hx]
      have hcoeffR : (m * u) ^ 2 + u * (m * u) ≤
          ((m + 1) * u) ^ 2 := by
        have hx : 0 ≤ (m + 1) * u ^ 2 :=
          mul_nonneg (by linarith) (sq_nonneg u)
        nlinarith only [hx]
      have hcoeffEN := mul_le_mul_of_nonneg_right hcoeffE hN
      have hcoeffRN := mul_le_mul_of_nonneg_right hcoeffR hN
      constructor
      · rw [hheight, hnorm]
        calc
          D * |(SummationTree.add l r δ).computedSum -
              (SummationTree.add l r δ).exactSum| ≤
              (1 + u) * D * (EL + ER) + D * u * (NL + NR) := hEd
          _ ≤ (1 + u) * ((m * u) * (NL + NR)) +
              D * u * (NL + NR) := by nlinarith only [hEsumAmp]
          _ = ((1 + u) * (m * u) + D * u) * (NL + NR) := by ring
          _ ≤ ((m + 1) * u) * (NL + NR) := hcoeffEN
      · rw [hheight, hnorm]
        calc
          D * |((SummationTree.add l r δ).computedSum -
                (SummationTree.add l r δ).exactSum) -
                (SummationTree.add l r δ).firstOrder| ≤
              D * (RL + RR) + u * D * (EL + ER) := hRd
          _ ≤ (m * u) ^ 2 * (NL + NR) +
              u * ((m * u) * (NL + NR)) := by
                nlinarith only [hRsum, hEsumU]
          _ = ((m * u) ^ 2 + u * (m * u)) * (NL + NR) := by ring
          _ ≤ ((m + 1) * u) ^ 2 * (NL + NR) := hcoeffRN

/-- Equation (2.7): the forward error is the sum of exact partial sums
times their local roundoffs, with a uniform second-order remainder. -/
theorem target (t : SummationTree) (u : ℝ)
    (hu : 0 ≤ u) (hround : t.RoundedBy u)
    (hsmall : (t.height : ℝ) * u < 1) :
    |(t.computedSum - t.exactSum) - t.firstOrder| ≤
      (((t.height : ℝ) * u) ^ 2 / (1 - (t.height : ℝ) * u)) * t.inputNorm := by
  have hb := tree_error_bounds u t.height hu hsmall t (le_refl _) hround
  have hd : 0 < 1 - (t.height : ℝ) * u := by linarith
  rcases hb with ⟨_, hb⟩
  rw [div_mul_eq_mul_div]
  apply (le_div_iff₀ hd).2
  nlinarith [hb]

end HighamBenchCandidate
