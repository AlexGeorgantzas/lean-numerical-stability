import Mathlib

namespace HighamBenchCandidate

/-- A binary summation tree. Each leaf is an exact real input, and each
internal node records the relative roundoff of that addition. -/
inductive SummationTree where
  | leaf (x : ℝ) : SummationTree
  | add (left right : SummationTree) (delta : ℝ) : SummationTree

namespace SummationTree

/-- The exact partial sum at a node. -/
def exactSum : SummationTree → ℝ
  | .leaf x => x
  | .add left right _ => exactSum left + exactSum right

/-- Evaluation of the tree by rounded additions on the computed children. -/
def computedSum : SummationTree → ℝ
  | .leaf x => x
  | .add left right delta =>
      (computedSum left + computedSum right) * (1 + delta)

/-- The sum of the first-order local errors `sₖ δₖ`. -/
def firstOrder : SummationTree → ℝ
  | .leaf _ => 0
  | .add left right delta =>
      firstOrder left + firstOrder right +
        (exactSum left + exactSum right) * delta

/-- The inputs, with repetitions retained. -/
def leaves : SummationTree → List ℝ
  | .leaf x => [x]
  | .add left right _ => leaves left ++ leaves right

/-- The sum of absolute values of the fixed input vector. -/
def inputNorm (t : SummationTree) : ℝ :=
  (t.leaves.map abs).sum

/-- The largest number of additions on a root-to-leaf path. -/
def height : SummationTree → ℕ
  | .leaf _ => 0
  | .add left right _ => max (height left) (height right) + 1

/-- Every internal addition satisfies the standard relative-error model. -/
def RoundedBy (u : ℝ) : SummationTree → Prop
  | .leaf _ => True
  | .add left right delta =>
      |delta| ≤ u ∧ RoundedBy u left ∧ RoundedBy u right

end SummationTree

/-- Equation (2.7): the forward error is the sum of exact partial sums
times their local roundoffs, with a uniform second-order remainder. -/
theorem target (t : SummationTree) (u : ℝ)
    (hu : 0 ≤ u) (hround : t.RoundedBy u)
    (hsmall : (t.height : ℝ) * u < 1) :
    |(t.computedSum - t.exactSum) - t.firstOrder| ≤
      (((t.height : ℝ) * u) ^ 2 / (1 - (t.height : ℝ) * u)) * t.inputNorm := by
  sorry

end HighamBenchCandidate
