import NumStability.Algorithms.Summation.Tree.Core

namespace HighamBenchCandidate

open NumStability
open scoped BigOperators

/-- One local error parameter for each internal addition of a binary tree. -/
inductive Roundoffs : {n : ℕ} → SumTree n → Type where
  | leaf : Roundoffs .leaf
  | node {m k : ℕ} {l : SumTree m} {r : SumTree k} :
      Roundoffs l → Roundoffs r → ℝ → Roundoffs (.node l r)

/-- Every internal addition has its own bounded relative error. -/
def BoundedRoundoffs (u : ℝ) :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → Prop
  | _, _, .leaf => True
  | _, _, .node wl wr δ =>
      BoundedRoundoffs u wl ∧ BoundedRoundoffs u wr ∧ |δ| ≤ u

/-- Evaluate the ordered binary tree. Each internal result is the sum of its
computed children times its own factor `1 + δ`; leaves are exact inputs. -/
noncomputable def RoundedEval :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → (Fin n → ℝ) → ℝ
  | _, _, .leaf, v => v ⟨0, by omega⟩
  | _, _, .node wl wr δ, v =>
      (RoundedEval wl (fun i => v (Fin.castAdd _ i)) +
        RoundedEval wr (fun i => v (Fin.natAdd _ i))) * (1 + δ)

/-- The sum of exact internal partial sums times their local roundoffs. -/
noncomputable def FirstOrderTerm :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → (Fin n → ℝ) → ℝ
  | _, _, .leaf, _ => 0
  | _, _, .node (l := l) (r := r) wl wr δ, v =>
      FirstOrderTerm wl (fun i => v (Fin.castAdd _ i)) +
      FirstOrderTerm wr (fun i => v (Fin.natAdd _ i)) +
      SumTree.exactSum (.node l r) v * δ

/-- Hallman–Ipsen (2021), Equation (2.7): the first-order error expansion
for general binary-tree summation. The rational bound makes the remainder
explicit throughout `h*u < 1`; its small-`h*u` consequence has a uniform
constant. The one-leaf tree has zero error and zero first-order term. -/
theorem target :
    ∀ {n : ℕ} (t : SumTree n) (v : Fin n → ℝ)
      (u : ℝ) (hu : 0 ≤ u) (w : Roundoffs t),
      BoundedRoundoffs u w →
      (t.depth : ℝ) * u < 1 →
      ∃ remainder : ℝ,
        RoundedEval w v - SumTree.exactSum t v =
          FirstOrderTerm w v + remainder ∧
        |remainder| ≤
          ((t.depth : ℝ) ^ 2 * u ^ 2) /
              (1 - (t.depth : ℝ) * u) *
            (∑ i : Fin n, |v i|) ∧
        ((t.depth : ℝ) * u ≤ 1 / 2 →
          |remainder| ≤
            2 * (t.depth : ℝ) ^ 2 * u ^ 2 *
              (∑ i : Fin n, |v i|)) := by sorry

end HighamBenchCandidate
