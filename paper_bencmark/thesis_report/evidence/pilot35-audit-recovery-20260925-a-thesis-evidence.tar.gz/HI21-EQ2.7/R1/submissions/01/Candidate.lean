import NumStability.Algorithms.Summation.Tree.Core

namespace HighamBenchCandidate

open NumStability
open scoped BigOperators

/-- One local error parameter for each internal addition of a binary tree. -/
inductive Roundoffs : {n : ℕ} → SumTree n → Type where
  | leaf : Roundoffs .leaf
  | node {m k : ℕ} {l : SumTree m} {r : SumTree k} :
      Roundoffs l → Roundoffs r → ℝ → Roundoffs (.node l r)

/-- Every local error describes the actual rounded addition of the computed
child sums, with the standard relative-error bound. -/
def ValidRoundoffs (fp : FPModel) :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → (Fin n → ℝ) → Prop
  | _, _, .leaf, _ => True
  | _, _, .node (l := l) (r := r) wl wr δ, v =>
      ValidRoundoffs fp wl (fun i => v (Fin.castAdd _ i)) ∧
      ValidRoundoffs fp wr (fun i => v (Fin.natAdd _ i)) ∧
      |δ| ≤ fp.u ∧
      SumTree.eval fp (.node l r) v =
        (SumTree.eval fp l (fun i => v (Fin.castAdd _ i)) +
          SumTree.eval fp r (fun i => v (Fin.natAdd _ i))) * (1 + δ)

/-- The sum of exact internal partial sums times their local roundoffs. -/
noncomputable def FirstOrderTerm :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → (Fin n → ℝ) → ℝ
  | _, _, .leaf, _ => 0
  | _, _, .node (l := l) (r := r) wl wr δ, v =>
      FirstOrderTerm wl (fun i => v (Fin.castAdd _ i)) +
      FirstOrderTerm wr (fun i => v (Fin.natAdd _ i)) +
      SumTree.exactSum (.node l r) v * δ

/-- Hallman–Ipsen (2021), Equation (2.7): the first-order error expansion
for general binary-tree summation. The rational bound makes the remainder
explicit throughout `h*u < 1`; its small-`h*u` consequence has a uniform
constant. The one-leaf tree has zero error and zero first-order term. -/
theorem target :
    ∀ {n : ℕ} (fp : FPModel) (t : SumTree n) (v : Fin n → ℝ),
      gammaValid fp t.depth →
      ∃ w : Roundoffs t,
        ValidRoundoffs fp w v ∧
        ∃ remainder : ℝ,
          SumTree.eval fp t v - SumTree.exactSum t v =
            FirstOrderTerm w v + remainder ∧
          |remainder| ≤
            ((t.depth : ℝ) ^ 2 * fp.u ^ 2) /
                (1 - (t.depth : ℝ) * fp.u) *
              (∑ i : Fin n, |v i|) ∧
          ((t.depth : ℝ) * fp.u ≤ 1 / 2 →
            |remainder| ≤
              2 * (t.depth : ℝ) ^ 2 * fp.u ^ 2 *
                (∑ i : Fin n, |v i|)) := by
  sorry

end HighamBenchCandidate
