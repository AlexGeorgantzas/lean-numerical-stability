import NumStability.Algorithms.Summation.Tree.Core

namespace HighamBenchCandidate

open NumStability
open scoped BigOperators

/-- One local error parameter for each internal addition of a binary tree. -/
inductive Roundoffs : {n : ℕ} → SumTree n → Type where
  | leaf : Roundoffs .leaf
  | node {m k : ℕ} {l : SumTree m} {r : SumTree k} :
      Roundoffs l → Roundoffs r → ℝ → Roundoffs (.node l r)

/-- Every internal addition has its own bounded relative error. -/
def BoundedRoundoffs (u : ℝ) :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → Prop
  | _, _, .leaf => True
  | _, _, .node wl wr δ =>
      BoundedRoundoffs u wl ∧ BoundedRoundoffs u wr ∧ |δ| ≤ u

/-- Evaluate the ordered binary tree. Each internal result is the sum of its
computed children times its own factor `1 + δ`; leaves are exact inputs. -/
noncomputable def RoundedEval :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → (Fin n → ℝ) → ℝ
  | _, _, .leaf, v => v ⟨0, by omega⟩
  | _, _, .node wl wr δ, v =>
      (RoundedEval wl (fun i => v (Fin.castAdd _ i)) +
        RoundedEval wr (fun i => v (Fin.natAdd _ i))) * (1 + δ)

/-- The sum of exact internal partial sums times their local roundoffs. -/
noncomputable def FirstOrderTerm :
    {n : ℕ} → {t : SumTree n} → Roundoffs t → (Fin n → ℝ) → ℝ
  | _, _, .leaf, _ => 0
  | _, _, .node (l := l) (r := r) wl wr δ, v =>
      FirstOrderTerm wl (fun i => v (Fin.castAdd _ i)) +
      FirstOrderTerm wr (fun i => v (Fin.natAdd _ i)) +
      SumTree.exactSum (.node l r) v * δ

private def gap (u : ℝ) (d : ℕ) : ℝ := (1 + u) ^ d - 1

private lemma gap_nonneg (u : ℝ) (hu : 0 ≤ u) (d : ℕ) :
    0 ≤ gap u d := by
  have hbase : 1 ≤ 1 + u := by linarith
  have hpow : (1 : ℝ) ≤ (1 + u) ^ d := by
    simpa using (pow_le_pow_right₀ hbase (Nat.zero_le d))
  exact sub_nonneg.mpr hpow

private lemma gap_mono (u : ℝ) (hu : 0 ≤ u) {a b : ℕ} (hab : a ≤ b) :
    gap u a ≤ gap u b := by
  have hbase : 1 ≤ 1 + u := by linarith
  unfold gap
  linarith [pow_le_pow_right₀ hbase hab]

private lemma gap_succ (u : ℝ) (d : ℕ) :
    gap u (d + 1) = gap u d * (1 + u) + u := by
  simp only [gap, pow_succ]
  ring

private theorem rounded_error_bound {n : ℕ} {t : SumTree n}
    (w : Roundoffs t) :
    ∀ (v : Fin n → ℝ) (u : ℝ), 0 ≤ u → BoundedRoundoffs u w →
      |RoundedEval w v - SumTree.exactSum t v| ≤
        gap u t.depth * (∑ i : Fin n, |v i|) := by
  induction w with
  | leaf =>
      intro v u hu hw
      simp [RoundedEval, SumTree.exactSum, SumTree.depth, gap]
  | @node m k l r wl wr δ ihl ihr =>
      intro v u hu hw
      obtain ⟨hwl, hwr, hδ⟩ := hw
      let vl : Fin m → ℝ := fun i => v (Fin.castAdd k i)
      let vr : Fin k → ℝ := fun i => v (Fin.natAdd m i)
      let AL : ℝ := ∑ i : Fin m, |vl i|
      let AR : ℝ := ∑ i : Fin k, |vr i|
      let A : ℝ := ∑ i : Fin (m + k), |v i|
      let EL : ℝ := RoundedEval wl vl - SumTree.exactSum l vl
      let ER : ℝ := RoundedEval wr vr - SumTree.exactSum r vr
      let D : ℕ := max l.depth r.depth
      have hAL : 0 ≤ AL := Finset.sum_nonneg (fun i _ => abs_nonneg (vl i))
      have hAR : 0 ≤ AR := Finset.sum_nonneg (fun i _ => abs_nonneg (vr i))
      have hA : A = AL + AR := by
        simp only [A, Fin.sum_univ_add]
        rfl
      have hdl : l.depth ≤ D := Nat.le_max_left _ _
      have hdr : r.depth ≤ D := Nat.le_max_right _ _
      have hEL : |EL| ≤ gap u D * AL :=
        (ihl vl u hu hwl).trans
          (mul_le_mul_of_nonneg_right (gap_mono u hu hdl) hAL)
      have hER : |ER| ≤ gap u D * AR :=
        (ihr vr u hu hwr).trans
          (mul_le_mul_of_nonneg_right (gap_mono u hu hdr) hAR)
      have hES : |EL + ER| ≤ gap u D * A := by
        calc
          |EL + ER| ≤ |EL| + |ER| := abs_add_le _ _
          _ ≤ gap u D * AL + gap u D * AR := add_le_add hEL hER
          _ = gap u D * A := by rw [hA]; ring
      have hS : |SumTree.exactSum (.node l r) v| ≤ A := by
        rw [SumTree.exactSum_eq_sum]
        exact Finset.abs_sum_le_sum_abs _ _
      have hfactor : |1 + δ| ≤ 1 + u := by
        calc
          |1 + δ| ≤ |(1 : ℝ)| + |δ| := abs_add_le _ _
          _ ≤ 1 + u := by simpa using add_le_add_left hδ 1
      have hE :
          RoundedEval (Roundoffs.node wl wr δ) v -
              SumTree.exactSum (.node l r) v =
            (EL + ER) * (1 + δ) +
              SumTree.exactSum (.node l r) v * δ := by
        dsimp [EL, ER, vl, vr, RoundedEval, SumTree.exactSum]
        ring
      have hgapA : 0 ≤ gap u D * A := by
        rw [hA]
        exact mul_nonneg (gap_nonneg u hu D) (add_nonneg hAL hAR)
      have hprod1 : |EL + ER| * |1 + δ| ≤ gap u D * A * (1 + u) := by
        calc
          |EL + ER| * |1 + δ| ≤ (gap u D * A) * |1 + δ| :=
            mul_le_mul_of_nonneg_right hES (abs_nonneg _)
          _ ≤ (gap u D * A) * (1 + u) :=
            mul_le_mul_of_nonneg_left hfactor hgapA
      have hprod2 : |SumTree.exactSum (.node l r) v| * |δ| ≤ A * u := by
        calc
          |SumTree.exactSum (.node l r) v| * |δ| ≤ A * |δ| :=
            mul_le_mul_of_nonneg_right hS (abs_nonneg _)
          _ ≤ A * u := by
            apply mul_le_mul_of_nonneg_left hδ
            rw [hA]
            exact add_nonneg hAL hAR
      rw [hE]
      calc
        |(EL + ER) * (1 + δ) + SumTree.exactSum (.node l r) v * δ|
            ≤ |EL + ER| * |1 + δ| +
                |SumTree.exactSum (.node l r) v| * |δ| := by
              simpa [abs_mul] using
                (abs_add_le ((EL + ER) * (1 + δ))
                  (SumTree.exactSum (.node l r) v * δ))
        _ ≤ gap u D * A * (1 + u) + A * u := add_le_add hprod1 hprod2
        _ = gap u (D + 1) * A := by rw [gap_succ]; ring

private theorem remainder_power_bound {n : ℕ} {t : SumTree n}
    (w : Roundoffs t) :
    ∀ (v : Fin n → ℝ) (u : ℝ), 0 ≤ u → BoundedRoundoffs u w →
      |(RoundedEval w v - SumTree.exactSum t v) - FirstOrderTerm w v| ≤
        (t.depth : ℝ) * u * gap u t.depth *
          (∑ i : Fin n, |v i|) := by
  induction w with
  | leaf =>
      intro v u hu hw
      simp [RoundedEval, SumTree.exactSum, FirstOrderTerm,
        SumTree.depth, gap]
  | @node m k l r wl wr δ ihl ihr =>
      intro v u hu hw
      obtain ⟨hwl, hwr, hδ⟩ := hw
      let vl : Fin m → ℝ := fun i => v (Fin.castAdd k i)
      let vr : Fin k → ℝ := fun i => v (Fin.natAdd m i)
      let AL : ℝ := ∑ i : Fin m, |vl i|
      let AR : ℝ := ∑ i : Fin k, |vr i|
      let A : ℝ := ∑ i : Fin (m + k), |v i|
      let EL : ℝ := RoundedEval wl vl - SumTree.exactSum l vl
      let ER : ℝ := RoundedEval wr vr - SumTree.exactSum r vr
      let RL : ℝ := EL - FirstOrderTerm wl vl
      let RR : ℝ := ER - FirstOrderTerm wr vr
      let D : ℕ := max l.depth r.depth
      have hAL : 0 ≤ AL := Finset.sum_nonneg (fun i _ => abs_nonneg (vl i))
      have hAR : 0 ≤ AR := Finset.sum_nonneg (fun i _ => abs_nonneg (vr i))
      have hA : A = AL + AR := by
        simp only [A, Fin.sum_univ_add]
        rfl
      have hdl : l.depth ≤ D := Nat.le_max_left _ _
      have hdr : r.depth ≤ D := Nat.le_max_right _ _
      have hEL := rounded_error_bound wl vl u hu hwl
      have hER := rounded_error_bound wr vr u hu hwr
      have hRL := ihl vl u hu hwl
      have hRR := ihr vr u hu hwr
      have hRoot :
          (RoundedEval (Roundoffs.node wl wr δ) v -
              SumTree.exactSum (.node l r) v) -
                FirstOrderTerm (Roundoffs.node wl wr δ) v =
            RL + RR + δ * (EL + ER) := by
        dsimp [RL, RR, EL, ER, vl, vr,
          RoundedEval, SumTree.exactSum, FirstOrderTerm]
        ring
      have hcoef (d : ℕ) (hd : d ≤ D) :
          ((d : ℝ) + 1) * u * gap u d ≤
            ((D : ℝ) + 1) * u * gap u (D + 1) := by
        have hdim : (d : ℝ) + 1 ≤ (D : ℝ) + 1 := by
          exact_mod_cast Nat.add_le_add_right hd 1
        have hdimU : ((d : ℝ) + 1) * u ≤ ((D : ℝ) + 1) * u :=
          mul_le_mul_of_nonneg_right hdim hu
        have hDU : 0 ≤ ((D : ℝ) + 1) * u := by positivity
        calc
          ((d : ℝ) + 1) * u * gap u d
              ≤ ((D : ℝ) + 1) * u * gap u d :=
                mul_le_mul_of_nonneg_right hdimU (gap_nonneg u hu d)
          _ ≤ ((D : ℝ) + 1) * u * gap u D :=
                mul_le_mul_of_nonneg_left (gap_mono u hu hd) hDU
          _ ≤ ((D : ℝ) + 1) * u * gap u (D + 1) :=
                mul_le_mul_of_nonneg_left
                  (gap_mono u hu (Nat.le_succ D)) hDU
      have hPairL : |RL| + u * |EL| ≤
          (((D : ℝ) + 1) * u * gap u (D + 1)) * AL := by
        calc
          |RL| + u * |EL| ≤
              ((l.depth : ℝ) * u * gap u l.depth) * AL +
                u * (gap u l.depth * AL) := by
                  exact add_le_add hRL
                    (mul_le_mul_of_nonneg_left hEL hu)
          _ = (((l.depth : ℝ) + 1) * u * gap u l.depth) * AL := by ring
          _ ≤ (((D : ℝ) + 1) * u * gap u (D + 1)) * AL :=
              mul_le_mul_of_nonneg_right (hcoef l.depth hdl) hAL
      have hPairR : |RR| + u * |ER| ≤
          (((D : ℝ) + 1) * u * gap u (D + 1)) * AR := by
        calc
          |RR| + u * |ER| ≤
              ((r.depth : ℝ) * u * gap u r.depth) * AR +
                u * (gap u r.depth * AR) := by
                  exact add_le_add hRR
                    (mul_le_mul_of_nonneg_left hER hu)
          _ = (((r.depth : ℝ) + 1) * u * gap u r.depth) * AR := by ring
          _ ≤ (((D : ℝ) + 1) * u * gap u (D + 1)) * AR :=
              mul_le_mul_of_nonneg_right (hcoef r.depth hdr) hAR
      have hCross : |δ * (EL + ER)| ≤ u * (|EL| + |ER|) := by
        rw [abs_mul]
        calc
          |δ| * |EL + ER| ≤ |δ| * (|EL| + |ER|) :=
            mul_le_mul_of_nonneg_left (abs_add_le _ _) (abs_nonneg _)
          _ ≤ u * (|EL| + |ER|) :=
            mul_le_mul_of_nonneg_right hδ (add_nonneg (abs_nonneg _) (abs_nonneg _))
      have hmain :
          |RL + RR + δ * (EL + ER)| ≤
            ((D : ℝ) + 1) * u * gap u (D + 1) * A := by
        calc
          |RL + RR + δ * (EL + ER)|
              ≤ |RL| + |RR| + |δ * (EL + ER)| := by
                linarith [abs_add_le RL RR,
                  abs_add_le (RL + RR) (δ * (EL + ER))]
          _ ≤ |RL| + |RR| + u * (|EL| + |ER|) := by linarith
          _ = (|RL| + u * |EL|) + (|RR| + u * |ER|) := by ring
          _ ≤ (((D : ℝ) + 1) * u * gap u (D + 1)) * AL +
                (((D : ℝ) + 1) * u * gap u (D + 1)) * AR :=
                  add_le_add hPairL hPairR
          _ = ((D : ℝ) + 1) * u * gap u (D + 1) * A := by
                rw [hA]
                ring
      rw [hRoot]
      simpa [SumTree.depth, D, A] using hmain

private lemma gap_le_rational (u : ℝ) (hu : 0 ≤ u) (d : ℕ)
    (hvalid : (d : ℝ) * u < 1) :
    gap u d ≤ ((d : ℝ) * u) / (1 - (d : ℝ) * u) := by
  let fp := FPModel.exactWithUnitRoundoff u hu
  have hdelta : ∀ i : Fin d, |(fun _ : Fin d => u) i| ≤ fp.u := by
    intro i
    simp [fp, FPModel.exactWithUnitRoundoff, abs_of_nonneg hu]
  have hv : gammaValid fp d := by
    simpa [gammaValid, fp, FPModel.exactWithUnitRoundoff] using hvalid
  obtain ⟨θ, hθ, hprod⟩ := prod_error_bound fp d (fun _ => u) hdelta hv
  have heq : (1 + u) ^ d = 1 + θ := by simpa using hprod
  have hgap : gap u d = θ := by unfold gap; linarith
  rw [hgap]
  calc
    θ ≤ |θ| := le_abs_self θ
    _ ≤ gamma fp d := hθ
    _ = ((d : ℝ) * u) / (1 - (d : ℝ) * u) := by
      simp [gamma, fp, FPModel.exactWithUnitRoundoff]

/-- Hallman–Ipsen (2021), Equation (2.7): the first-order error expansion
for general binary-tree summation. The rational bound makes the remainder
explicit throughout `h*u < 1`; its small-`h*u` consequence has a uniform
constant. The one-leaf tree has zero error and zero first-order term. -/
theorem target :
    ∀ {n : ℕ} (t : SumTree n) (v : Fin n → ℝ)
      (u : ℝ) (hu : 0 ≤ u) (w : Roundoffs t),
      BoundedRoundoffs u w →
      (t.depth : ℝ) * u < 1 →
      ∃ remainder : ℝ,
        RoundedEval w v - SumTree.exactSum t v =
          FirstOrderTerm w v + remainder ∧
        |remainder| ≤
          ((t.depth : ℝ) ^ 2 * u ^ 2) /
              (1 - (t.depth : ℝ) * u) *
            (∑ i : Fin n, |v i|) ∧
        ((t.depth : ℝ) * u ≤ 1 / 2 →
          |remainder| ≤
            2 * (t.depth : ℝ) ^ 2 * u ^ 2 *
            (∑ i : Fin n, |v i|)) := by
  intro n t v u hu w hw hvalid
  let a : ℝ := (t.depth : ℝ) * u
  let A : ℝ := ∑ i : Fin n, |v i|
  have ha : 0 ≤ a := by
    dsimp [a]
    exact mul_nonneg (by exact_mod_cast Nat.zero_le t.depth) hu
  have hA : 0 ≤ A := Finset.sum_nonneg (fun i _ => abs_nonneg (v i))
  have hgap : gap u t.depth ≤ a / (1 - a) := by
    simpa [a] using gap_le_rational u hu t.depth hvalid
  let remainder : ℝ :=
    (RoundedEval w v - SumTree.exactSum t v) - FirstOrderTerm w v
  refine ⟨remainder, ?_, ?_, ?_⟩
  · dsimp [remainder]
    ring
  · have hraw := remainder_power_bound w v u hu hw
    calc
      |remainder| ≤ a * gap u t.depth * A := by
        simpa [remainder, a, A] using hraw
      _ ≤ a * (a / (1 - a)) * A :=
        mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left hgap ha) hA
      _ = ((t.depth : ℝ) ^ 2 * u ^ 2) /
            (1 - (t.depth : ℝ) * u) * A := by
          dsimp [a]
          ring
      _ = ((t.depth : ℝ) ^ 2 * u ^ 2) /
            (1 - (t.depth : ℝ) * u) *
              (∑ i : Fin n, |v i|) := rfl
  · intro hsmall
    have hsmall' : a ≤ 1 / 2 := by simpa [a] using hsmall
    have hden : 0 < 1 - a := by simpa [a] using sub_pos.mpr hvalid
    have hInv : 1 / (1 - a) ≤ (2 : ℝ) := by
      apply (div_le_iff₀ hden).2
      linarith
    have hratio : a / (1 - a) ≤ 2 * a := by
      calc
        a / (1 - a) = a * (1 / (1 - a)) := by ring
        _ ≤ a * 2 := mul_le_mul_of_nonneg_left hInv ha
        _ = 2 * a := by ring
    have hraw := remainder_power_bound w v u hu hw
    calc
      |remainder| ≤ a * gap u t.depth * A := by
        simpa [remainder, a, A] using hraw
      _ ≤ a * (a / (1 - a)) * A :=
        mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left hgap ha) hA
      _ ≤ a * (2 * a) * A :=
        mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left hratio ha) hA
      _ = 2 * (t.depth : ℝ) ^ 2 * u ^ 2 *
            (∑ i : Fin n, |v i|) := by
          dsimp [a, A]
          ring

end HighamBenchCandidate
