import Mathlib

namespace HighamBenchCandidate

/-- Sum a nonempty block from its first input, rounding each subsequent addition. -/
def roundedSum (add : ℝ → ℝ → ℝ) : List ℝ → ℝ
  | [] => 0
  | x :: xs => xs.foldl add x

/-- At level `t + 1`, sum the consecutive `b` child blocks of length `b ^ t`.
The base level reads its one input without performing an addition. This follows
the prose and Figure 3.2: the propagation loop printed in Figure 3.1(a) omits
the final transfer into temporary zero. -/
def superblock (add : ℝ → ℝ → ℝ) (b : ℕ) : ℕ → List ℝ → ℝ
  | 0, xs => xs.headD 0
  | t + 1, xs =>
      roundedSum add <|
        (List.range b).map fun k =>
          superblock add b t ((xs.drop (k * b ^ t)).take (b ^ t))

/-- The standard relative-error model for each rounded addition. -/
def RelativeAddition (u : ℝ) (add : ℝ → ℝ → ℝ) : Prop :=
  ∀ a c : ℝ, ∃ δ : ℝ, |δ| ≤ u ∧ add a c = (a + c) * (1 + δ)

/-- Higham's gamma factor, defined when `k * u < 1`. -/
noncomputable def gamma (u : ℝ) (k : ℕ) : ℝ :=
  (k : ℝ) * u / (1 - (k : ℝ) * u)

/-- Sum of the `(factor - 1)` error counters at all levels. -/
def errorCounter {t : ℕ} (factors : Fin t → ℕ) : ℕ :=
  ∑ i : Fin t, factors i - 1

theorem target :
    ∀ (t b : ℕ) (u : ℝ) (add : ℝ → ℝ → ℝ)
      (x : Fin (b ^ t) → ℝ),
      0 < t → 0 < b → 0 ≤ u →
      (t * (b - 1) : ℕ) * u < 1 →
      RelativeAddition u add →
      (|superblock add b t (List.ofFn x) - ∑ i : Fin (b ^ t), x i| ≤
          gamma u (t * (b - 1)) * ∑ i : Fin (b ^ t), |x i|) ∧
      ((∏ _i : Fin t, b) = b ^ t) ∧
      (errorCounter (fun _ : Fin t => b) = t * (b - 1)) ∧
      (∀ factors : Fin t → ℕ,
        (∀ i, 0 < factors i) →
        (∏ i : Fin t, factors i) = b ^ t →
        t * (b - 1) ≤ errorCounter factors) := by
  sorry

end HighamBenchCandidate
