import NumStability.Algorithms.Summation.Recursive.Core
import Mathlib.Analysis.MeanInequalities
import Mathlib.Tactic

namespace HighamBenchCandidate

open scoped BigOperators

/-- Position `i` within the `j`th consecutive block of length `b^t`. -/
def blockIndex (b t : ℕ) (j : Fin b) (i : Fin (b ^ t)) : Fin (b ^ (t + 1)) :=
  ⟨j.val * b ^ t + i.val, by
    have hj : j.val + 1 ≤ b := j.isLt
    have hi : i.val < b ^ t := i.isLt
    have hmul := Nat.mul_le_mul_right (b ^ t) hj
    rw [pow_succ]
    nlinarith⟩

private def blockEquiv (b t : ℕ) : Fin b × Fin (b ^ t) ≃ Fin (b ^ (t + 1)) :=
  finProdFinEquiv.trans (finCongr (by rw [pow_succ]; ac_rfl))

private lemma blockEquiv_apply (b t : ℕ) (j : Fin b) (i : Fin (b ^ t)) :
    blockEquiv b t (j, i) = blockIndex b t j i := by
  apply Fin.ext
  simp [blockEquiv, blockIndex, finProdFinEquiv, Nat.mul_comm]
  omega

private lemma sum_blocks (b t : ℕ) (f : Fin (b ^ (t + 1)) → ℝ) :
    (∑ k, f k) = ∑ j : Fin b, ∑ i : Fin (b ^ t), f (blockIndex b t j i) := by
  calc
    (∑ k, f k) = ∑ p : Fin b × Fin (b ^ t), f (blockEquiv b t p) :=
      (Equiv.sum_comp (blockEquiv b t) f).symm
    _ = ∑ j : Fin b, ∑ i : Fin (b ^ t), f (blockIndex b t j i) := by
      rw [Fintype.sum_prod_type]
      apply Finset.sum_congr rfl
      intro j _
      apply Finset.sum_congr rfl
      intro i _
      rw [blockEquiv_apply]

/-- Equal-block summation: at each level, sum `b` consecutive child totals
left to right with rounded additions. The level-zero block is one input. -/
noncomputable def superblockSum (fp : NumStability.FPModel) (b : ℕ) :
    (t : ℕ) → (Fin (b ^ t) → ℝ) → ℝ
  | 0, v => v ⟨0, by simp⟩
  | t + 1, v =>
      NumStability.fl_recursiveSum fp b (fun j =>
        superblockSum fp b t (fun i => v (blockIndex b t j i)))

/-- The sum of per-level rounded-addition counters for integral block sizes. -/
def blockingCounter {t : ℕ} (factors : Fin t → ℕ) : ℕ :=
  ∑ i : Fin t, (factors i - 1)

private lemma blockingCounter_min (t b : ℕ) (ht : 0 < t) (hb : 0 < b)
    (factors : Fin t → ℕ) (hf : ∀ i, 0 < factors i)
    (hprod : (∏ i : Fin t, factors i) = b ^ t) :
    t * (b - 1) ≤ blockingCounter factors := by
  have hmean := Real.geom_mean_le_arith_mean (Finset.univ : Finset (Fin t))
    (fun _ => (1 : ℝ)) (fun i => (factors i : ℝ))
    (by simp) (by simpa using (show (0 : ℝ) < t by exact_mod_cast ht))
    (by intro i _; simpa using (Nat.cast_nonneg (factors i) : (0 : ℝ) ≤ (factors i : ℝ)))
  simp only [Finset.sum_const, Finset.card_fin, nsmul_eq_mul, mul_one,
    one_mul, Real.rpow_one] at hmean
  have hprodR : (∏ i : Fin t, (factors i : ℝ)) = (b : ℝ) ^ t := by
    exact_mod_cast hprod
  rw [hprodR, Real.pow_rpow_inv_natCast (by positivity) (by omega)] at hmean
  have htR : (0 : ℝ) < t := by exact_mod_cast ht
  have hsumR : (∑ i : Fin t, (factors i : ℝ)) =
      ((∑ i : Fin t, factors i : ℕ) : ℝ) := by norm_cast
  have hsum_lower : (t : ℝ) * b ≤ ∑ i : Fin t, (factors i : ℝ) := by
    have h := (le_div_iff₀ htR).mp hmean
    simpa [mul_comm] using h
  rw [hsumR] at hsum_lower
  have hn : t * b ≤ ∑ i : Fin t, factors i := by exact_mod_cast hsum_lower
  have hsplit : (∑ i : Fin t, factors i) = blockingCounter factors + t := by
    calc
      (∑ i : Fin t, factors i) = ∑ i : Fin t, ((factors i - 1) + 1) := by
        apply Finset.sum_congr rfl
        intro i _
        have hi := hf i
        omega
      _ = blockingCounter factors + t := by
        simp [blockingCounter, Finset.sum_add_distrib]
  have htb : t * (b - 1) + t = t * b := by
    calc
      t * (b - 1) + t = t * ((b - 1) + 1) := by ring
      _ = t * b := by rw [Nat.sub_add_cancel (by omega : 1 ≤ b)]
  omega

private lemma superblockSum_error (fp : NumStability.FPModel) (b : ℕ) (hb : 0 < b) :
    ∀ (t : ℕ) (v : Fin (b ^ t) → ℝ),
      NumStability.gammaValid fp (t * (b - 1)) →
      |superblockSum fp b t v - ∑ i : Fin (b ^ t), v i| ≤
        NumStability.gamma fp (t * (b - 1)) *
          ∑ i : Fin (b ^ t), |v i| := by
  intro t
  induction t with
  | zero =>
      intro v _
      simp [superblockSum, NumStability.gamma]
  | succ t ih =>
      intro v hvalid
      let w : Fin b → ℝ := fun j =>
        superblockSum fp b t (fun i => v (blockIndex b t j i))
      let a : Fin b → ℝ := fun j =>
        ∑ i : Fin (b ^ t), v (blockIndex b t j i)
      let m : Fin b → ℝ := fun j =>
        ∑ i : Fin (b ^ t), |v (blockIndex b t j i)|
      let gi := NumStability.gamma fp (t * (b - 1))
      let go := NumStability.gamma fp (b - 1)
      let gt := NumStability.gamma fp ((t + 1) * (b - 1))
      have hci : t * (b - 1) ≤ (t + 1) * (b - 1) :=
        Nat.mul_le_mul_right (b - 1) (Nat.le_succ t)
      have hco : b - 1 ≤ (t + 1) * (b - 1) := by
        calc
          b - 1 = 1 * (b - 1) := by simp
          _ ≤ (t + 1) * (b - 1) :=
            Nat.mul_le_mul_right (b - 1) (by omega)
      have hvi : NumStability.gammaValid fp (t * (b - 1)) :=
        NumStability.gammaValid_mono fp hci hvalid
      have hvo : NumStability.gammaValid fp (b - 1) :=
        NumStability.gammaValid_mono fp hco hvalid
      have hgi : 0 ≤ gi := NumStability.gamma_nonneg fp hvi
      have hgo : 0 ≤ go := NumStability.gamma_nonneg fp hvo
      have hinner : ∀ j, |w j - a j| ≤ gi * m j := by
        intro j
        exact ih (fun i => v (blockIndex b t j i)) hvi
      have hm : ∀ j, 0 ≤ m j := by
        intro j
        exact Finset.sum_nonneg (fun i _ => abs_nonneg _)
      have ha : ∀ j, |a j| ≤ m j := by
        intro j
        exact Finset.abs_sum_le_sum_abs _ _
      have hw : ∀ j, |w j| ≤ (1 + gi) * m j := by
        intro j
        calc
          |w j| = |(w j - a j) + a j| := by ring
          _ ≤ |w j - a j| + |a j| := abs_add_le _ _
          _ ≤ gi * m j + m j := add_le_add (hinner j) (ha j)
          _ = (1 + gi) * m j := by ring
      have hM : 0 ≤ ∑ j : Fin b, m j :=
        Finset.sum_nonneg (fun j _ => hm j)
      have hsumw : (∑ j : Fin b, |w j|) ≤
          (1 + gi) * ∑ j : Fin b, m j := by
        calc
          (∑ j : Fin b, |w j|) ≤ ∑ j : Fin b, (1 + gi) * m j :=
            Finset.sum_le_sum (fun j _ => hw j)
          _ = (1 + gi) * ∑ j : Fin b, m j := by rw [Finset.mul_sum]
      have hdiff : |(∑ j : Fin b, w j) - ∑ j : Fin b, a j| ≤
          gi * ∑ j : Fin b, m j := by
        rw [← Finset.sum_sub_distrib]
        calc
          |∑ j : Fin b, (w j - a j)| ≤ ∑ j : Fin b, |w j - a j| :=
            Finset.abs_sum_le_sum_abs _ _
          _ ≤ ∑ j : Fin b, gi * m j :=
            Finset.sum_le_sum (fun j _ => hinner j)
          _ = gi * ∑ j : Fin b, m j := by rw [Finset.mul_sum]
      have houter := NumStability.recursiveSum_forward_error_bound fp b w hvo
      have hcomp : |superblockSum fp b (t + 1) v - ∑ j : Fin b, a j| ≤
          (go + gi + go * gi) * ∑ j : Fin b, m j := by
        change |NumStability.fl_recursiveSum fp b w - ∑ j : Fin b, a j| ≤ _
        calc
          |NumStability.fl_recursiveSum fp b w - ∑ j : Fin b, a j| =
              |(NumStability.fl_recursiveSum fp b w - ∑ j : Fin b, w j) +
                ((∑ j : Fin b, w j) - ∑ j : Fin b, a j)| := by ring
          _ ≤ |NumStability.fl_recursiveSum fp b w - ∑ j : Fin b, w j| +
                |(∑ j : Fin b, w j) - ∑ j : Fin b, a j| := abs_add_le _ _
          _ ≤ go * (∑ j : Fin b, |w j|) + gi * (∑ j : Fin b, m j) :=
            add_le_add houter hdiff
          _ ≤ go * ((1 + gi) * ∑ j : Fin b, m j) +
                gi * (∑ j : Fin b, m j) := by
            gcongr
          _ = (go + gi + go * gi) * ∑ j : Fin b, m j := by ring
      have hgamma : go + gi + go * gi ≤ gt := by
        simpa [go, gi, gt, Nat.succ_mul, add_comm, add_left_comm, add_assoc] using
          NumStability.gamma_sum_le fp (b - 1) (t * (b - 1))
            (by simpa [Nat.succ_mul, add_comm, add_left_comm, add_assoc] using hvalid)
      calc
        |superblockSum fp b (t + 1) v - ∑ i : Fin (b ^ (t + 1)), v i| =
            |superblockSum fp b (t + 1) v - ∑ j : Fin b, a j| := by
              rw [sum_blocks]
        _ ≤ (go + gi + go * gi) * ∑ j : Fin b, m j := hcomp
        _ ≤ gt * ∑ j : Fin b, m j :=
          mul_le_mul_of_nonneg_right hgamma hM
        _ = NumStability.gamma fp ((t + 1) * (b - 1)) *
              ∑ i : Fin (b ^ (t + 1)), |v i| := by
          rw [sum_blocks]

/-- Castaldo, Whaley, and Chronopoulos, Proposition 3.1, for an integral
equal blocking factor. Figure 3.1(a)'s printed propagation loop omits the
final transfer to temporary zero; `superblockSum` follows the proposition's
consecutive-block computation and Figure 3.2. -/
theorem target :
    ∀ (t b : ℕ) (fp : NumStability.FPModel)
      (v : Fin (b ^ t) → ℝ),
      0 < t → 0 < b →
      NumStability.gammaValid fp (t * (b - 1)) →
      (∀ factors : Fin t → ℕ,
        (∀ i, 0 < factors i) →
        (∏ i : Fin t, factors i) = b ^ t →
        t * (b - 1) ≤ blockingCounter factors) ∧
      blockingCounter (fun _ : Fin t => b) = t * (b - 1) ∧
      |superblockSum fp b t v - ∑ i : Fin (b ^ t), v i| ≤
        NumStability.gamma fp (t * (b - 1)) *
          ∑ i : Fin (b ^ t), |v i| := by
  intro t b fp v ht hb hvalid
  refine ⟨?_, ?_, superblockSum_error fp b hb t v hvalid⟩
  · intro factors hf hprod
    exact blockingCounter_min t b ht hb factors hf hprod
  · simp [blockingCounter]

end HighamBenchCandidate
