import NumStability.Algorithms.Summation.Recursive.Core

namespace HighamBenchCandidate

open scoped BigOperators

/-- Position `i` within the `j`th consecutive block of length `b^t`. -/
def blockIndex (b t : ℕ) (j : Fin b) (i : Fin (b ^ t)) : Fin (b ^ (t + 1)) :=
  ⟨j.val * b ^ t + i.val, by
    have hj : j.val + 1 ≤ b := j.isLt
    have hi : i.val < b ^ t := i.isLt
    have hmul := Nat.mul_le_mul_right (b ^ t) hj
    rw [pow_succ]
    nlinarith⟩

/-- Equal-block summation: at each level, sum `b` consecutive child totals
left to right with rounded additions. The level-zero block is one input. -/
noncomputable def superblockSum (fp : NumStability.FPModel) (b : ℕ) :
    (t : ℕ) → (Fin (b ^ t) → ℝ) → ℝ
  | 0, v => v ⟨0, by simp⟩
  | t + 1, v =>
      NumStability.fl_recursiveSum fp b (fun j =>
        superblockSum fp b t (fun i => v (blockIndex b t j i)))

/-- The sum of per-level rounded-addition counters for integral block sizes. -/
def blockingCounter {t : ℕ} (factors : Fin t → ℕ) : ℕ :=
  ∑ i : Fin t, (factors i - 1)

/-- Castaldo, Whaley, and Chronopoulos, Proposition 3.1, for an integral
equal blocking factor. Figure 3.1(a)'s printed propagation loop omits the
final transfer to temporary zero; `superblockSum` follows the proposition's
consecutive-block computation and Figure 3.2. -/
theorem target :
    ∀ (t b : ℕ) (fp : NumStability.FPModel)
      (v : Fin (b ^ t) → ℝ),
      0 < t → 0 < b →
      NumStability.gammaValid fp (t * (b - 1)) →
      (∀ factors : Fin t → ℕ,
        (∀ i, 0 < factors i) →
        (∏ i : Fin t, factors i) = b ^ t →
        t * (b - 1) ≤ blockingCounter factors) ∧
      blockingCounter (fun _ : Fin t => b) = t * (b - 1) ∧
      |superblockSum fp b t v - ∑ i : Fin (b ^ t), v i| ≤
        NumStability.gamma fp (t * (b - 1)) *
          ∑ i : Fin (b ^ t), |v i| := by
  sorry

end HighamBenchCandidate
